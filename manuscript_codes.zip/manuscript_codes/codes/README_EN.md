# Python Codes for Article Figures

This folder contains all Python codes used to generate the figures in the article "A Bibliometric and S-Curve-Based Analysis of Artificial Intelligence Paradigms".

##  Code List and Descriptions

### Figure 1. Keyword Co-occurrence Analysis
**File:** `01_keyword_cooccurrence_analysis.py`
**Description:** Fig. 1 - Keyword co-occurrence patterns across Symbolic, Hybrid, and Statistical AI paradigms
**Output:** Comparative bar chart of most frequently used keywords across three paradigms

### Figure 2. Keyword Overlap Venn Diagram  
**File:** `02_keyword_overlap_venn_diagram.py`
**Description:** Fig. 2 - Keyword overlap among Symbolic, Hybrid, and Statistical AI paradigms
**Output:** Venn diagram showing keyword overlaps between paradigms

### Figure 6. Author Network Analysis
**File:** `03_author_network_analysis.py`
**Description:** Fig. 6 - Comparative Author Network Metrics Across AI Paradigms (1956–2024)
**Output:** Comparative metrics of author collaboration networks (Link Strength, Centrality, Citations)

### Figure 10. Cross-Paradigm Authors
**File:** `04_cross_paradigm_authors.py`
**Description:** Fig. 10 - Cross-paradigm author dynamics in AI research (1956-2024)
**Output:** Analysis of authors working across paradigms (6-panel visualization)

### Figure 11. Citation Analysis Panels
**File:** `05_citation_analysis_panels.py`
**Description:** Fig. 11 - Citation performance metrics across AI paradigms (1956–2024)
**Output:** Comprehensive 6-panel visualization of citation analysis

### Figure 12. Symbolic AI S-Curve
**File:** `06_symbolic_ai_s_curve.py`
**Description:** Fig. 12 - Symbolic AI S-curve analysis (1956-2024)
**Output:** 4-panel S-curve analysis of Symbolic AI

### Figure 13. Statistical AI S-Curve
**File:** `07_statistical_ai_s_curve.py`
**Description:** Fig. 13 - Statistical AI S-curve analysis (1956-2024)
**Output:** 4-panel S-curve analysis of Statistical AI

### Figure 14. Hybrid AI S-Curve
**File:** `08_hybrid_ai_s_curve.py`
**Description:** Fig. 14 - Hybrid AI S-curve analysis (1997-2024)
**Output:** 4-panel S-curve analysis of Hybrid AI

### Figure 15. Comparative S-Curves
**File:** `09_comparative_s_curves.py`
**Description:** Fig. 15 - Comparative S-curve analysis of AI paradigms
**Output:** Comparative S-curve analysis of three paradigms

### Figure 16. Paradigm Evolution Transitions
**File:** `10_paradigm_evolution_transitions.py`
**Description:** Fig. 16 - AI Paradigm Evolution: S-Curve Transitions and Paradigm Shifts
**Output:** Paradigm transition visualization based on Kurzweil's theory

##  Usage Instructions

### Required Libraries:
```python
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import json
import seaborn as sns
from scipy.optimize import curve_fit
from matplotlib.patches import Rectangle
import warnings
```

### Data Source:
- **Dataset:** JSON files extracted from `dataset.zip`
- **Paradigms:** Symbolic AI, Statistical AI, Hybrid AI
- **Time Range:** 1956-2024

### Execution:
```bash
cd makale_kodlari
python3 01_keyword_cooccurrence_analysis.py
python3 02_keyword_overlap_venn_diagram.py
# ... other files
```

## Technical Specifications

### Figure Properties:
- **DPI:** 300 (high resolution)
- **Format:** PNG
- **Dimensions:** Article standard compliant
- **Colors:** Paradigm consistency (Blue: Symbolic, Orange: Statistical, Green: Hybrid)

### S-Curve Model:
```python
def logistic_function(x, L, k, x0):
    return L / (1 + np.exp(-k * (x - x0)))
```

### Data Processing:
- JSON parse errors fixed
- UTF-8 BOM issues resolved
- Missing data cleaned

##  Results Summary

### Symbolic AI:
- **Publications:** 5,172
- **Inflection Point:** 2005.1
- **R²:** 0.997

### Statistical AI:
- **Publications:** 7,812
- **Inflection Point:** 2019.7
- **R²:** 0.996

### Hybrid AI:
- **Publications:** 1,543
- **Inflection Point:** 2024.0
- **R²:** 0.998

##  Key Findings

### Paradigm Lifecycle Stages:
- **Symbolic AI:** Maturity phase (post-2005 inflection)
- **Statistical AI:** Active growth phase (2019.7 inflection)
- **Hybrid AI:** Critical growth threshold (2024.0 inflection)

### Kurzweil's Theory Validation:
- **Law of Accelerating Returns:** Confirmed
- **Systematic paradigm transitions:** Validated
- **"Each paradigm creates the next":** Empirically supported

### S-Curve Model Performance:
- **Excellent fit:** R² values 0.996-0.998
- **Predictive power:** High accuracy in modeling
- **Pattern consistency:** Across all paradigms

##  Notes

- All codes use the dataset.zip file
- Figure outputs are publication quality (300 DPI)
- S-curve analyses validate Kurzweil's theory
- Paradigm transitions show systematic patterns
- Cross-paradigm analysis reveals research evolution

##  Methodology

### Bibliometric Analysis:
- **Data Sources:** OpenAlex API, VOSviewer exports
- **Time Span:** 1956-2024 (68 years)
- **Classification:** Rule-based paradigm assignment
- **Validation:** Cross-reference with literature

### S-Curve Modeling:
- **Function:** Logistic growth model
- **Parameters:** L (carrying capacity), k (growth rate), x0 (inflection point)
- **Optimization:** Scipy curve_fit with robust error handling
- **Validation:** R² goodness-of-fit metrics

### Visualization Standards:
- **Consistency:** Unified color scheme across figures
- **Quality:** Publication-ready 300 DPI resolution
- **Accessibility:** Clear legends and annotations
- **Reproducibility:** Fully documented code

##  Research Impact

### Theoretical Contributions:
- First comprehensive S-curve analysis of AI paradigms
- Empirical validation of Kurzweil's accelerating returns law
- Quantitative framework for paradigm transition analysis

### Practical Applications:
- Technology forecasting and planning
- Research funding allocation guidance
- Academic career path insights
- Innovation policy development

### Future Research Directions:
- Real-time paradigm monitoring systems
- Predictive models for emerging paradigms
- Cross-disciplinary paradigm analysis
- AI ethics and governance implications

##  Developer
* - Advanced Bibliometric Analysis & S-Curve Modeling

##  Citation
If you use these codes in your research, please cite:
```
[Your Article Citation Here]
"A Bibliometric and S-Curve-Based Analysis of Artificial Intelligence Paradigms"
```

##  Contact
For questions about the code or methodology, please refer to the original article or contact the corresponding author.

---


