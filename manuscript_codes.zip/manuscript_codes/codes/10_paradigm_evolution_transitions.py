#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AI Paradigm Transition Figure
Ekteki WhatsApp görselindeki gibi paradigma geçişlerini gösteren küçük figür
"""

import matplotlib.pyplot as plt
import numpy as np
import matplotlib.patches as patches
from matplotlib.patches import FancyBboxPatch
import warnings
warnings.filterwarnings('ignore')

# Set matplotlib parameters for clean visualization
plt.rcParams['figure.figsize'] = (12, 8)
plt.rcParams['font.size'] = 12
plt.rcParams['axes.titlesize'] = 14
plt.rcParams['axes.labelsize'] = 12
plt.rcParams['xtick.labelsize'] = 10
plt.rcParams['ytick.labelsize'] = 10
plt.rcParams['legend.fontsize'] = 11

def s_curve_function(x, L, k, x0):
    """Logistic S-curve function"""
    return L / (1 + np.exp(-k * (x - x0)))

def create_paradigm_transition_figure():
    """Create a conceptual figure showing AI paradigm transitions"""
    
    # Create figure and axis
    fig, ax = plt.subplots(1, 1, figsize=(12, 8))
    
    # Time range
    years = np.linspace(1950, 2030, 1000)
    
    # Define S-curve parameters for each paradigm (conceptual)
    # Symbolic AI: Early start, mature
    symbolic_params = [1000, 0.08, 1985]
    
    # Statistical AI: Later start, currently dominant
    statistical_params = [1500, 0.12, 2005]
    
    # Hybrid AI: Recent start, exponential growth
    hybrid_params = [800, 0.25, 2020]
    
    # Generate S-curves
    symbolic_curve = s_curve_function(years, *symbolic_params)
    statistical_curve = s_curve_function(years, *statistical_params)
    hybrid_curve = s_curve_function(years, *hybrid_params)
    
    # Plot the curves
    ax.plot(years, symbolic_curve, color='#1f77b4', linewidth=3, 
           label='Symbolic AI', alpha=0.8)
    ax.plot(years, statistical_curve, color='#ff7f0e', linewidth=3, 
           label='Statistical AI', alpha=0.8)
    ax.plot(years, hybrid_curve, color='#2ca02c', linewidth=3, 
           label='Hybrid AI', alpha=0.8)
    
    # Add transition arrows and annotations
    # Symbolic to Statistical transition
    ax.annotate('', xy=(2000, 800), xytext=(1995, 900),
                arrowprops=dict(arrowstyle='->', lw=2, color='red', alpha=0.7))
    ax.text(1997, 850, 'Paradigm\nTransition', fontsize=10, ha='center', 
            bbox=dict(boxstyle="round,pad=0.3", facecolor='lightcoral', alpha=0.7))
    
    # Statistical to Hybrid transition
    ax.annotate('', xy=(2020, 600), xytext=(2015, 1200),
                arrowprops=dict(arrowstyle='->', lw=2, color='red', alpha=0.7))
    ax.text(2017, 900, 'Paradigm\nTransition', fontsize=10, ha='center',
            bbox=dict(boxstyle="round,pad=0.3", facecolor='lightcoral', alpha=0.7))
    
    # Add phase labels
    # Symbolic AI phases
    ax.text(1970, 200, 'Growth', fontsize=9, ha='center', style='italic', color='#1f77b4')
    ax.text(1985, 500, 'Maturity', fontsize=9, ha='center', style='italic', color='#1f77b4')
    ax.text(2010, 950, 'Saturation', fontsize=9, ha='center', style='italic', color='#1f77b4')
    
    # Statistical AI phases
    ax.text(1990, 100, 'Emergence', fontsize=9, ha='center', style='italic', color='#ff7f0e')
    ax.text(2005, 750, 'Growth', fontsize=9, ha='center', style='italic', color='#ff7f0e')
    ax.text(2025, 1400, 'Dominance', fontsize=9, ha='center', style='italic', color='#ff7f0e')
    
    # Hybrid AI phases
    ax.text(2010, 50, 'Emergence', fontsize=9, ha='center', style='italic', color='#2ca02c')
    ax.text(2020, 400, 'Exponential\nGrowth', fontsize=9, ha='center', style='italic', color='#2ca02c')
    
    # Add vertical lines for key transition points
    ax.axvline(x=2005, color='gray', linestyle='--', alpha=0.5, linewidth=1)
    ax.text(2005, 1600, '2005\nSymbolic AI\nInflection', fontsize=8, ha='center', 
            bbox=dict(boxstyle="round,pad=0.2", facecolor='lightgray', alpha=0.7))
    
    ax.axvline(x=2020, color='gray', linestyle='--', alpha=0.5, linewidth=1)
    ax.text(2020, 1600, '2020\nHybrid AI\nInflection', fontsize=8, ha='center',
            bbox=dict(boxstyle="round,pad=0.2", facecolor='lightgray', alpha=0.7))
    
    # Add Kurzweil's law annotation
    ax.text(1960, 1400, "Kurzweil's Law of Accelerating Returns:\n\"Each paradigm creates the next\"", 
            fontsize=11, ha='left', va='top',
            bbox=dict(boxstyle="round,pad=0.5", facecolor='lightyellow', alpha=0.8))
    
    # Customize the plot
    ax.set_xlabel('Year', fontweight='bold')
    ax.set_ylabel('Research Activity (Conceptual Scale)', fontweight='bold')
    ax.set_xlim(1950, 2030)
    ax.set_ylim(0, 1700)
    ax.grid(True, alpha=0.3)
    ax.legend(loc='upper left', frameon=True, fancybox=True, shadow=True)
    
    # No title (removed for publication)
    
    # Adjust layout
    plt.tight_layout()
    
    # Save the figure
    output_path = '/home/ubuntu/ai_paradigm_transitions.png'
    plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor='white')
    print(f"Paradigm transition figure saved to: {output_path}")
    
    return output_path

if __name__ == "__main__":
    create_paradigm_transition_figure()

