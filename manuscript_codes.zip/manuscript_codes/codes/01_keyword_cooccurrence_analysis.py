#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from collections import Counter, defaultdict
import seaborn as sns
from matplotlib_venn import venn3
import warnings
warnings.filterwarnings('ignore')

def extract_keywords_from_json(file_path, paradigm_name):
    """Extract keywords from JSON file"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        keywords = []
        for result in data.get('results', []):
            # Extract keywords from concepts
            concepts = result.get('concepts', [])
            for concept in concepts:
                keyword = concept.get('display_name', '').lower().strip()
                if keyword and len(keyword) > 2:  # Filter out very short keywords
                    keywords.append(keyword)
            
            # Extract keywords from topics
            topics = result.get('topics', [])
            for topic in topics:
                topic_name = topic.get('display_name', '').lower().strip()
                if topic_name and len(topic_name) > 2:
                    keywords.append(topic_name)
        
        return keywords
    except Exception as e:
        print(f"Error reading {file_path}: {e}")
        return []

def create_figure1_heatmap(symbolic_keywords, statistical_keywords, hybrid_keywords):
    """Create Figure 1: Keyword Occurrence Frequencies Heatmap"""
    
    # Count keywords for each paradigm
    symbolic_counts = Counter(symbolic_keywords)
    statistical_counts = Counter(statistical_keywords)
    hybrid_counts = Counter(hybrid_keywords)
    
    # Get top 20 most common keywords across all paradigms
    all_keywords = set(list(symbolic_counts.keys()) + 
                      list(statistical_counts.keys()) + 
                      list(hybrid_counts.keys()))
    
    # Calculate total occurrences for each keyword
    keyword_totals = {}
    for keyword in all_keywords:
        total = (symbolic_counts.get(keyword, 0) + 
                statistical_counts.get(keyword, 0) + 
                hybrid_counts.get(keyword, 0))
        keyword_totals[keyword] = total
    
    # Get top 20 keywords
    top_keywords = sorted(keyword_totals.items(), key=lambda x: x[1], reverse=True)[:20]
    top_keyword_names = [item[0] for item in top_keywords]
    
    # Create data matrix
    data_matrix = []
    paradigms = ['Hybrid AI', 'Statistical AI', 'Symbolic AI']
    
    for keyword in top_keyword_names:
        row = [
            hybrid_counts.get(keyword, 0),
            statistical_counts.get(keyword, 0),
            symbolic_counts.get(keyword, 0)
        ]
        data_matrix.append(row)
    
    # Create heatmap
    fig, ax = plt.subplots(figsize=(12, 10))
    
    # Convert to numpy array
    data_array = np.array(data_matrix)
    
    # Create heatmap
    im = ax.imshow(data_array, cmap='Blues', aspect='auto')
    
    # Set ticks and labels
    ax.set_xticks(np.arange(len(paradigms)))
    ax.set_yticks(np.arange(len(top_keyword_names)))
    ax.set_xticklabels(paradigms, fontsize=12, fontweight='bold')
    ax.set_yticklabels(top_keyword_names, fontsize=11)
    
    # Add text annotations
    for i in range(len(top_keyword_names)):
        for j in range(len(paradigms)):
            text = ax.text(j, i, int(data_array[i, j]),
                          ha="center", va="center", color="white" if data_array[i, j] > data_array.max()/2 else "black",
                          fontweight='bold', fontsize=10)
    
    # Add colorbar
    cbar = plt.colorbar(im, ax=ax, shrink=0.8)
    cbar.set_label('Occurrences', fontsize=12, fontweight='bold')
    
    # Set labels
    ax.set_xlabel('AI Paradigm', fontsize=14, fontweight='bold')
    ax.set_ylabel('Keywords', fontsize=14, fontweight='bold')
    
    # Adjust layout
    plt.tight_layout()
    
    # Save figure
    plt.savefig('/home/ubuntu/figure1_keyword_heatmap.png', dpi=300, bbox_inches='tight', facecolor='white')
    plt.close()
    
    return top_keyword_names, data_matrix

def create_figure2_venn_diagram(symbolic_keywords, statistical_keywords, hybrid_keywords):
    """Create Figure 2: Venn Diagram of Keyword Overlap"""
    
    # Convert to sets
    symbolic_set = set(symbolic_keywords)
    statistical_set = set(statistical_keywords)
    hybrid_set = set(hybrid_keywords)
    
    # Create Venn diagram
    fig, ax = plt.subplots(figsize=(10, 8))
    
    # Create venn diagram
    venn = venn3([symbolic_set, statistical_set, hybrid_set], 
                 ('Symbolic AI', 'Statistical AI', 'Hybrid AI'),
                 ax=ax)
    
    # Customize colors
    if venn.get_patch_by_id('100'):
        venn.get_patch_by_id('100').set_color('#ffb3ba')  # Light red
    if venn.get_patch_by_id('010'):
        venn.get_patch_by_id('010').set_color('#bae1ff')  # Light blue
    if venn.get_patch_by_id('001'):
        venn.get_patch_by_id('001').set_color('#baffc9')  # Light green
    if venn.get_patch_by_id('110'):
        venn.get_patch_by_id('110').set_color('#ffffba')  # Light yellow
    if venn.get_patch_by_id('101'):
        venn.get_patch_by_id('101').set_color('#ffdfba')  # Light orange
    if venn.get_patch_by_id('011'):
        venn.get_patch_by_id('011').set_color('#e0bbff')  # Light purple
    if venn.get_patch_by_id('111'):
        venn.get_patch_by_id('111').set_color('#d3d3d3')  # Light gray
    
    # Set font sizes
    for text in venn.set_labels:
        if text:
            text.set_fontsize(14)
            text.set_fontweight('bold')
    
    for text in venn.subset_labels:
        if text:
            text.set_fontsize(12)
            text.set_fontweight('bold')
    
    plt.tight_layout()
    
    # Save figure
    plt.savefig('/home/ubuntu/figure2_venn_diagram.png', dpi=300, bbox_inches='tight', facecolor='white')
    plt.close()

def create_figure3_overlap_matrix(symbolic_keywords, statistical_keywords, hybrid_keywords):
    """Create Figure 3: Conceptual Overlap Matrix"""
    
    # Get unique keywords from all paradigms
    all_keywords = list(set(symbolic_keywords + statistical_keywords + hybrid_keywords))
    
    # Count occurrences for each paradigm
    symbolic_counts = Counter(symbolic_keywords)
    statistical_counts = Counter(statistical_keywords)
    hybrid_counts = Counter(hybrid_keywords)
    
    # Filter to get keywords that appear in at least one paradigm with reasonable frequency
    min_frequency = 5  # Minimum frequency threshold
    filtered_keywords = []
    
    for keyword in all_keywords:
        total_freq = (symbolic_counts.get(keyword, 0) + 
                     statistical_counts.get(keyword, 0) + 
                     hybrid_counts.get(keyword, 0))
        if total_freq >= min_frequency:
            filtered_keywords.append(keyword)
    
    # Sort by total frequency and take top 25
    keyword_totals = {}
    for keyword in filtered_keywords:
        total = (symbolic_counts.get(keyword, 0) + 
                statistical_counts.get(keyword, 0) + 
                hybrid_counts.get(keyword, 0))
        keyword_totals[keyword] = total
    
    top_keywords = sorted(keyword_totals.items(), key=lambda x: x[1], reverse=True)[:25]
    selected_keywords = [item[0] for item in top_keywords]
    
    # Create binary matrix (1 if keyword exists in paradigm, 0 otherwise)
    paradigms = ['Symbolic AI', 'Hybrid AI', 'Statistical AI']
    matrix_data = []
    
    for keyword in selected_keywords:
        row = []
        # Symbolic AI
        row.append(1 if symbolic_counts.get(keyword, 0) > 0 else 0)
        # Hybrid AI  
        row.append(1 if hybrid_counts.get(keyword, 0) > 0 else 0)
        # Statistical AI
        row.append(1 if statistical_counts.get(keyword, 0) > 0 else 0)
        matrix_data.append(row)
    
    # Create heatmap
    fig, ax = plt.subplots(figsize=(8, 12))
    
    # Convert to numpy array
    matrix_array = np.array(matrix_data)
    
    # Create heatmap with green color scheme
    im = ax.imshow(matrix_array, cmap='Greens', aspect='auto', vmin=0, vmax=1)
    
    # Set ticks and labels
    ax.set_xticks(np.arange(len(paradigms)))
    ax.set_yticks(np.arange(len(selected_keywords)))
    ax.set_xticklabels(paradigms, fontsize=12, fontweight='bold')
    ax.set_yticklabels(selected_keywords, fontsize=10)
    
    # Add text annotations
    for i in range(len(selected_keywords)):
        for j in range(len(paradigms)):
            text = ax.text(j, i, int(matrix_array[i, j]),
                          ha="center", va="center", 
                          color="white" if matrix_array[i, j] > 0.5 else "black",
                          fontweight='bold', fontsize=12)
    
    # Remove colorbar for cleaner look
    # Add grid
    ax.set_xticks(np.arange(len(paradigms)+1)-.5, minor=True)
    ax.set_yticks(np.arange(len(selected_keywords)+1)-.5, minor=True)
    ax.grid(which="minor", color="white", linestyle='-', linewidth=2)
    
    plt.tight_layout()
    
    # Save figure
    plt.savefig('/home/ubuntu/figure3_overlap_matrix.png', dpi=300, bbox_inches='tight', facecolor='white')
    plt.close()

def main():
    """Main function to create all figures"""
    print("Creating keyword analysis figures from JSON data...")
    
    # Extract keywords from each JSON file
    print("Extracting keywords from JSON files...")
    symbolic_keywords = extract_keywords_from_json('/home/ubuntu/upload/works_sembolic.json', 'Symbolic AI')
    statistical_keywords = extract_keywords_from_json('/home/ubuntu/upload/works_statical.json', 'Statistical AI')
    hybrid_keywords = extract_keywords_from_json('/home/ubuntu/upload/works_hibrit.json', 'Hybrid AI')
    
    print(f"Extracted keywords:")
    print(f"  Symbolic AI: {len(symbolic_keywords)} keywords")
    print(f"  Statistical AI: {len(statistical_keywords)} keywords")
    print(f"  Hybrid AI: {len(hybrid_keywords)} keywords")
    
    # Create Figure 1: Keyword Heatmap
    print("Creating Figure 1: Keyword Occurrence Frequencies Heatmap...")
    top_keywords, data_matrix = create_figure1_heatmap(symbolic_keywords, statistical_keywords, hybrid_keywords)
    
    # Create Figure 2: Venn Diagram
    print("Creating Figure 2: Venn Diagram...")
    create_figure2_venn_diagram(symbolic_keywords, statistical_keywords, hybrid_keywords)
    
    # Create Figure 3: Overlap Matrix
    print("Creating Figure 3: Conceptual Overlap Matrix...")
    create_figure3_overlap_matrix(symbolic_keywords, statistical_keywords, hybrid_keywords)
    
    print("✅ All figures created successfully!")
    print("Files saved:")
    print("  - figure1_keyword_heatmap.png")
    print("  - figure2_venn_diagram.png") 
    print("  - figure3_overlap_matrix.png")

if __name__ == "__main__":
    main()

