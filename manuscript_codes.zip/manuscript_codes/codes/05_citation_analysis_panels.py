#!/usr/bin/env python3
"""
Citation Analysis Visualization Generator
Tablolardan en can alıcı grafikleri paneller halinde oluşturur
"""

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from matplotlib.patches import Wedge
import matplotlib.patches as mpatches

def create_data_from_tables():
    """Tablolardan veri oluşturur"""
    print("📊 Tablo verilerinden grafik verileri hazırlanıyor...")
    
    # Ana tablo verisi
    data = {
        'AI Paradigm': ['Statistical AI', 'Symbolic AI', 'Hybrid AI'],
        'Publications (N)': [5934, 5172, 681],
        'Total Citations': [3028522, 894861, 91026],
        'Mean Citations': [510.4, 173.0, 133.7],
        'H-Index': [727, 366, 146],
        'Very High Impact (≥10K)': [40, 5, 0],
        'High Impact (1K-10K)': [509, 121, 12],
        'Medium Impact (100-999)': [2437, 1262, 190],
        'Low Impact (<100)': [2948, 3784, 479],
        'Research Clusters': [64, 34, 41],
        'Active Years': [61, 68, 26]
    }
    
    df = pd.DataFrame(data)
    
    # Paradigm dominance verisi
    dominance_data = {
        'AI Paradigm': ['Statistical AI', 'Symbolic AI', 'Hybrid AI'],
        'Citations': [3028522, 894861, 91026],
        'Percentage': [75.4, 22.3, 2.3]
    }
    
    dominance_df = pd.DataFrame(dominance_data)
    
    print("✅ Veri hazırlığı tamamlandı")
    return df, dominance_df

def create_citation_analysis_panels():
    """Citation analizi panelleri oluşturur"""
    print("🎨 Citation analizi görselleştirme panelleri oluşturuluyor...")
    
    # Veriyi hazırla
    df, dominance_df = create_data_from_tables()
    
    # Figure ve subplots oluştur
    fig, axes = plt.subplots(2, 3, figsize=(18, 12))
    fig.patch.set_facecolor('white')
    
    # Renk paleti
    colors = ['#2E86AB', '#A23B72', '#F18F01']  # Mavi, Mor, Turuncu
    paradigms = df['AI Paradigm'].tolist()
    
    # Panel (a): Paradigm Dominance (Pie Chart)
    ax1 = axes[0, 0]
    wedges, texts, autotexts = ax1.pie(dominance_df['Percentage'], 
                                      labels=dominance_df['AI Paradigm'],
                                      colors=colors,
                                      autopct='%1.1f%%',
                                      startangle=90,
                                      textprops={'fontsize': 10})
    
    ax1.set_title('(a) Paradigm Citation Dominance', fontsize=12, fontweight='bold', pad=20)
    
    # Panel (b): Publications vs Total Citations (Scatter Plot)
    ax2 = axes[0, 1]
    scatter = ax2.scatter(df['Publications (N)'], df['Total Citations'], 
                         c=colors, s=200, alpha=0.7, edgecolors='black', linewidth=1)
    
    # Paradigm labels
    for i, paradigm in enumerate(paradigms):
        ax2.annotate(paradigm.replace(' AI', ''), 
                    (df['Publications (N)'].iloc[i], df['Total Citations'].iloc[i]),
                    xytext=(10, 10), textcoords='offset points',
                    fontsize=9, fontweight='bold')
    
    ax2.set_xlabel('Publications (N)', fontsize=10, fontweight='bold')
    ax2.set_ylabel('Total Citations', fontsize=10, fontweight='bold')
    ax2.set_title('(b) Publications vs Total Citations', fontsize=12, fontweight='bold', pad=20)
    ax2.grid(True, alpha=0.3)
    
    # Y-axis formatting
    ax2.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, p: f'{x/1e6:.1f}M'))
    ax2.xaxis.set_major_formatter(plt.FuncFormatter(lambda x, p: f'{x/1e3:.1f}K'))
    
    # Panel (c): H-Index Comparison (Bar Chart)
    ax3 = axes[0, 2]
    bars = ax3.bar(paradigms, df['H-Index'], color=colors, alpha=0.8, edgecolor='black', linewidth=1)
    
    # Value labels on bars
    for i, bar in enumerate(bars):
        height = bar.get_height()
        ax3.text(bar.get_x() + bar.get_width()/2., height + 10,
                f'{int(height)}', ha='center', va='bottom', fontweight='bold', fontsize=10)
    
    ax3.set_ylabel('H-Index', fontsize=10, fontweight='bold')
    ax3.set_title('(c) H-Index by Paradigm', fontsize=12, fontweight='bold', pad=20)
    ax3.set_xticklabels([p.replace(' AI', '') for p in paradigms], rotation=0)
    ax3.grid(True, alpha=0.3, axis='y')
    
    # Panel (d): Impact Categories Distribution (Stacked Bar)
    ax4 = axes[1, 0]
    
    impact_categories = ['Very High Impact (≥10K)', 'High Impact (1K-10K)', 
                        'Medium Impact (100-999)', 'Low Impact (<100)']
    impact_colors = ['#8B0000', '#FF4500', '#FFD700', '#90EE90']  # Dark red to light green
    
    bottom = np.zeros(len(paradigms))
    
    for i, category in enumerate(impact_categories):
        values = df[category].values
        bars = ax4.bar(paradigms, values, bottom=bottom, 
                      color=impact_colors[i], alpha=0.8, 
                      label=category.replace(' Impact', '').replace(' (', '\n('),
                      edgecolor='black', linewidth=0.5)
        bottom += values
    
    ax4.set_ylabel('Number of Publications', fontsize=10, fontweight='bold')
    ax4.set_title('(d) Impact Categories Distribution', fontsize=12, fontweight='bold', pad=20)
    ax4.set_xticklabels([p.replace(' AI', '') for p in paradigms], rotation=0)
    ax4.legend(bbox_to_anchor=(1.05, 1), loc='upper left', fontsize=8)
    ax4.grid(True, alpha=0.3, axis='y')
    
    # Panel (e): Mean Citations vs Research Clusters (Bubble Chart)
    ax5 = axes[1, 1]
    
    # Bubble sizes based on publications
    sizes = (df['Publications (N)'] / df['Publications (N)'].max() * 1000)
    
    scatter = ax5.scatter(df['Research Clusters'], df['Mean Citations'], 
                         s=sizes, c=colors, alpha=0.6, edgecolors='black', linewidth=1)
    
    # Paradigm labels
    for i, paradigm in enumerate(paradigms):
        ax5.annotate(paradigm.replace(' AI', ''), 
                    (df['Research Clusters'].iloc[i], df['Mean Citations'].iloc[i]),
                    xytext=(10, 10), textcoords='offset points',
                    fontsize=9, fontweight='bold')
    
    ax5.set_xlabel('Research Clusters', fontsize=10, fontweight='bold')
    ax5.set_ylabel('Mean Citations', fontsize=10, fontweight='bold')
    ax5.set_title('(e) Mean Citations vs Research Clusters', fontsize=12, fontweight='bold', pad=20)
    ax5.grid(True, alpha=0.3)
    
    # Bubble size legend
    legend_sizes = [1000, 3000, 6000]
    legend_labels = ['1K', '3K', '6K']
    legend_bubbles = []
    for size in legend_sizes:
        legend_bubbles.append(plt.scatter([], [], s=size/6, c='gray', alpha=0.6))
    
    legend1 = ax5.legend(legend_bubbles, legend_labels, 
                        title='Publications', loc='upper right', 
                        title_fontsize=8, fontsize=8)
    ax5.add_artist(legend1)
    
    # Panel (f): Temporal Coverage (Bar Chart)
    ax6 = axes[1, 2]
    
    bars = ax6.bar(paradigms, df['Active Years'], color=colors, alpha=0.8, 
                  edgecolor='black', linewidth=1)
    
    # Value labels on bars
    for i, bar in enumerate(bars):
        height = bar.get_height()
        ax6.text(bar.get_x() + bar.get_width()/2., height + 1,
                f'{int(height)} years', ha='center', va='bottom', 
                fontweight='bold', fontsize=10)
    
    ax6.set_ylabel('Active Years', fontsize=10, fontweight='bold')
    ax6.set_title('(f) Temporal Coverage by Paradigm', fontsize=12, fontweight='bold', pad=20)
    ax6.set_xticklabels([p.replace(' AI', '') for p in paradigms], rotation=0)
    ax6.grid(True, alpha=0.3, axis='y')
    
    # Layout ayarlaması
    plt.tight_layout(pad=3.0)
    
    # Dosyayı kaydet
    output_file = '/home/ubuntu/citation_analysis_visualization_panels.png'
    plt.savefig(output_file, dpi=300, bbox_inches='tight', 
                facecolor='white', edgecolor='none')
    
    print(f"✅ Görselleştirme başarıyla kaydedildi: {output_file}")
    
    # Veri doğruluğunu kontrol et
    print(f"\n🔍 VERİ DOĞRULUK KONTROLÜ:")
    print(f"📊 Statistical AI - Publications: {df.loc[0, 'Publications (N)']} (Tablo: 5,934)")
    print(f"📊 Statistical AI - Total Citations: {df.loc[0, 'Total Citations']:,} (Tablo: 3,028,522)")
    print(f"📊 Statistical AI - H-Index: {df.loc[0, 'H-Index']} (Tablo: 727)")
    print(f"📊 Symbolic AI - Publications: {df.loc[1, 'Publications (N)']} (Tablo: 5,172)")
    print(f"📊 Hybrid AI - Publications: {df.loc[2, 'Publications (N)']} (Tablo: 681)")
    print(f"📊 Dominance - Statistical AI: {dominance_df.loc[0, 'Percentage']}% (Tablo: 75.4%)")
    
    return output_file

def main():
    """Ana fonksiyon"""
    print("🎨 Citation Analysis Visualization Generator")
    print("="*60)
    
    # Görselleştirme oluştur
    output_file = create_citation_analysis_panels()
    
    print(f"\n✅ Citation Analysis Visualization tamamlandı!")
    print(f"📄 Çıktı dosyası: {output_file}")
    print(f"🎯 Panel sayısı: 6 (2x3 grid)")
    print(f"📊 İçerik:")
    print(f"   (a) Paradigm Citation Dominance - Pie chart")
    print(f"   (b) Publications vs Total Citations - Scatter plot")
    print(f"   (c) H-Index by Paradigm - Bar chart")
    print(f"   (d) Impact Categories Distribution - Stacked bar")
    print(f"   (e) Mean Citations vs Research Clusters - Bubble chart")
    print(f"   (f) Temporal Coverage by Paradigm - Bar chart")
    print(f"🎨 Format: İngilizce, 300 DPI, ana başlıksız, okunaklı")

if __name__ == "__main__":
    main()

