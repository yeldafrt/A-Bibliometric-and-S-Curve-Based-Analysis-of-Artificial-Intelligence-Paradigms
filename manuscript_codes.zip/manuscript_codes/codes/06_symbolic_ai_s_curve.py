#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Symbolic AI S-Curve Analysis
Ekteki görsel formatında 4 panelli S-eğrisi analizi
"""

import json
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
from scipy.stats import linregress
import os
import glob
from collections import defaultdict
import warnings
warnings.filterwarnings('ignore')

# Set matplotlib parameters for better visualization
plt.rcParams['figure.figsize'] = (16, 12)
plt.rcParams['font.size'] = 12
plt.rcParams['axes.titlesize'] = 14
plt.rcParams['axes.labelsize'] = 12
plt.rcParams['xtick.labelsize'] = 10
plt.rcParams['ytick.labelsize'] = 10
plt.rcParams['legend.fontsize'] = 10

def load_symbolic_ai_data():
    """Load all Symbolic AI JSON files and extract publication data"""
    data_dir = "/home/ubuntu/upload/json_cititation/1956-2024_sembolic_json/"
    json_files = glob.glob(os.path.join(data_dir, "*.json"))
    
    all_publications = []
    
    for file_path in json_files:
        print(f"Loading: {os.path.basename(file_path)}")
        try:
            with open(file_path, 'r', encoding='utf-8-sig') as f:
                data = json.load(f)
                
            # Extract publications from network items
            if 'network' in data and 'items' in data['network']:
                for item in data['network']['items']:
                    pub_data = {
                        'id': item.get('id'),
                        'label': item.get('label', ''),
                        'year': item.get('scores', {}).get('Pub. year', 0),
                        'citations': item.get('scores', {}).get('Citations', 0),
                        'norm_citations': item.get('scores', {}).get('Norm. citations', 0),
                        'cluster': item.get('cluster', 0)
                    }
                    
                    # Only include valid years
                    if pub_data['year'] >= 1956 and pub_data['year'] <= 2024:
                        all_publications.append(pub_data)
                        
        except Exception as e:
            print(f"Error loading {file_path}: {e}")
            continue
    
    return pd.DataFrame(all_publications)

def s_curve_function(x, L, k, x0):
    """Logistic S-curve function"""
    return L / (1 + np.exp(-k * (x - x0)))

def fit_s_curve(years, cumulative_data):
    """Fit S-curve to cumulative data"""
    try:
        # Initial parameter estimates
        L_init = max(cumulative_data) * 1.1  # Carrying capacity
        k_init = 0.1  # Growth rate
        x0_init = np.median(years)  # Inflection point
        
        # Fit the curve
        popt, pcov = curve_fit(
            s_curve_function, 
            years, 
            cumulative_data,
            p0=[L_init, k_init, x0_init],
            maxfev=5000,
            bounds=([0, 0, min(years)], [np.inf, 1, max(years)])
        )
        
        # Calculate R-squared
        y_pred = s_curve_function(years, *popt)
        ss_res = np.sum((cumulative_data - y_pred) ** 2)
        ss_tot = np.sum((cumulative_data - np.mean(cumulative_data)) ** 2)
        r_squared = 1 - (ss_res / ss_tot)
        
        return popt, r_squared
    except Exception as e:
        print(f"S-curve fitting error: {e}")
        return None, 0

def calculate_growth_rate(annual_counts):
    """Calculate year-over-year growth rate"""
    growth_rates = []
    years = sorted(annual_counts.keys())
    
    for i in range(1, len(years)):
        prev_year = years[i-1]
        curr_year = years[i]
        
        if annual_counts[prev_year] > 0:
            growth_rate = (annual_counts[curr_year] - annual_counts[prev_year]) / annual_counts[prev_year]
        else:
            growth_rate = 0
        
        growth_rates.append((curr_year, growth_rate))
    
    return growth_rates

def create_symbolic_ai_s_curve_analysis():
    """Create 4-panel S-curve analysis for Symbolic AI"""
    
    # Load data
    print("Loading Symbolic AI data...")
    df = load_symbolic_ai_data()
    
    if df.empty:
        print("No data loaded!")
        return
    
    print(f"Loaded {len(df)} publications from {df['year'].min()} to {df['year'].max()}")
    
    # Prepare data for analysis
    annual_counts = df.groupby('year').size().to_dict()
    annual_citations = df.groupby('year')['citations'].sum().to_dict()
    
    # Fill missing years with 0
    all_years = range(1956, 2025)
    for year in all_years:
        if year not in annual_counts:
            annual_counts[year] = 0
        if year not in annual_citations:
            annual_citations[year] = 0
    
    # Calculate cumulative data
    years = sorted(annual_counts.keys())
    cumulative_pubs = np.cumsum([annual_counts[year] for year in years])
    cumulative_citations = np.cumsum([annual_citations[year] for year in years])
    
    # Fit S-curves
    pub_params, pub_r2 = fit_s_curve(years, cumulative_pubs)
    cit_params, cit_r2 = fit_s_curve(years, cumulative_citations)
    
    # Calculate growth rates
    growth_rates = calculate_growth_rate(annual_counts)
    
    # Create the 4-panel plot
    fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(16, 12))
    
    # Panel (a): Publications S-Curve
    ax1.scatter(years, cumulative_pubs, color='blue', alpha=0.7, s=30, label='Actual Data')
    if pub_params is not None:
        y_fit = s_curve_function(np.array(years), *pub_params)
        ax1.plot(years, y_fit, 'r-', linewidth=2, label=f'S-Curve Fit (R² = {pub_r2:.3f})')
    ax1.set_xlabel('Year')
    ax1.set_ylabel('Cumulative Publications')
    ax1.set_title('(a) Symbolic AI Publications S-Curve (1956-2024)')
    ax1.legend()
    ax1.grid(True, alpha=0.3)
    ax1.set_xlim(1955, 2025)
    
    # Panel (b): Annual Publications
    years_with_data = [year for year in years if annual_counts[year] > 0]
    counts_with_data = [annual_counts[year] for year in years_with_data]
    ax2.bar(years_with_data, counts_with_data, color='green', alpha=0.7, width=0.8)
    ax2.set_xlabel('Year')
    ax2.set_ylabel('Annual Publications')
    ax2.set_title('(b) Annual Symbolic AI Publications')
    ax2.grid(True, alpha=0.3)
    ax2.set_xlim(1955, 2025)
    
    # Panel (c): Citations S-Curve
    ax3.scatter(years, cumulative_citations, color='orange', alpha=0.7, s=30, label='Actual Data')
    if cit_params is not None:
        y_fit_cit = s_curve_function(np.array(years), *cit_params)
        ax3.plot(years, y_fit_cit, 'r-', linewidth=2, label=f'S-Curve Fit (R² = {cit_r2:.3f})')
    ax3.set_xlabel('Year')
    ax3.set_ylabel('Cumulative Citations')
    ax3.set_title('(c) Symbolic AI Citations S-Curve (1956-2024)')
    ax3.legend()
    ax3.grid(True, alpha=0.3)
    ax3.set_xlim(1955, 2025)
    
    # Panel (d): Publication Growth Rate
    if growth_rates:
        growth_years, growth_values = zip(*growth_rates)
        ax4.plot(growth_years, growth_values, color='purple', linewidth=2, marker='o', markersize=4)
        ax4.axhline(y=0, color='black', linestyle='--', alpha=0.5)
    ax4.set_xlabel('Year')
    ax4.set_ylabel('Publication Growth Rate')
    ax4.set_title('(d) Symbolic AI Publication Growth Rate')
    ax4.grid(True, alpha=0.3)
    ax4.set_xlim(1955, 2025)
    
    # Adjust layout
    plt.tight_layout()
    
    # Save the plot
    output_path = '/home/ubuntu/symbolic_ai_s_curve_analysis_new.png'
    plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor='white')
    print(f"S-curve analysis saved to: {output_path}")
    
    # Print summary statistics
    print("\n=== SYMBOLIC AI S-CURVE ANALYSIS SUMMARY ===")
    print(f"Total Publications: {len(df):,}")
    print(f"Year Range: {df['year'].min():.0f} - {df['year'].max():.0f}")
    print(f"Total Citations: {df['citations'].sum():,}")
    print(f"Average Citations per Publication: {df['citations'].mean():.1f}")
    
    if pub_params is not None:
        print(f"\nPublications S-Curve Parameters:")
        print(f"  Carrying Capacity (L): {pub_params[0]:.0f}")
        print(f"  Growth Rate (k): {pub_params[1]:.4f}")
        print(f"  Inflection Point (x0): {pub_params[2]:.1f}")
        print(f"  R-squared: {pub_r2:.3f}")
    
    if cit_params is not None:
        print(f"\nCitations S-Curve Parameters:")
        print(f"  Carrying Capacity (L): {cit_params[0]:,.0f}")
        print(f"  Growth Rate (k): {cit_params[1]:.4f}")
        print(f"  Inflection Point (x0): {cit_params[2]:.1f}")
        print(f"  R-squared: {cit_r2:.3f}")
    
    # Peak publication years
    peak_year = max(annual_counts.keys(), key=lambda x: annual_counts[x])
    print(f"\nPeak Publication Year: {peak_year} ({annual_counts[peak_year]} publications)")
    
    return output_path

if __name__ == "__main__":
    create_symbolic_ai_s_curve_analysis()

