import json
import re
import os

excel_path = '/home/ubuntu/upload/kaan_dergi/supplementary/citation_analysis_tables.xlsx'
hybrid_json_path = '/home/ubuntu/upload/kaan_dergi/dataset/json_cititation/1956_2024_hybrid_json/2023-2024.json'
statistical_json_dir = '/home/ubuntu/upload/kaan_dergi/dataset/json_cititation/1956_2024_statistical/'

def load_and_clean_json(file_path):
    with open(file_path, 'r', encoding='utf-8-sig') as f:
        json_string = f.read()
    cleaned_json_string = re.sub(r'[\x00-\x1f\x7f-\x9f]', '', json_string)
    try:
        json_content = json.loads(cleaned_json_string)
        return json_content.get('network', {}).get('items', [])
    except json.JSONDecodeError as e:
        print(f'Error decoding JSON from {file_path}: {e}')
        return []

# Load existing Excel data
excel_data = pd.read_excel(excel_path, sheet_name='All Citation Data')

# Load Hybrid JSON data
hybrid_json_data = load_and_clean_json(hybrid_json_path)

# Load all Statistical JSON data
statistical_json_files = [f for f in os.listdir(statistical_json_dir) if f.endswith('.json')]
all_statistical_json_data = []
for filename in statistical_json_files:
    file_path = os.path.join(statistical_json_dir, filename)
    data = load_and_clean_json(file_path)
    for item in data:
        item['source_file'] = filename  # Assign the correct filename
    all_statistical_json_data.extend(data)

# Convert JSON data to DataFrames
hybrid_df = pd.DataFrame(hybrid_json_data)
statistical_df = pd.DataFrame(all_statistical_json_data)

# Add 'paradigm' column to new dataframes
hybrid_df['paradigm'] = 'Hybrid'
statistical_df['paradigm'] = 'Statistical'

# Function to extract data from description HTML
def extract_from_description(description, field):
    if pd.isna(description):
        return None
    match = re.search(f'<td>{field}:</td><td>(.*?)</td>', description)
    return match.group(1) if match else None

# Process hybrid_df to match excel_data columns
hybrid_df['authors'] = hybrid_df['description'].apply(lambda x: extract_from_description(x, 'Authors'))
hybrid_df['title'] = hybrid_df['description'].apply(lambda x: extract_from_description(x, 'Title'))
hybrid_df['source'] = hybrid_df['description'].apply(lambda x: extract_from_description(x, 'Source'))
hybrid_df['pub_year'] = hybrid_df['description'].apply(lambda x: extract_from_description(x, 'Year')).astype(int)
hybrid_df['links'] = hybrid_df['weights'].apply(lambda x: x.get('Links', 0) if isinstance(x, dict) else 0)
hybrid_df['citations'] = hybrid_df['weights'].apply(lambda x: x.get('Citations', 0) if isinstance(x, dict) else 0)
hybrid_df['norm_citations'] = hybrid_df['weights'].apply(lambda x: x.get('Norm. citations', 0) if isinstance(x, dict) else 0)
hybrid_df['score_citations'] = hybrid_df['scores'].apply(lambda x: x.get('Citations', 0) if isinstance(x, dict) else 0)
hybrid_df['score_norm_citations'] = hybrid_df['scores'].apply(lambda x: x.get('Norm. citations', 0) if isinstance(x, dict) else 0)
hybrid_df['x_coord'] = hybrid_df['x']
hybrid_df['y_coord'] = hybrid_df['y']
hybrid_df['desc_year'] = hybrid_df['pub_year']
hybrid_df['decade'] = (hybrid_df['pub_year'] // 10) * 10
hybrid_df['year_range'] = hybrid_df['pub_year'].astype(str) + '-' + (hybrid_df['pub_year'] + 1).astype(str)
hybrid_df['source_file'] = os.path.basename(hybrid_json_path) # Set source_file for hybrid data

# Process statistical_df to match excel_data columns
statistical_df['authors'] = statistical_df['description'].apply(lambda x: extract_from_description(x, 'Authors'))
statistical_df['title'] = statistical_df['description'].apply(lambda x: extract_from_description(x, 'Title'))
statistical_df['source'] = statistical_df['description'].apply(lambda x: extract_from_description(x, 'Source'))
statistical_df['pub_year'] = statistical_df['description'].apply(lambda x: extract_from_description(x, 'Year')).astype(int)
statistical_df['links'] = statistical_df['weights'].apply(lambda x: x.get('Links', 0) if isinstance(x, dict) else 0)
statistical_df['citations'] = statistical_df['weights'].apply(lambda x: x.get('Citations', 0) if isinstance(x, dict) else 0)
statistical_df['norm_citations'] = statistical_df['weights'].apply(lambda x: x.get('Norm. citations', 0) if isinstance(x, dict) else 0)
statistical_df['score_citations'] = statistical_df['scores'].apply(lambda x: x.get('Citations', 0) if isinstance(x, dict) else 0)
statistical_df['score_norm_citations'] = statistical_df['scores'].apply(lambda x: x.get('Norm. citations', 0) if isinstance(x, dict) else 0)
statistical_df['x_coord'] = statistical_df['x']
statistical_df['y_coord'] = statistical_df['y']
statistical_df['desc_year'] = statistical_df['pub_year']
statistical_df['decade'] = (statistical_df['pub_year'] // 10) * 10
statistical_df['year_range'] = statistical_df['pub_year'].astype(str) + '-' + (statistical_df['pub_year'] + 1).astype(str)
# source_file is already set during loading for statistical_df

# Select and reorder columns to match the Excel file
columns_to_keep = [
    'paradigm', 'id', 'label', 'cluster', 'source_file', 'year_range', 'url', 
    'links', 'citations', 'norm_citations', 'pub_year', 'score_citations', 
    'score_norm_citations', 'x_coord', 'y_coord', 'authors', 'title', 'source', 
    'desc_year', 'decade'
]

hybrid_df_processed = hybrid_df[columns_to_keep]
statistical_df_processed = statistical_df[columns_to_keep]

# Filter out existing Statistical and Hybrid data from excel_data
excel_data_filtered = excel_data[~excel_data['paradigm'].isin(['Statistical', 'Hybrid'])]

# Concatenate the filtered Excel data with the new JSON data
updated_excel_data = pd.concat([excel_data_filtered, hybrid_df_processed, statistical_df_processed], ignore_index=True)

# Save the updated DataFrame back to the Excel file
with pd.ExcelWriter(excel_path, engine='openpyxl', mode='a', if_sheet_exists='replace') as writer:
    updated_excel_data.to_excel(writer, sheet_name='All Citation Data', index=False)

print('Excel file updated successfully.')

# Verify counts after update
updated_excel_data = pd.read_excel(excel_path, sheet_name='All Citation Data')
statistical_count_updated = updated_excel_data[updated_excel_data['paradigm'] == 'Statistical'].shape[0]
hybrid_count_updated = updated_excel_data[updated_excel_data['paradigm'] == 'Hybrid'].shape[0]

print(f'\nUpdated Statistical publications in Excel: {statistical_count_updated}')
print(f'Updated Hybrid publications in Excel: {hybrid_count_updated}')

# Check total count for Statistical
expected_statistical_count = 7812
if statistical_count_updated == expected_statistical_count:
    print(f'Statistical count is correct: {statistical_count_updated}')
else:
    print(f'Statistical count is incorrect. Expected {expected_statistical_count}, got {statistical_count_updated}')

# Check if Hybrid publications from 2023-2024.json are added
if hybrid_count_updated >= len(hybrid_json_data):
    print(f'Hybrid publications from 2023-2024.json appear to be added. Count: {hybrid_count_updated}')
else:
    print(f'Hybrid publications from 2023-2024.json might be incomplete. Count: {hybrid_count_updated}')