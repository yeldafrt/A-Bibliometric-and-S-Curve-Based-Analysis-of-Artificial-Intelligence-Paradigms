#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Coauthorship Analysis Tables Excel Generator
Bu script, VOSviewer JSON dosyalarından co-authorship verilerini analiz eder
ve coauthorship_analysis_tables.xlsx dosyasını oluşturur.
"""

import json
import pandas as pd
import numpy as np
from collections import defaultdict, Counter
import warnings
warnings.filterwarnings('ignore')

def load_coauthorship_data(file_path):
    """Co-authorship JSON dosyasını yükle"""
    try:
        with open(file_path, 'r', encoding='utf-8-sig') as f:
            data = json.load(f)
        print(f"✅ Co-authorship JSON dosyası başarıyla yüklendi: {file_path}")
        return data
    except Exception as e:
        print(f"❌ JSON dosyası yüklenirken hata: {e}")
        return None

def extract_coauthorship_data(data, paradigm_name):
    """Co-authorship verilerini çıkar ve analiz et"""
    
    authors_data = []
    
    if 'network' in data and 'items' in data['network']:
        items = data['network']['items']
        
        for item in items:
            # Temel bilgileri çıkar
            author_info = {
                'id': item.get('id', 0),
                'label': item.get('label', ''),
                'cluster': item.get('cluster', 0),
                'x': item.get('x', 0),
                'y': item.get('y', 0),
                'Paradigm': paradigm_name
            }
            
            # Weights bilgilerini çıkar
            if 'weights' in item:
                weights = item['weights']
                author_info['weights.Links'] = weights.get('Links', 0)
                author_info['weights.Total link strength'] = weights.get('Total link strength', 0)
                author_info['weights.Documents'] = weights.get('Documents', 0)
                author_info['weights.Citations'] = weights.get('Citations', 0)
                author_info['weights.Norm. citations'] = weights.get('Norm. citations', 0)
            
            # Scores bilgilerini çıkar
            if 'scores' in item:
                scores = item['scores']
                author_info['scores.Avg. pub. year'] = scores.get('Avg. pub. year', 0)
                author_info['scores.Avg. citations'] = scores.get('Avg. citations', 0)
                author_info['scores.Avg. norm. citations'] = scores.get('Avg. norm. citations', 0)
            
            authors_data.append(author_info)
    
    print(f"{paradigm_name}: {len(authors_data)} yazar verisi çıkarıldı")
    return authors_data

def create_table1_top_link_strength(all_authors_df):
    """Table 1: Top 15 authors by Total Link Strength"""
    
    # En yüksek link strength'e sahip 15 yazarı al
    top_authors = all_authors_df.nlargest(15, 'weights.Total link strength')[
        ['label', 'weights.Total link strength', 'Paradigm']
    ].copy()
    
    return top_authors

def create_table2_top_degree_centrality(all_authors_df):
    """Table 2: Top 15 authors by Degree Centrality (Links)"""
    
    # En yüksek degree centrality'ye sahip 15 yazarı al
    top_authors = all_authors_df.nlargest(15, 'weights.Links')[
        ['label', 'weights.Links', 'Paradigm']
    ].copy()
    
    return top_authors

def create_table3_network_summary(all_authors_df):
    """Table 3: Network Summary by Paradigm"""
    
    # Paradigma bazında özet istatistikler
    summary_stats = []
    
    for paradigm in ['Statistical AI']:#['Hybrid AI', 'Statistical AI', 'Symbolic AI']:
        paradigm_data = all_authors_df[all_authors_df['Paradigm'] == paradigm]
        
        if len(paradigm_data) > 0:
            stats = {
                'Paradigm': paradigm,
                'Total_Authors': len(paradigm_data),
                'Avg_Total_Link_Strength': paradigm_data['weights.Total link strength'].mean(),
                'Avg_Degree_Centrality': paradigm_data['weights.Links'].mean(),
                'Avg_Documents': paradigm_data['weights.Documents'].mean(),
                'Avg_Citations': paradigm_data['weights.Citations'].mean()
            }
            summary_stats.append(stats)
    
    summary_df = pd.DataFrame(summary_stats)
    return summary_df

def create_cluster_sizes_table(all_authors_df):
    """Cluster Sizes: Paradigm ve cluster bazında yazar sayıları"""
    
    cluster_stats = all_authors_df.groupby(['Paradigm', 'cluster']).size().reset_index(name='Author_Count')
    cluster_stats = cluster_stats.sort_values(['Paradigm', 'Author_Count'], ascending=[True, False])
    
    return cluster_stats

def create_coauthorship_analysis_excel(json_files):
    """Coauthorship analysis Excel dosyasını oluştur"""
    
    print("🚀 Coauthorship Analysis Tables Excel Generator")
    print("="*60)
    
    # Tüm paradigmalardan veri yükle
    all_authors_data = []
    
    for json_file, paradigm_name in json_files:
        print(f"\n📊 {paradigm_name} verisi yükleniyor...")
        data = load_coauthorship_data(json_file)
        
        if data:
            authors_data = extract_coauthorship_data(data, paradigm_name)
            all_authors_data.extend(authors_data)
    
    # DataFrame oluştur
    all_authors_df = pd.DataFrame(all_authors_data)
    
    print(f"\n📋 Toplam {len(all_authors_df)} yazar verisi işlendi")
    print(f"Paradigm dağılımı:")
    for paradigm in all_authors_df['Paradigm'].unique():
        count = len(all_authors_df[all_authors_df['Paradigm'] == paradigm])
        print(f"  - {paradigm}: {count} yazar")
    
    # Tabloları oluştur
    print(f"\n📊 Tablolar oluşturuluyor...")
    
    table1 = create_table1_top_link_strength(all_authors_df)
    print(f"✅ Table 1 - Top Link Strength: {len(table1)} kayıt")
    
    table2 = create_table2_top_degree_centrality(all_authors_df)
    print(f"✅ Table 2 - Top Degree Centrality: {len(table2)} kayıt")
    
    table3 = create_table3_network_summary(all_authors_df)
    print(f"✅ Table 3 - Network Summary: {len(table3)} kayıt")
    
    cluster_sizes = create_cluster_sizes_table(all_authors_df)
    print(f"✅ Cluster Sizes: {len(cluster_sizes)} kayıt")
    
    # Excel dosyasını oluştur
    excel_file = 'dataset/dataset/st_coauthorship_analysis_tables22.xlsx'
    
    print(f"\n💾 Excel dosyası oluşturuluyor: {excel_file}")
    
    with pd.ExcelWriter(excel_file, engine='openpyxl') as writer:
        
        # Sheet 1: Table 1 - Top Link Strength
        table1.to_excel(writer, sheet_name='Table 1 - Top Link Strength', index=False)
        
        # Sheet 2: Table 2 - Top Degree Centrality
        table2.to_excel(writer, sheet_name='Table 2 - Top Degree Centrality', index=False)
        
        # Sheet 3: Table 3 - Network Summary
        table3.to_excel(writer, sheet_name='Table 3 - Network Summary', index=False)
        
        # Sheet 4: Cluster Sizes
        cluster_sizes.to_excel(writer, sheet_name='Cluster Sizes', index=False)
        
        # Sheet 5: All Authors Raw Data
        all_authors_df.to_excel(writer, sheet_name='All Authors Raw Data', index=False)
    
    print(f"✅ Excel dosyası başarıyla oluşturuldu!")
    
    # Özet istatistikler
    print(f"\n📈 Özet İstatistikler:")
    print(f"  📄 Excel dosyası: {excel_file}")
    print(f"  📊 Sheet sayısı: 5")
    print(f"  👥 Toplam yazar: {len(all_authors_df)}")
    print(f"  🏷️ Toplam cluster: {all_authors_df['cluster'].nunique()}")
    print(f"  📚 Toplam makale: {all_authors_df['weights.Documents'].sum():.0f}")
    print(f"  📊 Toplam atıf: {all_authors_df['weights.Citations'].sum():,.0f}")
    
    # En yüksek değerler
    print(f"\n🏆 En Yüksek Değerler:")
    top_link = all_authors_df.loc[all_authors_df['weights.Total link strength'].idxmax()]
    print(f"  🔗 En yüksek Link Strength: {top_link['label']} ({top_link['weights.Total link strength']:.0f}) - {top_link['Paradigm']}")
    
    top_degree = all_authors_df.loc[all_authors_df['weights.Links'].idxmax()]
    print(f"  🎯 En yüksek Degree Centrality: {top_degree['label']} ({top_degree['weights.Links']}) - {top_degree['Paradigm']}")
    
    top_docs = all_authors_df.loc[all_authors_df['weights.Documents'].idxmax()]
    print(f"  📚 En çok makale: {top_docs['label']} ({top_docs['weights.Documents']:.0f}) - {top_docs['Paradigm']}")
    
    top_cit = all_authors_df.loc[all_authors_df['weights.Citations'].idxmax()]
    print(f"  📊 En çok atıf: {top_cit['label']} ({top_cit['weights.Citations']:,.0f}) - {top_cit['Paradigm']}")
    
    return excel_file

def main():
    """Ana fonksiyon"""
    
    # JSON dosyaları ve paradigma isimleri
    json_files = [
        #('dataset/dataset/json_co_authorship/authorship_hibrid.json', 'Hybrid AI'),
         ('dataset/dataset/json_co_authorship/authorship_statical.json', 'Statistical AI'),
        # ('dataset/dataset/json_co_authorship/authorship_sembolic.json', 'Symbolic AI')
    ]
    
    # Excel dosyasını oluştur
    excel_file = create_coauthorship_analysis_excel(json_files)
    
    print(f"\n🎯 İşlem Tamamlandı!")
    print(f"Çıktı dosyası: {excel_file}")
    
    print(f"\n📋 Excel Dosyası İçeriği:")
    print(f"  1. Table 1 - Top Link Strength: En yüksek link strength'e sahip 15 yazar")
    print(f"  2. Table 2 - Top Degree Centrality: En yüksek degree centrality'ye sahip 15 yazar")
    print(f"  3. Table 3 - Network Summary: Paradigma bazında özet istatistikler")
    print(f"  4. Cluster Sizes: Paradigma ve cluster bazında yazar sayıları")
    print(f"  5. All Authors Raw Data: Tüm yazarların ham verisi")

if __name__ == "__main__":
    main()

