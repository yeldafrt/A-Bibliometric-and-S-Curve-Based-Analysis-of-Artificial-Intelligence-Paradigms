#!/usr/bin/env python3
"""
Cross-Paradigm Authors JSON to Excel Converter
JSON dosyasını detaylı Excel tablolarına dönüştürür
"""

import json
import pandas as pd
from collections import Counter
import os

def load_json_data(file_path):
    """JSON dosyasını yükler"""
    print(f"JSON dosyası yükleniyor: {file_path}")
    
    with open(file_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    print(f"{len(data)} cross-paradigm yazar yüklendi")
    return data

def create_main_authors_table(data):
    """Ana yazarlar tablosunu oluşturur"""
    print("Ana yazarlar tablosu oluşturuluyor...")
    
    authors_list = []
    
    for author in data:
        # Paradigmaları string olarak birleştir
        paradigms_str = ', '.join(sorted(author['paradigms']))
        
        # Kurumları string olarak birleştir
        institutions_str = ', '.join(author.get('institutions', [])[:3])
        
        # Ülkeleri string olarak birleştir
        countries_str = ', '.join(sorted(author.get('countries', [])))
        
        author_row = {
            'Author ID': author['id'],
            'Author Name': author['name'],
            'Paradigms': paradigms_str,
            'Paradigm Count': author['paradigm_count'],
            'Total Works': author['total_works'],
            'Total Citations': author['total_citations'],
            'Avg Citations per Work': author['avg_citations_per_work'],
            'Career Start': author['career_start'],
            'Career End': author['career_end'],
            'Career Span (Years)': author['career_span'],
            'Primary Institutions': institutions_str,
            'Countries': countries_str
        }
        
        authors_list.append(author_row)
    
    df = pd.DataFrame(authors_list)
    print(f"Ana tablo oluşturuldu: {len(df)} satır")
    return df

def create_paradigm_combinations_table(data):
    """Paradigma kombinasyonları tablosunu oluşturur"""
    print("Paradigma kombinasyonları tablosu oluşturuluyor...")
    
    combinations = Counter()
    combination_details = {}
    
    for author in data:
        paradigms = sorted(author['paradigms'])
        
        if len(paradigms) == 2:
            combo_key = ' + '.join(paradigms)
        elif len(paradigms) == 3:
            combo_key = 'All Three Paradigms'
        else:
            combo_key = paradigms[0] if paradigms else 'Unknown'
        
        combinations[combo_key] += 1
        
        # Detayları sakla
        if combo_key not in combination_details:
            combination_details[combo_key] = {
                'total_works': 0,
                'total_citations': 0,
                'authors': []
            }
        
        combination_details[combo_key]['total_works'] += author['total_works']
        combination_details[combo_key]['total_citations'] += author['total_citations']
        combination_details[combo_key]['authors'].append(author['name'])
    
    # DataFrame oluştur
    combo_list = []
    for combo, count in combinations.most_common():
        details = combination_details[combo]
        avg_works = details['total_works'] / count if count > 0 else 0
        avg_citations = details['total_citations'] / count if count > 0 else 0
        
        combo_row = {
            'Paradigm Combination': combo,
            'Author Count': count,
            'Percentage': f"{(count/len(data)*100):.1f}%",
            'Total Works': details['total_works'],
            'Total Citations': details['total_citations'],
            'Avg Works per Author': round(avg_works, 1),
            'Avg Citations per Author': round(avg_citations, 1),
            'Sample Authors': ', '.join(details['authors'][:3])
        }
        
        combo_list.append(combo_row)
    
    df = pd.DataFrame(combo_list)
    print(f"Paradigma kombinasyonları tablosu oluşturuldu: {len(df)} satır")
    return df

def create_top_authors_tables(data):
    """En iyi yazarlar tablolarını oluşturur"""
    print("En iyi yazarlar tabloları oluşturuluyor...")
    
    # En produktif yazarlar
    top_productive = sorted(data, key=lambda x: x['total_works'], reverse=True)[:20]
    productive_list = []
    
    for i, author in enumerate(top_productive, 1):
        paradigms_str = ', '.join(sorted(author['paradigms']))
        institutions_str = ', '.join(author.get('institutions', [])[:2])
        
        productive_row = {
            'Rank': i,
            'Author Name': author['name'],
            'Total Works': author['total_works'],
            'Total Citations': author['total_citations'],
            'Avg Citations per Work': author['avg_citations_per_work'],
            'Paradigms': paradigms_str,
            'Career Span': author['career_span'],
            'Primary Institutions': institutions_str
        }
        
        productive_list.append(productive_row)
    
    df_productive = pd.DataFrame(productive_list)
    
    # En çok atıf alan yazarlar
    top_cited = sorted(data, key=lambda x: x['total_citations'], reverse=True)[:20]
    cited_list = []
    
    for i, author in enumerate(top_cited, 1):
        paradigms_str = ', '.join(sorted(author['paradigms']))
        institutions_str = ', '.join(author.get('institutions', [])[:2])
        
        cited_row = {
            'Rank': i,
            'Author Name': author['name'],
            'Total Citations': author['total_citations'],
            'Total Works': author['total_works'],
            'Avg Citations per Work': author['avg_citations_per_work'],
            'Paradigms': paradigms_str,
            'Career Span': author['career_span'],
            'Primary Institutions': institutions_str
        }
        
        cited_list.append(cited_row)
    
    df_cited = pd.DataFrame(cited_list)
    
    print(f"En produktif yazarlar tablosu: {len(df_productive)} satır")
    print(f"En çok atıf alan yazarlar tablosu: {len(df_cited)} satır")
    
    return df_productive, df_cited

def create_temporal_analysis_table(data):
    """Temporal analiz tablosunu oluşturur"""
    print("Temporal analiz tablosu oluşturuluyor...")
    
    # Yıllara göre grupla
    year_data = {}
    
    for author in data:
        start_year = author['career_start']
        if start_year > 0:
            decade = (start_year // 10) * 10
            decade_key = f"{decade}s"
            
            if decade_key not in year_data:
                year_data[decade_key] = {
                    'author_count': 0,
                    'total_works': 0,
                    'total_citations': 0,
                    'paradigm_combinations': Counter()
                }
            
            year_data[decade_key]['author_count'] += 1
            year_data[decade_key]['total_works'] += author['total_works']
            year_data[decade_key]['total_citations'] += author['total_citations']
            
            paradigms = sorted(author['paradigms'])
            if len(paradigms) == 2:
                combo = ' + '.join(paradigms)
            elif len(paradigms) == 3:
                combo = 'All Three'
            else:
                combo = paradigms[0] if paradigms else 'Unknown'
            
            year_data[decade_key]['paradigm_combinations'][combo] += 1
    
    # DataFrame oluştur
    temporal_list = []
    for decade in sorted(year_data.keys()):
        data_decade = year_data[decade]
        avg_works = data_decade['total_works'] / data_decade['author_count'] if data_decade['author_count'] > 0 else 0
        avg_citations = data_decade['total_citations'] / data_decade['author_count'] if data_decade['author_count'] > 0 else 0
        
        # En yaygın paradigma kombinasyonu
        most_common_combo = data_decade['paradigm_combinations'].most_common(1)
        top_combo = most_common_combo[0][0] if most_common_combo else 'N/A'
        
        temporal_row = {
            'Decade': decade,
            'Author Count': data_decade['author_count'],
            'Total Works': data_decade['total_works'],
            'Total Citations': data_decade['total_citations'],
            'Avg Works per Author': round(avg_works, 1),
            'Avg Citations per Author': round(avg_citations, 1),
            'Most Common Combination': top_combo
        }
        
        temporal_list.append(temporal_row)
    
    df = pd.DataFrame(temporal_list)
    print(f"Temporal analiz tablosu oluşturuldu: {len(df)} satır")
    return df

def create_institutional_analysis_table(data):
    """Kurumsal analiz tablosunu oluşturur"""
    print("Kurumsal analiz tablosu oluşturuluyor...")
    
    institution_data = {}
    
    for author in data:
        institutions = author.get('institutions', [])
        for institution in institutions[:3]:  # İlk 3 kurum
            if institution not in institution_data:
                institution_data[institution] = {
                    'author_count': 0,
                    'total_works': 0,
                    'total_citations': 0,
                    'paradigm_combinations': Counter(),
                    'authors': []
                }
            
            institution_data[institution]['author_count'] += 1
            institution_data[institution]['total_works'] += author['total_works']
            institution_data[institution]['total_citations'] += author['total_citations']
            institution_data[institution]['authors'].append(author['name'])
            
            paradigms = sorted(author['paradigms'])
            if len(paradigms) == 2:
                combo = ' + '.join(paradigms)
            elif len(paradigms) == 3:
                combo = 'All Three'
            else:
                combo = paradigms[0] if paradigms else 'Unknown'
            
            institution_data[institution]['paradigm_combinations'][combo] += 1
    
    # En az 2 yazarı olan kurumları filtrele
    filtered_institutions = {k: v for k, v in institution_data.items() if v['author_count'] >= 2}
    
    # DataFrame oluştur
    institutional_list = []
    for institution, data_inst in sorted(filtered_institutions.items(), 
                                       key=lambda x: x[1]['author_count'], reverse=True)[:30]:
        
        avg_works = data_inst['total_works'] / data_inst['author_count'] if data_inst['author_count'] > 0 else 0
        avg_citations = data_inst['total_citations'] / data_inst['author_count'] if data_inst['author_count'] > 0 else 0
        
        # En yaygın paradigma kombinasyonu
        most_common_combo = data_inst['paradigm_combinations'].most_common(1)
        top_combo = most_common_combo[0][0] if most_common_combo else 'N/A'
        
        # Örnek yazarlar
        sample_authors = ', '.join(data_inst['authors'][:3])
        
        institutional_row = {
            'Institution': institution,
            'Cross-Paradigm Authors': data_inst['author_count'],
            'Total Works': data_inst['total_works'],
            'Total Citations': data_inst['total_citations'],
            'Avg Works per Author': round(avg_works, 1),
            'Avg Citations per Author': round(avg_citations, 1),
            'Most Common Combination': top_combo,
            'Sample Authors': sample_authors
        }
        
        institutional_list.append(institutional_row)
    
    df = pd.DataFrame(institutional_list)
    print(f"Kurumsal analiz tablosu oluşturuldu: {len(df)} satır")
    return df

def create_summary_statistics_table(data):
    """Özet istatistikler tablosunu oluşturur"""
    print("Özet istatistikler tablosu oluşturuluyor...")
    
    # Genel istatistikler
    total_authors = len(data)
    total_works = sum(author['total_works'] for author in data)
    total_citations = sum(author['total_citations'] for author in data)
    
    # Paradigma sayılarına göre dağılım
    paradigm_count_dist = Counter(author['paradigm_count'] for author in data)
    
    # Kariyer span istatistikleri
    career_spans = [author['career_span'] for author in data if author['career_span'] > 0]
    avg_career_span = sum(career_spans) / len(career_spans) if career_spans else 0
    
    # Yıl aralığı
    career_starts = [author['career_start'] for author in data if author['career_start'] > 0]
    career_ends = [author['career_end'] for author in data if author['career_end'] > 0]
    
    min_year = min(career_starts) if career_starts else 0
    max_year = max(career_ends) if career_ends else 0
    
    # Özet tablosu
    summary_data = [
        {'Metric': 'Total Cross-Paradigm Authors', 'Value': total_authors},
        {'Metric': 'Total Works by Cross-Paradigm Authors', 'Value': total_works},
        {'Metric': 'Total Citations', 'Value': total_citations},
        {'Metric': 'Average Works per Author', 'Value': round(total_works/total_authors, 1)},
        {'Metric': 'Average Citations per Author', 'Value': round(total_citations/total_authors, 1)},
        {'Metric': 'Average Career Span (Years)', 'Value': round(avg_career_span, 1)},
        {'Metric': 'Earliest Career Start', 'Value': min_year},
        {'Metric': 'Latest Career End', 'Value': max_year},
        {'Metric': 'Authors with 2 Paradigms', 'Value': paradigm_count_dist.get(2, 0)},
        {'Metric': 'Authors with 3 Paradigms', 'Value': paradigm_count_dist.get(3, 0)},
    ]
    
    df = pd.DataFrame(summary_data)
    print(f"Özet istatistikler tablosu oluşturuldu: {len(df)} satır")
    return df

def save_to_excel(data, output_file):
    """Tüm tabloları Excel dosyasına kaydeder"""
    print(f"\nExcel dosyası oluşturuluyor: {output_file}")
    
    # Tabloları oluştur
    df_main = create_main_authors_table(data)
    df_combinations = create_paradigm_combinations_table(data)
    df_productive, df_cited = create_top_authors_tables(data)
    df_temporal = create_temporal_analysis_table(data)
    df_institutional = create_institutional_analysis_table(data)
    df_summary = create_summary_statistics_table(data)
    
    # Excel dosyasına kaydet
    with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
        # Ana tablolar
        df_summary.to_excel(writer, sheet_name='Summary Statistics', index=False)
        df_main.to_excel(writer, sheet_name='All Cross-Paradigm Authors', index=False)
        df_combinations.to_excel(writer, sheet_name='Paradigm Combinations', index=False)
        
        # En iyi yazarlar
        df_productive.to_excel(writer, sheet_name='Top Productive Authors', index=False)
        df_cited.to_excel(writer, sheet_name='Top Cited Authors', index=False)
        
        # Analiz tabloları
        df_temporal.to_excel(writer, sheet_name='Temporal Analysis', index=False)
        df_institutional.to_excel(writer, sheet_name='Institutional Analysis', index=False)
    
    print(f"Excel dosyası başarıyla oluşturuldu!")
    print(f"📄 Dosya konumu: {output_file}")
    
    # Sheet'lerin listesi
    sheet_names = [
        'Summary Statistics',
        'All Cross-Paradigm Authors', 
        'Paradigm Combinations',
        'Top Productive Authors',
        'Top Cited Authors',
        'Temporal Analysis',
        'Institutional Analysis'
    ]
    
    print(f"\nOluşturulan sheet'ler:")
    for i, sheet in enumerate(sheet_names, 1):
        print(f"   {i}. {sheet}")
    
    return output_file

def main():
    """Ana fonksiyon"""
    print("Cross-Paradigm Authors JSON to Excel Converter")
    print("="*60)
    
    # JSON dosyasını yükle
    json_file = "dataset/dataset/json_cross_paradigm_author/cross_paradigm_authors.json"
    
    if not os.path.exists(json_file):
        print(f"JSON dosyası bulunamadı: {json_file}")
        return
    
    data = load_json_data(json_file)
    
    # Excel dosyasına dönüştür
    output_file = "cross_paradigm_authors_analysis22.xlsx"
    save_to_excel(data, output_file)
    
    print(f"\nDönüştürme işlemi tamamlandı!")
    print(f"{len(data)} cross-paradigm yazar analiz edildi")
    print(f"Excel dosyası: {output_file}")

if __name__ == "__main__":
    main()
