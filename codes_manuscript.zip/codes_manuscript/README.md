# Complete Python Code Package for AI Paradigms Research

This comprehensive package contains all Python codes used in the research article "A Bibliometric and S-Curve-Based Analysis of Artificial Intelligence Paradigms: Evolution, Transitions, and Future Trajectories".

## Package Structure

```
makale_kodlari_complete/
├── 01_data_processing/          # Data processing and table generation
├── 02_visualization/            # Figure generation and visualization
├── README_COMPLETE.md           # This file
└── METHODOLOGY.md               # Detailed methodology
```

##  01_data_processing/ - Data Processing Pipeline

### Core Data Processing Scripts

#### `convert_json_to_excel.py`
**Purpose:** Converts raw JSON files from VOSviewer/OpenAlex to structured Excel tables
**Input:** JSON files from dataset.zip
**Output:** Structured Excel files for analysis
**Key Functions:**
- JSON parsing and cleaning
- Data structure normalization
- Excel file generation with multiple sheets

#### `create_excel_tables.py`
**Purpose:** Creates comprehensive analysis tables from processed data
**Input:** Processed JSON data
**Output:** Multi-sheet Excel files with statistical summaries
**Key Functions:**
- Cross-paradigm author analysis
- Citation metrics calculation
- Temporal analysis tables

#### `analyze_json_structure.py`
**Purpose:** Analyzes and validates JSON data structure
**Input:** Raw JSON files
**Output:** Data quality reports and structure analysis
**Key Functions:**
- Data validation
- Missing value detection
- Structure consistency checks

### Citation Analysis Scripts

#### `create_citation_summary_table.py`
**Purpose:** Generates comprehensive citation analysis tables
**Input:** Citation data from JSON files
**Output:** Citation summary Excel files
**Key Functions:**
- H-index calculations
- Impact category classification
- Paradigm-wise citation analysis

#### `create_complete_citation_table.py`
**Purpose:** Creates detailed citation analysis with all metrics
**Input:** Processed citation data
**Output:** Complete citation analysis tables
**Key Functions:**
- Normalized citation calculations
- Research cluster analysis
- Temporal citation patterns

#### `fix_complete_citation_table.py`
**Purpose:** Data cleaning and error correction for citation tables
**Input:** Raw citation tables
**Output:** Cleaned and validated citation data
**Key Functions:**
- Data consistency checks
- Error correction algorithms
- Missing data imputation

#### `analyze_top_cited_works.py`
**Purpose:** Identifies and analyzes most influential publications
**Input:** Citation data
**Output:** Top-cited works analysis
**Key Functions:**
- Citation ranking
- Impact analysis
- Paradigm influence assessment

### Supplementary Excel Generation Scripts

#### `create_cross_paradigm_excel.py`
**Purpose:** Creates cross_paradigm_authors_tables.xlsx from JSON data
**Input:** Cross-paradigm author JSON files from dataset.zip
**Output:** Multi-sheet Excel file with cross-paradigm author analysis
**Key Functions:**
- Author paradigm classification
- Temporal analysis of paradigm transitions
- Institutional analysis
- Career span calculations

#### `create_coauthorship_excel.py`
**Purpose:** Creates coauthorship_analysis_tables.xlsx from JSON data
**Input:** Co-authorship network JSON files
**Output:** Author collaboration network analysis tables
**Key Functions:**
- Network metrics calculation
- Collaboration strength analysis
- Author centrality measures
- Cluster identification

#### `create_citation_excel.py`
**Purpose:** Creates citation_analysis_tables.xlsx from JSON data
**Input:** Citation data from VOSviewer JSON files
**Output:** Comprehensive citation analysis tables
**Key Functions:**
- Citation distribution analysis
- H-index calculations by paradigm
- Impact category classification
- Temporal citation patterns

#### `create_keyword_excel.py`
**Purpose:** Creates keyword_analysis_tables.xlsx from JSON data
**Input:** Keyword co-occurrence JSON files
**Output:** Keyword analysis and co-occurrence tables
**Key Functions:**
- Keyword frequency analysis
- Co-occurrence pattern detection
- Paradigm-specific keyword extraction
- Temporal keyword evolution

## 02_visualization/ - Figure Generation

### Figure Generation Scripts (Corresponds to Article Figures)

#### `01_keyword_cooccurrence_analysis.py`
**Article Figure:** Fig. 1
**Description:** Keyword co-occurrence patterns across AI paradigms
**Output:** Comparative bar chart of keyword frequencies

#### `02_keyword_overlap_venn_diagram.py`
**Article Figure:** Fig. 2
**Description:** Keyword overlap visualization
**Output:** Venn diagram showing paradigm intersections

#### `03_author_network_analysis.py`
**Article Figure:** Fig. 6
**Description:** Author network metrics comparison
**Output:** Multi-panel network analysis visualization

#### `04_cross_paradigm_authors.py`
**Article Figure:** Fig. 10
**Description:** Cross-paradigm author dynamics (1956-2024)
**Output:** 6-panel comprehensive author analysis

#### `05_citation_analysis_panels.py`
**Article Figure:** Fig. 11
**Description:** Citation performance across paradigms
**Output:** 6-panel citation analysis visualization

#### `06_symbolic_ai_s_curve.py`
**Article Figure:** Fig. 12
**Description:** Symbolic AI S-curve analysis (1956-2024)
**Output:** 4-panel S-curve analysis

#### `07_statistical_ai_s_curve.py`
**Article Figure:** Fig. 13
**Description:** Statistical AI S-curve analysis (1956-2024)
**Output:** 4-panel S-curve analysis

#### `08_hybrid_ai_s_curve.py`
**Article Figure:** Fig. 14
**Description:** Hybrid AI S-curve analysis (1997-2024)
**Output:** 4-panel S-curve analysis

#### `09_comparative_s_curves.py`
**Article Figure:** Fig. 15
**Description:** Comparative S-curve analysis of all paradigms
**Output:** Multi-paradigm S-curve comparison

#### `10_paradigm_evolution_transitions.py`
**Article Figure:** Fig. 16
**Description:** Paradigm evolution based on Kurzweil's theory
**Output:** Paradigm transition visualization

## Usage Instructions

### Prerequisites
```bash
pip install pandas numpy matplotlib seaborn scipy openpyxl json glob warnings collections
```

### Data Processing Pipeline
```bash
# Step 1: Analyze data structure
cd 01_data_processing
python3 analyze_json_structure.py

# Step 2: Convert JSON to Excel
python3 convert_json_to_excel.py

# Step 3: Create analysis tables
python3 create_excel_tables.py

# Step 4: Generate supplementary Excel files
python3 create_cross_paradigm_excel.py
python3 create_coauthorship_excel.py
python3 create_citation_excel.py
python3 create_keyword_excel.py

# Step 5: Generate citation analysis
python3 create_citation_summary_table.py
python3 create_complete_citation_table.py

# Step 6: Clean and validate
python3 fix_complete_citation_table.py

# Step 7: Analyze top works
python3 analyze_top_cited_works.py
```

### Figure Generation
```bash
# Generate all figures
cd 02_visualization
python3 01_keyword_cooccurrence_analysis.py
python3 02_keyword_overlap_venn_diagram.py
# ... continue with all visualization scripts
```

## Technical Specifications

### Data Sources
- **Primary:** JSON files from VOSviewer analysis
- **Secondary:** OpenAlex API data
- **Supplementary:** Excel tables generated from processing pipeline

### Analysis Methods
- **S-curve Modeling:** Logistic regression with scipy.optimize
- **Network Analysis:** Graph theory metrics
- **Citation Analysis:** Bibliometric indicators
- **Temporal Analysis:** Time series analysis

### Output Specifications
- **Figures:** 300 DPI, publication-ready
- **Tables:** Multi-sheet Excel format
- **Data:** JSON and CSV formats for interoperability

## Key Findings Summary

### Paradigm Characteristics
- **Symbolic AI:** 5,172 publications, inflection point 2005.1, mature phase
- **Statistical AI:** 7,812 publications, inflection point 2019.7, dominant phase
- **Hybrid AI:** 1,543 publications, inflection point 2024.0, exponential growth

### S-curve Model Performance
- **R² values:** 0.996-0.998 (excellent fit)
- **Kurzweil's theory:** Empirically validated
- **Paradigm transitions:** Systematic and predictable

## 🔬 Methodological Contributions

### Theoretical Framework
- Integration of Kurzweil's "Law of Accelerating Returns"
- S-curve analysis for paradigm evolution
- Cross-paradigm author mobility analysis

### Empirical Validation
- Large-scale bibliometric analysis (11,787+ publications)
- Multi-source data integration (VOSviewer + OpenAlex)
- Temporal analysis spanning 68 years (1956-2024)

##  Citation and Usage

When using this code package, please cite:
```
[Your Article Citation]
```

##  Reproducibility

This package ensures full reproducibility of research findings:
- Complete data processing pipeline
- All visualization codes included
- Detailed methodology documentation
- Error handling and validation scripts

## Contact

For questions about the code or methodology, please contact:
[+905053865514]

---

**Note:** This package represents a complete analytical framework for bibliometric analysis of AI paradigms and can be adapted for similar research in other technological domains.

