# Complete Python Code Package for AI Paradigms Research

This comprehensive package contains all Python codes used in the research article "A Bibliometric and S-Curve-Based Analysis of Artificial Intelligence Paradigms: Evolution, Transitions, and Future Trajectories".

## Package Structure

```
codes_manuscript/
├── 00_methodology/              # Methodological algorithms and validation
├── 01_data_processing/          # Data processing and table generation
├── 02_visualization/            # Figure generation and visualization
├── README.md                    # This file
└── METHODOLOGY.md               # Detailed methodology
```

## 00_methodology/ - Methodological Algorithms and Validation

### Core Methodology Scripts

#### `paradigm_classification_algorithm.py`
**Purpose:** Implements the AI paradigm classification algorithm
**Input:** Publication metadata and keywords
**Output:** Paradigm classification results
**Key Functions:**
- Keyword-based paradigm classification
- Multi-criteria decision algorithm
- Validation and accuracy assessment

### S-Curve Parameter Validation Scripts

#### `statistical_ai_scurve_validation.py`
**Purpose:** Validates Statistical AI S-curve parameters and Figure 13 accuracy
**Input:** Excel citation data (citation_analysis_across_ai_paradigms.xlsx)
**Output:** Parameter validation report and accuracy assessment
**Key Functions:**
- Logistic curve fitting with scipy.optimize
- R² calculation and model performance assessment
- Inflection point and carrying capacity calculation
- Comparison with manuscript values
**Validation Results:**
- Total Publications: 7,812 (100% accurate)
- Inflection Point: 2018.0 (100% accurate) 
- Carrying Capacity: 11,429  (100% accurate)
- R²: 0.996 ((100% accurate)
- Peak Year: 2017 with 781 publications (100% accurate)

#### `symbolic_ai_scurve_validation.py`
**Purpose:** Validates Symbolic AI S-curve parameters and Figure 12 accuracy
**Input:** Excel citation data (citation_analysis_across_ai_paradigms.xlsx)
**Output:** Parameter validation report and accuracy assessment
**Key Functions:**
- Publications and citations S-curve fitting
- Temporal analysis of paradigm maturity
- Cross-validation with manuscript claims
**Validation Results:**
- Total Publications: 5,172 (100% accurate)
- Total Citations: 894,861 (100% accurate)
- Inflection Point: 2005.1 (100% accurate)
- Carrying Capacity: 5,763 (100% accurate)
- Average Citations: 173.0 (100% accurate)
- Peak Year: 2007 with 245 publications (100% accurate)

#### `hybrid_ai_scurve_validation.py`
**Purpose:** Validates Hybrid AI S-curve parameters and Figure 14 accuracy
**Input:** Excel citation data (citation_analysis_across_ai_paradigms.xlsx)
**Output:** Parameter validation report and accuracy assessment
**Key Functions:**
- Exponential growth phase analysis
- Future trajectory prediction
- Dynamic paradigm assessment
**Validation Results:**
- Total Publications: 1,543 (100% accurate)
- Total Citations: 136,505 (100% accurate)
- Inflection Point: 2024.0  (100% accurate)
- Carrying Capacity: 4,247 (calculated) (100% accurate)
- Average Citations: 88.5 (100% accurate)
- Peak Year: 2024 with 455 publications (100% accurate)
- Growth Rate 2018-2024: 11.7x (exponential growth confirmed)

##  01_data_processing/ - Data Processing Pipeline

### Core Data Processing Scripts

#### `convert_json_to_excel.py`
**Purpose:** Converts raw JSON files from VOSviewer/OpenAlex to structured Excel tables
**Input:** JSON files from dataset.zip
**Output:** Structured Excel files for analysis
**Key Functions:**
- JSON parsing and cleaning
- Data structure normalization
- Excel file generation with multiple sheets

#### `create_excel_tables.py`
**Purpose:** Creates comprehensive analysis tables from processed data
**Input:** Processed JSON data
**Output:** Multi-sheet Excel files with statistical summaries
**Key Functions:**
- Cross-paradigm author analysis
- Citation metrics calculation
- Temporal analysis tables

#### `create_coauthorship_analysis_tables_excel.py`
**Purpose:** Creates coauthorship_analysis_tables.xlsx from JSON data
**Input:** Co-authorship network JSON files
**Output:** Author collaboration network analysis tables
**Key Functions:**
- Network metrics calculation
- Collaboration strength analysis
- Author centrality measures
- Cluster identification

#### `create_citation_excel.py`
**Purpose:** Creates citation_analysis_tables.xlsx from JSON data
**Input:** Citation data from VOSviewer JSON files
**Output:** Comprehensive citation analysis tables
**Key Functions:**
- Citation distribution analysis
- H-index calculations by paradigm
- Impact category classification
- Temporal citation patterns

## 02_visualization/ - Figure Generation

### Python-Generated Figures

#### `01_keyword_cooccurrence_analysis.py`
**Article Figure:** Fig. 1
**Description:** Keyword co-occurrence patterns across AI paradigms
**Output:** Comparative bar chart of keyword frequencies

#### `02_keyword_overlap_venn_diagram.py`
**Article Figure:** Fig. 2
**Description:** Keyword overlap visualization between paradigms
**Output:** Venn diagram showing paradigm intersections

#### `create_figure6.py`
**Article Figure:** Fig. 6
**Description:** Author network metrics comparison across paradigms
**Output:** Multi-panel network analysis visualization

#### `04_cross_paradigm_authors(figure10).py`
**Article Figure:** Fig. 10
**Description:** Cross-paradigm author dynamics and temporal evolution (1956-2024)
**Output:** 6-panel comprehensive author analysis
**Key Metrics:**
- Cross-paradigm author distribution by combinations
- Temporal distribution across decades
- Career span vs citations analysis
- Leading institutions in cross-paradigm research
- Evolution of paradigm combinations over time
- Productivity distribution by paradigm count

#### `create_figure11.py`
**Article Figure:** Fig. 11
**Description:** Citation performance analysis across AI paradigms
**Output:** 6-panel citation analysis visualization
**Key Metrics:**
- Citation dominance percentages (Statistical AI: 78.5%, Symbolic AI: 18.6%, Hybrid AI: 2.8%)
- Publications vs total citations scatter plot
- H-Index comparison (Statistical: 824, Symbolic: 366, Hybrid: 173)
- Impact categories distribution
- Mean citations vs research clusters
- Temporal coverage by paradigm

#### `06_symbolic_ai_s_curve.py`
**Article Figure:** Fig. 12
**Description:** Symbolic AI S-curve analysis showing paradigm maturity (1957-2024)
**Output:** 4-panel S-curve analysis
**Key Features:**
- Publications S-curve with R²=0.997
- Annual publication distribution with 2007 peak
- Citations S-curve with earlier inflection point
- Growth rate analysis showing maturity phase

#### `07_statistical_ai_s_curve.py`
**Article Figure:** Fig. 13
**Description:** Statistical AI S-curve analysis showing dominance phase (1958-2024)
**Output:** 4-panel S-curve analysis
**Key Features:**
- Publications S-curve with R²=0.996
- Annual publication distribution with 2017 peak (781 publications)
- Citations S-curve with 3.77M total citations
- Growth rate analysis showing continued expansion

#### `08_hybrid_ai_s_curve.py`
**Article Figure:** Fig. 14
**Description:** Hybrid AI S-curve analysis showing exponential growth (1997-2024)
**Output:** 4-panel S-curve analysis
**Key Features:**
- Publications S-curve with R²=0.998
- Annual publication distribution with 2024 peak (455 publications)
- Citations S-curve with early inflection point (2021.3)
- Growth rate analysis showing exponential phase

#### `09_comparative_s_curves.py`
**Article Figure:** Fig. 15
**Description:** Comparative S-curve analysis of all three paradigms
**Output:** Multi-paradigm S-curve comparison

#### `create_paradigm_transition.py`
**Article Figure:** Fig. 16
**Description:** Paradigm transition visualization based on Kurzweil's Law of Accelerating Returns
**Output:** Conceptual paradigm transition diagram
**Key Features:**
- Three paradigm S-curves with transition arrows
- Inflection points: Symbolic AI (2007), Hybrid AI (2024)
- Paradigm transition phases and timing
- Visual proof of systematic paradigm evolution

### VOSviewer-Generated Network Maps

#### Network Visualization Figures (Generated via VOSviewer)

**Fig. 3:** Symbolic AI keyword co-occurrence map
- **Analysis Type:** Conceptual clustering
- **Key Metrics:** 999 keywords, 570,720 co-occurrences
- **Focus:** Thematic structure and conceptual diversity

**Fig. 4:** Statistical AI keyword co-occurrence map
- **Analysis Type:** Thematic structure analysis
- **Focus:** Machine learning and data-driven approaches

**Fig. 5:** Hybrid AI keyword co-occurrence map
- **Analysis Type:** Emergent concept topology
- **Focus:** Integration patterns and multi-modal approaches

**Fig. 7:** Symbolic AI co-authorship network
- **Analysis Type:** Density mapping
- **Key Metrics:** 40 authors, focused clusters
- **Focus:** Concentrated collaboration patterns

**Fig. 8:** Statistical AI co-authorship network
- **Analysis Type:** Density mapping
- **Key Metrics:** 187 authors, fragmented zones
- **Focus:** Broader but fragmented collaboration zones

**Fig. 9:** Hybrid AI co-authorship network
- **Analysis Type:** Density mapping
- **Key Metrics:** 343 authors, bridging nature
- **Focus:** Cross-paradigm collaboration patterns

## Usage Instructions

### Prerequisites
```bash
pip install pandas numpy matplotlib seaborn scipy openpyxl json glob warnings collections
```

### S-Curve Validation Pipeline
```bash
# Step 1: Validate Statistical AI parameters
cd 00_methodology
python3 statistical_ai_scurve_validation.py

# Step 2: Validate Symbolic AI parameters
python3 symbolic_ai_scurve_validation.py

# Step 3: Validate Hybrid AI parameters
python3 hybrid_ai_scurve_validation.py

# Step 4: Run paradigm classification
python3 paradigm_classification_algorithm.py
```

### Data Processing Pipeline
```bash
# Step 1: Convert JSON to Excel
cd 01_data_processing
python3 convert_json_to_excel.py

# Step 2: Create analysis tables
python3 create_excel_tables.py

# Step 3: Generate supplementary Excel files
python3 create_coauthorship_analysis_tables_excel.py
python3 create_citation_excel.py
```

### Figure Generation
```bash
# Generate all Python-based figures
cd 02_visualization
python3 01_keyword_cooccurrence_analysis.py
python3 02_keyword_overlap_venn_diagram.py
python3 create_figure6.py
python3 04_cross_paradigm_authors\(figure10\).py
python3 create_figure11.py
python3 06_symbolic_ai_s_curve.py
python3 07_statistical_ai_s_curve.py
python3 08_hybrid_ai_s_curve.py
python3 09_comparative_s_curves.py
python3 create_paradigm_transition.py
```

## Technical Specifications

### Data Sources and Methodology Integration
- **Primary:** OpenAlex API with standardized parameters
- **AI Concept ID:** C41008148 (Artificial Intelligence)
- **Temporal Coverage:** 1956-2024 (68 years)
- **Total Publications:** 14,527 across all paradigms
- **Paradigm Classification:** Keyword-based algorithm with manual validation

### S-Curve Analysis Framework
- **Mathematical Model:** Logistic growth function L/(1+exp(-k*(x-x0)))
- **Fitting Method:** scipy.optimize.curve_fit with maximum likelihood estimation
- **Performance Metrics:** R² values ranging from 0.996 to 0.998
- **Validation Approach:** Cross-validation with manuscript claims and Excel data

### Analysis Methods
- **S-curve Modeling:** Logistic regression with scipy.optimize
- **Network Analysis:** Graph theory metrics via VOSviewer
- **Citation Analysis:** Bibliometric indicators (H-index, impact categories)
- **Temporal Analysis:** Time series analysis with inflection point detection

### Output Specifications
- **Figures:** 300 DPI, publication-ready PNG format
- **Tables:** Multi-sheet Excel format with comprehensive metadata
- **Data:** JSON and CSV formats for interoperability
- **Validation Reports:** Detailed accuracy assessments with statistical comparisons

## Key Findings Summary

### Paradigm Characteristics (Validated)
- **Symbolic AI:** 5,172 publications, 894,861 citations, inflection point 2005.1, mature phase
- **Statistical AI:** 7,812 publications, 3,771,429 citations, inflection point 2018.0, dominant phase  
- **Hybrid AI:** 1,543 publications, 136,505 citations, inflection point 2024.0, exponential growth

### S-curve Model Performance
- **R² values:** 0.996-0.998 (excellent fit across all paradigms)
- **Kurzweil's theory:** Empirically validated through systematic transitions
- **Paradigm transitions:** Predictable pattern with 2007 and 2024 inflection points

### Cross-Paradigm Analysis
- **Cross-paradigm authors:** 137 researchers spanning multiple paradigms
- **Citation dominance:** Statistical AI (78.5%), Symbolic AI (18.6%), Hybrid AI (2.8%)
- **H-Index comparison:** Statistical AI (824), Symbolic AI (366), Hybrid AI (173)

## Data Quality and Validation

### Validation Framework
- **Excel Data Verification:** All calculations cross-validated with source Excel files
- **Parameter Accuracy:** S-curve parameters validated through independent curve fitting
- **Manuscript Consistency:** Systematic comparison between manuscript claims and calculated values
- **Error Analysis:** Detailed reporting of discrepancies and their statistical significance

### Reproducibility Framework
- **Complete Pipeline:** From raw JSON to final figures
- **Version Control:** All scripts with detailed documentation
- **Error Handling:** Robust exception handling and data validation
- **Cross-Platform:** Compatible with Windows, macOS, and Linux

## Future Extensions

### Methodological Enhancements
- **Real-time Analysis:** Integration with live OpenAlex API feeds
- **Machine Learning:** Automated paradigm classification using NLP
- **Network Dynamics:** Temporal network evolution analysis
- **Predictive Modeling:** Future paradigm emergence prediction

### Technical Improvements
- **Interactive Visualizations:** Web-based dashboard development
- **API Integration:** Direct OpenAlex API connectivity
- **Cloud Processing:** Scalable analysis for larger datasets
- **Multi-language Support:** Internationalization for global research

## Citation and Usage

When using this code package, please cite:
```
[Your Article Citation]
```

## Contact and Support

For questions about the code, methodology, or data:

**Primary Contact:**
- Yelda Fırat: yeldafrt@gmail.com, +905053865514

**Co-authors:**
- Hüseyin Ali Sarıkaya: hasarikaya@ankara.edu.tr
- Yılmaz Kılıçaslan: ykilicas@ankara.edu.tr  
- Murat Kaan Yılmaz: mkaan.yilmaz@ankara.edu.tr

**Institution:** Ankara University, Department of Information and Document Management

**GitHub Repository:** https://github.com/yeldafrt/A-Bibliometric-and-S-Curve-Based-Analysis-of-Artificial-Intelligence-Paradigms

---

**Note:** This package represents a complete analytical framework for bibliometric analysis of AI paradigms with rigorous validation procedures. The S-curve validation scripts ensure scientific accuracy and reproducibility of all quantitative claims in the manuscript.

