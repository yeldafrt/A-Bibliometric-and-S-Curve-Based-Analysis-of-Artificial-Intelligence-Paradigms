#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Comparative AI S-Curve Analysis
Üç AI paradigmasının (Symbolic, Statistical, Hybrid) karşılaştırmalı S-eğrisi analizi
Ekteki comparative_ai_s_curves.png formatında
"""

import json
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
import os
import glob
import re
import warnings
warnings.filterwarnings('ignore')

# Set matplotlib parameters for high-quality visualization
plt.rcParams['figure.figsize'] = (14, 10)
plt.rcParams['font.size'] = 14
plt.rcParams['axes.titlesize'] = 16
plt.rcParams['axes.labelsize'] = 14
plt.rcParams['xtick.labelsize'] = 12
plt.rcParams['ytick.labelsize'] = 12
plt.rcParams['legend.fontsize'] = 12

def load_paradigm_data(paradigm_name, data_dir):
    """Load data for a specific paradigm"""
    json_files = glob.glob(os.path.join(data_dir, "*.json"))
    all_publications = []
    
    for file_path in json_files:
        print(f"Loading {paradigm_name}: {os.path.basename(file_path)}")
        try:
            # Read file and clean invalid control characters
            with open(file_path, 'rb') as f:
                raw_content = f.read()
            
            # Decode with error handling
            try:
                content = raw_content.decode('utf-8-sig')
            except UnicodeDecodeError:
                content = raw_content.decode('utf-8-sig', errors='ignore')
            
            # Remove invalid control characters and fix common JSON issues
            content = re.sub(r'[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]', '', content)
            content = re.sub(r'[\r\n\t]+', ' ', content)  # Normalize whitespace
            content = re.sub(r'\s+', ' ', content)  # Remove extra spaces
            
            # Try to parse JSON
            data = json.loads(content)
                
            # Extract publications from network items
            if 'network' in data and 'items' in data['network']:
                for item in data['network']['items']:
                    pub_data = {
                        'id': item.get('id'),
                        'label': item.get('label', ''),
                        'year': item.get('scores', {}).get('Pub. year', 0),
                        'citations': item.get('scores', {}).get('Citations', 0),
                        'norm_citations': item.get('scores', {}).get('Norm. citations', 0),
                        'cluster': item.get('cluster', 0)
                    }
                    
                    # Only include valid years
                    if pub_data['year'] >= 1956 and pub_data['year'] <= 2024:
                        all_publications.append(pub_data)
                        
        except Exception as e:
            print(f"Error loading {file_path}: {e}")
            continue
    
    return pd.DataFrame(all_publications)

def s_curve_function(x, L, k, x0):
    """Logistic S-curve function"""
    return L / (1 + np.exp(-k * (x - x0)))

def fit_s_curve(years, cumulative_data):
    """Fit S-curve to cumulative data"""
    try:
        # Initial parameter estimates
        L_init = max(cumulative_data) * 1.1  # Carrying capacity
        k_init = 0.1  # Growth rate
        x0_init = np.median(years)  # Inflection point
        
        # Fit the curve
        popt, pcov = curve_fit(
            s_curve_function, 
            years, 
            cumulative_data,
            p0=[L_init, k_init, x0_init],
            maxfev=5000,
            bounds=([0, 0, min(years)], [np.inf, 1, max(years)])
        )
        
        # Calculate R-squared
        y_pred = s_curve_function(years, *popt)
        ss_res = np.sum((cumulative_data - y_pred) ** 2)
        ss_tot = np.sum((cumulative_data - np.mean(cumulative_data)) ** 2)
        r_squared = 1 - (ss_res / ss_tot)
        
        return popt, r_squared
    except Exception as e:
        print(f"S-curve fitting error: {e}")
        return None, 0

def create_comparative_s_curves():
    """Create comparative S-curve analysis for all three AI paradigms"""
    
    # Data directories
    data_dirs = {
        'Symbolic AI': "/home/ubuntu/upload/json_cititation/1956-2024_sembolic_json/",
        'Statistical AI': "/home/ubuntu/upload/dataset/json_cititation/1956_2024_statistical/",
        'Hybrid AI': "/home/ubuntu/upload/dataset/json_cititation/1956_2024_hybrid_json/"
    }
    
    # Colors for each paradigm
    colors = {
        'Symbolic AI': '#1f77b4',      # Blue
        'Statistical AI': '#ff7f0e',   # Orange  
        'Hybrid AI': '#2ca02c'         # Green
    }
    
    # Load data for all paradigms
    paradigm_data = {}
    for paradigm, data_dir in data_dirs.items():
        print(f"\n=== Loading {paradigm} ===")
        df = load_paradigm_data(paradigm, data_dir)
        if not df.empty:
            paradigm_data[paradigm] = df
            print(f"Loaded {len(df)} publications from {df['year'].min()} to {df['year'].max()}")
    
    # Create the comparative plot (NO MAIN TITLE)
    fig, ax = plt.subplots(1, 1, figsize=(14, 10))
    
    # Year range for plotting
    all_years = range(1956, 2025)
    
    # Process each paradigm
    for paradigm, df in paradigm_data.items():
        # Prepare data for analysis
        annual_counts = df.groupby('year').size().to_dict()
        
        # Fill missing years with 0
        for year in all_years:
            if year not in annual_counts:
                annual_counts[year] = 0
        
        # Calculate cumulative data
        years = sorted(annual_counts.keys())
        cumulative_pubs = np.cumsum([annual_counts[year] for year in years])
        
        # Fit S-curve
        pub_params, pub_r2 = fit_s_curve(years, cumulative_pubs)
        
        # Plot actual data points
        ax.scatter(years, cumulative_pubs, color=colors[paradigm], alpha=0.7, s=40, zorder=5)
        
        # Plot S-curve fit
        if pub_params is not None:
            y_fit = s_curve_function(np.array(years), *pub_params)
            ax.plot(years, y_fit, color=colors[paradigm], linewidth=3, 
                   label=f'{paradigm} (R² = {pub_r2:.3f})', zorder=4)
        
        # Print summary
        print(f"\n=== {paradigm.upper()} SUMMARY ===")
        print(f"Total Publications: {len(df):,}")
        print(f"Year Range: {df['year'].min():.0f} - {df['year'].max():.0f}")
        print(f"Total Citations: {df['citations'].sum():,}")
        print(f"Average Citations per Publication: {df['citations'].mean():.1f}")
        
        if pub_params is not None:
            print(f"S-Curve Parameters:")
            print(f"  Carrying Capacity (L): {pub_params[0]:.0f}")
            print(f"  Growth Rate (k): {pub_params[1]:.4f}")
            print(f"  Inflection Point (x0): {pub_params[2]:.1f}")
            print(f"  R-squared: {pub_r2:.3f}")
    
    # Customize the plot
    ax.set_xlabel('Year', fontsize=14, fontweight='bold')
    ax.set_ylabel('Cumulative Publications', fontsize=14, fontweight='bold')
    ax.grid(True, alpha=0.3)
    ax.set_xlim(1955, 2025)
    ax.set_ylim(0, None)
    
    # Legend
    ax.legend(loc='upper left', frameon=True, fancybox=True, shadow=True)
    
    # Adjust layout
    plt.tight_layout()
    
    # Save the plot with high DPI
    output_path = '/home/ubuntu/comparative_ai_s_curves_new.png'
    plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor='white')
    print(f"\nComparative S-curve analysis saved to: {output_path}")
    
    return output_path

if __name__ == "__main__":
    create_comparative_s_curves()

