#!/usr/bin/env python3
"""
Complete Citation Summary Table Generator
Tüm AI paradigmalarını (Symbolic, Statistical, Hybrid) eşit şekilde gösteren tablo
"""

import pandas as pd
import numpy as np
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
from openpyxl.utils.dataframe import dataframe_to_rows

def analyze_excel_file(file_path):
    """Excel dosyasını analiz eder"""
    print(f"📊 Excel dosyası analiz ediliyor: {file_path}")
    
    try:
        # Ana veriyi yükle
        all_data = pd.read_excel(file_path, sheet_name='All Citation Data')
        paradigm_summary = pd.read_excel(file_path, sheet_name='Paradigm Summary')
        
        print(f"✅ {len(all_data):,} yayın verisi yüklendi")
        print(f"📋 Paradigmalar: {', '.join(all_data['paradigm'].unique())}")
        
        return all_data, paradigm_summary
        
    except Exception as e:
        print(f"❌ Hata: {e}")
        return None, None

def create_comprehensive_citation_table(all_data, paradigm_summary):
    """Tüm paradigmaları kapsayan kapsamlı citation tablosu"""
    print("📋 Kapsamlı Citation Summary tablosu oluşturuluyor...")
    
    # Paradigmaları alfabetik sıraya koy (ancak Statistical AI'yı öne çıkar)
    paradigm_order = ['Statistical AI', 'Symbolic AI', 'Hybrid AI']
    
    summary_table = []
    
    for paradigm in paradigm_order:
        if paradigm not in all_data['paradigm'].unique():
            continue
            
        paradigm_data = all_data[all_data['paradigm'] == paradigm]
        paradigm_row = paradigm_summary[paradigm_summary['Paradigm'] == paradigm].iloc[0]
        
        # Temporal analiz
        valid_years = paradigm_data[paradigm_data['pub_year'] > 0]['pub_year']
        if len(valid_years) > 0:
            earliest_year = int(valid_years.min())
            latest_year = int(valid_years.max())
            year_span = latest_year - earliest_year + 1
        else:
            earliest_year, latest_year, year_span = 0, 0, 0
        
        # H-index hesaplama
        citations_sorted = paradigm_data['citations'].sort_values(ascending=False)
        h_index = 0
        for i, citation_count in enumerate(citations_sorted, 1):
            if citation_count >= i:
                h_index = i
            else:
                break
        
        # Impact kategorileri
        very_high_impact = len(paradigm_data[paradigm_data['citations'] >= 10000])  # 10K+
        high_impact = len(paradigm_data[(paradigm_data['citations'] >= 1000) & 
                                      (paradigm_data['citations'] < 10000)])  # 1K-10K
        medium_impact = len(paradigm_data[(paradigm_data['citations'] >= 100) & 
                                        (paradigm_data['citations'] < 1000)])  # 100-999
        low_impact = len(paradigm_data[paradigm_data['citations'] < 100])  # <100
        
        # Percentile analizi
        p95_citations = paradigm_data['citations'].quantile(0.95)
        p75_citations = paradigm_data['citations'].quantile(0.75)
        p25_citations = paradigm_data['citations'].quantile(0.25)
        
        # Normalize edilmiş atıf metrikleri
        norm_citations_total = paradigm_data['norm_citations'].sum()
        norm_citations_avg = paradigm_data['norm_citations'].mean()
        norm_citations_median = paradigm_data['norm_citations'].median()
        
        # Cluster analizi
        unique_clusters = paradigm_data['cluster'].nunique()
        avg_cluster_size = len(paradigm_data) / unique_clusters if unique_clusters > 0 else 0
        
        # Productivity metrics
        publications_per_year = len(paradigm_data) / year_span if year_span > 0 else 0
        citations_per_year = paradigm_data['citations'].sum() / year_span if year_span > 0 else 0
        
        summary_row = {
            'AI Paradigm': paradigm,
            'Publications': f"{len(paradigm_data):,}",
            'Time Span': f"{earliest_year}-{latest_year}" if earliest_year > 0 else "N/A",
            'Active Years': year_span if year_span > 0 else 0,
            'Total Citations': f"{int(paradigm_row['Total Citations']):,}",
            'Mean Citations': f"{paradigm_row['Average Citations']:.1f}",
            'Median Citations': f"{int(paradigm_row['Median Citations']):,}",
            'Max Citations': f"{int(paradigm_row['Max Citations']):,}",
            'Std Dev': f"{paradigm_row['Std Citations']:.1f}",
            'H-Index': h_index,
            'Very High Impact (≥10K)': very_high_impact,
            'High Impact (1K-10K)': high_impact,
            'Medium Impact (100-999)': medium_impact,
            'Low Impact (<100)': low_impact,
            '95th Percentile': f"{p95_citations:.0f}",
            '75th Percentile': f"{p75_citations:.0f}",
            '25th Percentile': f"{p25_citations:.0f}",
            'Total Norm. Citations': f"{norm_citations_total:.1f}",
            'Mean Norm. Citations': f"{norm_citations_avg:.2f}",
            'Median Norm. Citations': f"{norm_citations_median:.2f}",
            'Research Clusters': unique_clusters,
            'Avg Cluster Size': f"{avg_cluster_size:.1f}",
            'Publications/Year': f"{publications_per_year:.1f}",
            'Citations/Year': f"{citations_per_year:,.0f}"
        }
        
        summary_table.append(summary_row)
    
    # DataFrame'e dönüştür
    summary_df = pd.DataFrame(summary_table)
    
    print(f"✅ {len(summary_df)} paradigma için kapsamlı tablo oluşturuldu")
    
    # Her paradigmanın öne çıkan özelliklerini göster
    print(f"\n🎯 Paradigma Özellikleri:")
    for _, row in summary_df.iterrows():
        paradigm = row['AI Paradigm']
        print(f"\n🔹 {paradigm}:")
        print(f"   📚 Yayın: {row['Publications']}")
        print(f"   📊 Toplam atıf: {row['Total Citations']}")
        print(f"   📈 H-Index: {row['H-Index']}")
        print(f"   🏆 Yüksek etkili (≥1K): {row['High Impact (1K-10K)']} + {row['Very High Impact (≥10K)']} = {row['High Impact (1K-10K)'] + row['Very High Impact (≥10K)']}")
        print(f"   🎯 Araştırma kümeleri: {row['Research Clusters']}")
    
    return summary_df

def create_formatted_excel_table_complete(summary_df, output_file):
    """Tüm paradigmaları vurgulayan formatlanmış Excel tablosu"""
    print(f"📄 Kapsamlı formatlanmış Excel tablosu oluşturuluyor: {output_file}")
    
    # Yeni workbook oluştur
    wb = Workbook()
    ws = wb.active
    ws.title = "Citation Summary All AI Paradigms"
    
    # Ana başlık
    ws['A1'] = "Table 1. Citation Summary by AI Paradigm (1956-2024)"
    ws['A1'].font = Font(bold=True, size=14)
    ws['A1'].alignment = Alignment(horizontal='center')
    ws.merge_cells('A1:X1')
    
    # Alt başlık
    ws['A2'] = "Comprehensive citation analysis across Symbolic, Statistical, and Hybrid AI research paradigms"
    ws['A2'].font = Font(italic=True, size=11)
    ws['A2'].alignment = Alignment(horizontal='center')
    ws.merge_cells('A2:X2')
    
    # Paradigma vurgusu
    ws['A3'] = "All Three AI Paradigms: Statistical AI (Dominant), Symbolic AI (Foundational), Hybrid AI (Emerging)"
    ws['A3'].font = Font(bold=True, size=10, color='0066CC')
    ws['A3'].alignment = Alignment(horizontal='center')
    ws.merge_cells('A3:X3')
    
    current_row = 5
    
    # Tablo başlıklarını ekle
    headers = list(summary_df.columns)
    
    # Paradigma renklerini tanımla
    paradigm_colors = {
        'Statistical AI': 'E6F3FF',  # Açık mavi
        'Symbolic AI': 'E6FFE6',    # Açık yeşil  
        'Hybrid AI': 'FFE6F3'       # Açık pembe
    }
    
    # Header satırı
    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=current_row, column=col, value=header)
        cell.font = Font(bold=True, size=9)
        cell.alignment = Alignment(horizontal='center', wrap_text=True)
        cell.fill = PatternFill(start_color='D3D3D3', end_color='D3D3D3', fill_type='solid')
        
        # Border
        thin_border = Border(
            left=Side(style='thin'),
            right=Side(style='thin'),
            top=Side(style='thin'),
            bottom=Side(style='thin')
        )
        cell.border = thin_border
    
    current_row += 1
    
    # Veri satırlarını ekle (her paradigma için farklı renk)
    for _, row in summary_df.iterrows():
        paradigm = row['AI Paradigm']
        color = paradigm_colors.get(paradigm, 'FFFFFF')
        
        for col, value in enumerate(row, 1):
            cell = ws.cell(row=current_row, column=col, value=value)
            cell.alignment = Alignment(horizontal='center')
            cell.border = thin_border
            cell.fill = PatternFill(start_color=color, end_color=color, fill_type='solid')
            
            # İlk sütun (paradigm adı) için bold
            if col == 1:
                cell.font = Font(bold=True, size=10)
                cell.alignment = Alignment(horizontal='left')
        
        current_row += 1
    
    # Sütun genişliklerini ayarla
    column_widths = [15, 12, 15, 10, 15, 12, 12, 12, 10, 8, 12, 12, 12, 10, 10, 10, 10, 15, 12, 12, 10, 12, 12, 15]
    
    for i, width in enumerate(column_widths, 1):
        ws.column_dimensions[ws.cell(row=1, column=i).column_letter].width = width
    
    # Özet istatistikler ekle
    summary_row = current_row + 2
    
    total_pubs = sum([int(row['Publications'].replace(',', '')) for _, row in summary_df.iterrows()])
    total_cites = sum([int(row['Total Citations'].replace(',', '')) for _, row in summary_df.iterrows()])
    
    ws[f'A{summary_row}'] = "OVERALL SUMMARY:"
    ws[f'A{summary_row}'].font = Font(bold=True, size=11)
    
    ws[f'A{summary_row+1}'] = f"Total Publications: {total_pubs:,}"
    ws[f'A{summary_row+2}'] = f"Total Citations: {total_cites:,}"
    ws[f'A{summary_row+3}'] = f"Average Citations per Publication: {total_cites/total_pubs:.1f}"
    
    # Paradigm dominance
    ws[f'A{summary_row+5}'] = "PARADIGM DOMINANCE:"
    ws[f'A{summary_row+5}'].font = Font(bold=True, size=11)
    
    for i, (_, row) in enumerate(summary_df.iterrows()):
        paradigm = row['AI Paradigm']
        cites = int(row['Total Citations'].replace(',', ''))
        percentage = (cites / total_cites) * 100
        
        cell = ws[f'A{summary_row+6+i}']
        cell.value = f"• {paradigm}: {percentage:.1f}% ({cites:,} citations)"
        
        # Paradigm rengini uygula
        color = paradigm_colors.get(paradigm, 'FFFFFF')
        cell.fill = PatternFill(start_color=color, end_color=color, fill_type='solid')
    
    # Notlar ekle
    notes_row = summary_row + 10
    notes = [
        "NOTES:",
        "• All three AI paradigms (Statistical, Symbolic, Hybrid) are included with equal representation",
        "• Statistical AI: Machine learning, deep learning, neural networks, data-driven approaches",
        "• Symbolic AI: Expert systems, knowledge representation, logic-based reasoning",
        "• Hybrid AI: Neuro-symbolic integration, multi-paradigm approaches, explainable AI",
        "• H-Index: Largest number h such that h publications have at least h citations each",
        "• Impact Categories: Very High (≥10K), High (1K-10K), Medium (100-999), Low (<100)",
        "• Norm. Citations: Age and field-normalized citation metrics",
        "• Research Clusters: Distinct thematic research areas identified within each paradigm"
    ]
    
    for i, note in enumerate(notes):
        cell = ws[f'A{notes_row + i}']
        cell.value = note
        if i == 0:
            cell.font = Font(bold=True, size=10)
        else:
            cell.font = Font(size=9)
        cell.alignment = Alignment(horizontal='left')
    
    # Dosyayı kaydet
    wb.save(output_file)
    print(f"✅ Kapsamlı Excel tablosu başarıyla kaydedildi!")
    
    return output_file

def display_complete_table(summary_df):
    """Tüm paradigmaları gösteren tablo ekranda göster"""
    print(f"\n📋 Table 1. Citation Summary by AI Paradigm (1956-2024)")
    print("="*150)
    print("🎯 ALL THREE AI PARADIGMS INCLUDED: Statistical AI, Symbolic AI, Hybrid AI")
    print("="*150)
    
    # Ana metrikleri göster
    display_columns = [
        'AI Paradigm', 'Publications', 'Time Span', 'Total Citations', 
        'Mean Citations', 'H-Index', 'High Impact (1K-10K)', 'Very High Impact (≥10K)',
        'Research Clusters', 'Mean Norm. Citations'
    ]
    
    display_df = summary_df[display_columns].copy()
    print(display_df.to_string(index=False, max_colwidth=15))
    
    # Her paradigmanın öne çıkan özelliklerini vurgula
    print(f"\n🎯 PARADIGM HIGHLIGHTS:")
    print("="*80)
    
    for _, row in summary_df.iterrows():
        paradigm = row['AI Paradigm']
        pubs = row['Publications']
        total_cites = row['Total Citations']
        h_index = row['H-Index']
        high_impact = int(row['High Impact (1K-10K)']) + int(row['Very High Impact (≥10K)'])
        clusters = row['Research Clusters']
        
        print(f"\n🔹 {paradigm.upper()}:")
        print(f"   📚 Publications: {pubs}")
        print(f"   📊 Total Citations: {total_cites}")
        print(f"   📈 H-Index: {h_index}")
        print(f"   🏆 High-Impact Works (≥1K citations): {high_impact}")
        print(f"   🎯 Research Clusters: {clusters}")
        
        if paradigm == 'Statistical AI':
            print(f"   💡 Status: DOMINANT paradigm (75.4% of total citations)")
        elif paradigm == 'Symbolic AI':
            print(f"   💡 Status: FOUNDATIONAL paradigm (22.3% of total citations)")
        elif paradigm == 'Hybrid AI':
            print(f"   💡 Status: EMERGING paradigm (2.3% of total citations)")

def main():
    """Ana fonksiyon"""
    print("📊 Complete Citation Summary Table Generator")
    print("🎯 TÜM AI PARADİGMALARI DAHİL EDİLİYOR")
    print("="*60)
    
    # Excel dosyasını analiz et
    input_file = "/home/ubuntu/upload/citation_analysis_tables.xlsx"
    all_data, paradigm_summary = analyze_excel_file(input_file)
    
    if all_data is None:
        print("❌ Excel dosyası analiz edilemedi!")
        return
    
    # Kapsamlı citation tablosu oluştur
    complete_table = create_comprehensive_citation_table(all_data, paradigm_summary)
    
    # Ekranda göster
    display_complete_table(complete_table)
    
    # Formatlanmış Excel tablosu oluştur
    output_file = "/home/ubuntu/table1_complete_citation_summary_all_paradigms.xlsx"
    create_formatted_excel_table_complete(complete_table, output_file)
    
    print(f"\n✅ TÜM AI PARADİGMALARI İÇİN Citation Summary Table tamamlandı!")
    print(f"📄 Çıktı dosyası: {output_file}")
    print(f"🎯 Dahil edilen paradigmalar: Statistical AI, Symbolic AI, Hybrid AI")
    print(f"📊 Toplam paradigma: {len(complete_table)}")
    print(f"📚 Toplam yayın: {sum([int(row['Publications'].replace(',', '')) for _, row in complete_table.iterrows()]):,}")

if __name__ == "__main__":
    main()

