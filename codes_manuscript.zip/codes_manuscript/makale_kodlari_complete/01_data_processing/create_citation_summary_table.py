#!/usr/bin/env python3
"""
Citation Summary Table Generator
Excel dosyasından makale için Citation Summary tablosu oluşturur
"""

import pandas as pd
import numpy as np
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
from openpyxl.utils.dataframe import dataframe_to_rows

def analyze_excel_file(file_path):
    """Excel dosyasını analiz eder ve tüm sayfaları inceler"""
    print(f"📊 Excel dosyası analiz ediliyor: {file_path}")
    
    try:
        # Tüm sheet isimlerini al
        excel_file = pd.ExcelFile(file_path)
        sheet_names = excel_file.sheet_names
        
        print(f"📋 Bulunan sayfalar: {len(sheet_names)}")
        for i, sheet in enumerate(sheet_names, 1):
            print(f"   {i}. {sheet}")
        
        # Ana veriyi yükle
        all_data = pd.read_excel(file_path, sheet_name='All Citation Data')
        
        # Paradigm Summary sayfası varsa yükle
        if 'Paradigm Summary' in sheet_names:
            paradigm_summary = pd.read_excel(file_path, sheet_name='Paradigm Summary')
        else:
            # Manuel hesaplama
            paradigm_summary = create_paradigm_summary(all_data)
        
        print(f"✅ {len(all_data):,} yayın verisi yüklendi")
        return all_data, paradigm_summary, sheet_names
        
    except Exception as e:
        print(f"❌ Hata: {e}")
        return None, None, None

def create_paradigm_summary(all_data):
    """Ana veriden paradigm summary oluşturur"""
    print("📊 Paradigm summary manuel olarak oluşturuluyor...")
    
    summary_data = []
    
    for paradigm in all_data['paradigm'].unique():
        paradigm_data = all_data[all_data['paradigm'] == paradigm]
        
        summary = {
            'Paradigm': paradigm,
            'Total Publications': len(paradigm_data),
            'Total Citations': paradigm_data['citations'].sum(),
            'Average Citations': paradigm_data['citations'].mean(),
            'Median Citations': paradigm_data['citations'].median(),
            'Max Citations': paradigm_data['citations'].max(),
            'Min Citations': paradigm_data['citations'].min(),
            'Std Citations': paradigm_data['citations'].std(),
            'Total Norm Citations': paradigm_data['norm_citations'].sum(),
            'Average Norm Citations': paradigm_data['norm_citations'].mean(),
            'Unique Clusters': paradigm_data['cluster'].nunique(),
            'Year Range': f"{paradigm_data['pub_year'].min():.0f}-{paradigm_data['pub_year'].max():.0f}" if paradigm_data['pub_year'].max() > 0 else "N/A"
        }
        summary_data.append(summary)
    
    return pd.DataFrame(summary_data)

def create_citation_summary_table(all_data, paradigm_summary):
    """Citation Summary tablosu oluşturur"""
    print("📋 Citation Summary tablosu oluşturuluyor...")
    
    # Temel istatistikler
    summary_table = []
    
    for _, row in paradigm_summary.iterrows():
        paradigm = row['Paradigm']
        
        # Paradigm verilerini al
        paradigm_data = all_data[all_data['paradigm'] == paradigm]
        
        # Temporal analiz
        if len(paradigm_data[paradigm_data['pub_year'] > 0]) > 0:
            earliest_year = int(paradigm_data[paradigm_data['pub_year'] > 0]['pub_year'].min())
            latest_year = int(paradigm_data[paradigm_data['pub_year'] > 0]['pub_year'].max())
            year_span = latest_year - earliest_year + 1
        else:
            earliest_year, latest_year, year_span = 0, 0, 0
        
        # H-index benzeri metrik (en az h kez atıf alan h yayın sayısı)
        citations_sorted = paradigm_data['citations'].sort_values(ascending=False)
        h_index = 0
        for i, citation_count in enumerate(citations_sorted, 1):
            if citation_count >= i:
                h_index = i
            else:
                break
        
        # Yüksek etkili yayın sayısı (1000+ atıf)
        high_impact = len(paradigm_data[paradigm_data['citations'] >= 1000])
        
        # Orta etkili yayın sayısı (100-999 atıf)
        medium_impact = len(paradigm_data[(paradigm_data['citations'] >= 100) & 
                                        (paradigm_data['citations'] < 1000)])
        
        # Düşük etkili yayın sayısı (<100 atıf)
        low_impact = len(paradigm_data[paradigm_data['citations'] < 100])
        
        # Normalize edilmiş atıf metrikleri
        norm_citations_total = paradigm_data['norm_citations'].sum()
        norm_citations_avg = paradigm_data['norm_citations'].mean()
        
        # Cluster çeşitliliği
        unique_clusters = paradigm_data['cluster'].nunique()
        
        summary_row = {
            'AI Paradigm': paradigm,
            'Publications (N)': int(row['Total Publications']),
            'Time Span (Years)': f"{earliest_year}-{latest_year}" if earliest_year > 0 else "N/A",
            'Coverage (Years)': year_span if year_span > 0 else 0,
            'Total Citations': int(row['Total Citations']),
            'Mean Citations': round(row['Average Citations'], 1),
            'Median Citations': int(row['Median Citations']),
            'Max Citations': int(row['Max Citations']),
            'Std Citations': round(row['Std Citations'], 1),
            'H-Index': h_index,
            'High Impact (≥1000)': high_impact,
            'Medium Impact (100-999)': medium_impact,
            'Low Impact (<100)': low_impact,
            'Total Norm. Citations': round(norm_citations_total, 1),
            'Mean Norm. Citations': round(norm_citations_avg, 2),
            'Unique Clusters': unique_clusters
        }
        
        summary_table.append(summary_row)
    
    # DataFrame'e dönüştür
    summary_df = pd.DataFrame(summary_table)
    
    # Paradigmaları Total Citations'a göre sırala
    summary_df = summary_df.sort_values('Total Citations', ascending=False)
    
    print(f"✅ {len(summary_df)} paradigma için özet tablo oluşturuldu")
    return summary_df

def create_formatted_excel_table(summary_df, output_file):
    """Formatlanmış Excel tablosu oluşturur"""
    print(f"📄 Formatlanmış Excel tablosu oluşturuluyor: {output_file}")
    
    # Yeni workbook oluştur
    wb = Workbook()
    ws = wb.active
    ws.title = "Citation Summary by AI Paradigm"
    
    # Başlık ekle
    ws['A1'] = "Table 1. Citation Summary by AI Paradigm (1956-2024)"
    ws['A1'].font = Font(bold=True, size=14)
    ws['A1'].alignment = Alignment(horizontal='left')
    ws.merge_cells('A1:P1')
    
    # Alt başlık ekle
    ws['A2'] = "Comprehensive citation analysis across Symbolic, Statistical, and Hybrid AI research paradigms"
    ws['A2'].font = Font(italic=True, size=10)
    ws['A2'].alignment = Alignment(horizontal='left')
    ws.merge_cells('A2:P2')
    
    # Boş satır
    current_row = 4
    
    # Tablo başlıklarını ekle
    headers = list(summary_df.columns)
    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=current_row, column=col, value=header)
        cell.font = Font(bold=True, size=10)
        cell.alignment = Alignment(horizontal='center', wrap_text=True)
        cell.fill = PatternFill(start_color='E6E6FA', end_color='E6E6FA', fill_type='solid')
        
        # Border ekle
        thin_border = Border(
            left=Side(style='thin'),
            right=Side(style='thin'),
            top=Side(style='thin'),
            bottom=Side(style='thin')
        )
        cell.border = thin_border
    
    current_row += 1
    
    # Veri satırlarını ekle
    for _, row in summary_df.iterrows():
        for col, value in enumerate(row, 1):
            cell = ws.cell(row=current_row, column=col, value=value)
            cell.alignment = Alignment(horizontal='center')
            cell.border = thin_border
            
            # Sayısal değerler için formatting
            if isinstance(value, (int, float)) and col > 2:  # Paradigm adı hariç
                if value >= 1000:
                    cell.number_format = '#,##0'
                elif isinstance(value, float):
                    cell.number_format = '0.0'
        
        current_row += 1
    
    # Sütun genişliklerini ayarla
    column_widths = {
        'A': 15,  # AI Paradigm
        'B': 12,  # Publications
        'C': 15,  # Time Span
        'D': 12,  # Coverage
        'E': 15,  # Total Citations
        'F': 12,  # Mean Citations
        'G': 12,  # Median Citations
        'H': 12,  # Max Citations
        'I': 12,  # Std Citations
        'J': 10,  # H-Index
        'K': 12,  # High Impact
        'L': 12,  # Medium Impact
        'M': 12,  # Low Impact
        'N': 15,  # Total Norm Citations
        'O': 15,  # Mean Norm Citations
        'P': 12   # Unique Clusters
    }
    
    for col, width in column_widths.items():
        ws.column_dimensions[col].width = width
    
    # Satır yüksekliklerini ayarla
    ws.row_dimensions[1].height = 20
    ws.row_dimensions[2].height = 15
    ws.row_dimensions[4].height = 30  # Header row
    
    # Notlar ekle
    notes_row = current_row + 2
    notes = [
        "Notes:",
        "• Publications (N): Total number of publications in each paradigm",
        "• Time Span: Earliest to latest publication years",
        "• Coverage: Total years of research activity",
        "• H-Index: Largest number h such that h publications have at least h citations each",
        "• High/Medium/Low Impact: Publications categorized by citation thresholds",
        "• Norm. Citations: Normalized citations accounting for publication age and field",
        "• Unique Clusters: Number of distinct research clusters identified"
    ]
    
    for i, note in enumerate(notes):
        cell = ws.cell(row=notes_row + i, column=1, value=note)
        if i == 0:
            cell.font = Font(bold=True, size=10)
        else:
            cell.font = Font(size=9)
        cell.alignment = Alignment(horizontal='left')
    
    # Dosyayı kaydet
    wb.save(output_file)
    print(f"✅ Excel tablosu başarıyla kaydedildi!")
    
    return output_file

def create_simple_table_for_display(summary_df):
    """Ekranda gösterim için basit tablo oluşturur"""
    print(f"\n📋 Table 1. Citation Summary by AI Paradigm (1956-2024)")
    print("="*120)
    
    # Seçili sütunları göster
    display_columns = [
        'AI Paradigm', 'Publications (N)', 'Time Span (Years)', 
        'Total Citations', 'Mean Citations', 'H-Index',
        'High Impact (≥1000)', 'Mean Norm. Citations'
    ]
    
    display_df = summary_df[display_columns].copy()
    
    # Formatla
    for col in ['Total Citations', 'Mean Citations', 'H-Index', 'High Impact (≥1000)']:
        if col in display_df.columns:
            display_df[col] = display_df[col].apply(lambda x: f"{x:,}" if isinstance(x, (int, float)) else x)
    
    print(display_df.to_string(index=False))
    
    # Özet istatistikler
    total_pubs = summary_df['Publications (N)'].sum()
    total_cites = summary_df['Total Citations'].sum()
    
    print(f"\n📊 Overall Summary:")
    print(f"   • Total Publications: {total_pubs:,}")
    print(f"   • Total Citations: {total_cites:,}")
    print(f"   • Average Citations per Publication: {total_cites/total_pubs:.1f}")
    
    # Paradigm dominance
    print(f"\n🏆 Paradigm Dominance (by Total Citations):")
    for _, row in summary_df.iterrows():
        percentage = (row['Total Citations'] / total_cites) * 100
        print(f"   • {row['AI Paradigm']}: {percentage:.1f}%")

def main():
    """Ana fonksiyon"""
    print("📊 Citation Summary Table Generator")
    print("="*50)
    
    # Excel dosyasını analiz et
    input_file = "/home/ubuntu/upload/citation_analysis_tables.xlsx"
    all_data, paradigm_summary, sheet_names = analyze_excel_file(input_file)
    
    if all_data is None:
        print("❌ Excel dosyası analiz edilemedi!")
        return
    
    # Citation Summary tablosu oluştur
    summary_table = create_citation_summary_table(all_data, paradigm_summary)
    
    # Ekranda göster
    create_simple_table_for_display(summary_table)
    
    # Formatlanmış Excel tablosu oluştur
    output_file = "/home/ubuntu/table1_citation_summary_by_ai_paradigm.xlsx"
    create_formatted_excel_table(summary_table, output_file)
    
    print(f"\n✅ Citation Summary Table tamamlandı!")
    print(f"📄 Çıktı dosyası: {output_file}")
    print(f"📊 Paradigma sayısı: {len(summary_table)}")
    print(f"📚 Toplam yayın: {summary_table['Publications (N)'].sum():,}")
    print(f"📈 Toplam atıf: {summary_table['Total Citations'].sum():,}")

if __name__ == "__main__":
    main()

