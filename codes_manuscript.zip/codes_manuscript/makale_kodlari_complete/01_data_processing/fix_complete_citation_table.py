#!/usr/bin/env python3
"""
Fixed Complete Citation Summary Table Generator
Excel formatting hatası düzeltilmiş versiyon
"""

import pandas as pd
import numpy as np
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
from openpyxl.utils import get_column_letter

def analyze_excel_file(file_path):
    """Excel dosyasını analiz eder"""
    print(f"📊 Excel dosyası analiz ediliyor: {file_path}")
    
    try:
        all_data = pd.read_excel(file_path, sheet_name='All Citation Data')
        paradigm_summary = pd.read_excel(file_path, sheet_name='Paradigm Summary')
        
        print(f"✅ {len(all_data):,} yayın verisi yüklendi")
        print(f"📋 Paradigmalar: {', '.join(all_data['paradigm'].unique())}")
        
        return all_data, paradigm_summary
        
    except Exception as e:
        print(f"❌ Hata: {e}")
        return None, None

def create_comprehensive_citation_table(all_data, paradigm_summary):
    """Tüm paradigmaları kapsayan citation tablosu"""
    print("📋 Kapsamlı Citation Summary tablosu oluşturuluyor...")
    
    paradigm_order = ['Statistical AI', 'Symbolic AI', 'Hybrid AI']
    summary_table = []
    
    for paradigm in paradigm_order:
        if paradigm not in all_data['paradigm'].unique():
            continue
            
        paradigm_data = all_data[all_data['paradigm'] == paradigm]
        paradigm_row = paradigm_summary[paradigm_summary['Paradigm'] == paradigm].iloc[0]
        
        # Temporal analiz
        valid_years = paradigm_data[paradigm_data['pub_year'] > 0]['pub_year']
        if len(valid_years) > 0:
            earliest_year = int(valid_years.min())
            latest_year = int(valid_years.max())
            year_span = latest_year - earliest_year + 1
        else:
            earliest_year, latest_year, year_span = 0, 0, 0
        
        # H-index hesaplama
        citations_sorted = paradigm_data['citations'].sort_values(ascending=False)
        h_index = 0
        for i, citation_count in enumerate(citations_sorted, 1):
            if citation_count >= i:
                h_index = i
            else:
                break
        
        # Impact kategorileri
        very_high_impact = len(paradigm_data[paradigm_data['citations'] >= 10000])
        high_impact = len(paradigm_data[(paradigm_data['citations'] >= 1000) & 
                                      (paradigm_data['citations'] < 10000)])
        medium_impact = len(paradigm_data[(paradigm_data['citations'] >= 100) & 
                                        (paradigm_data['citations'] < 1000)])
        low_impact = len(paradigm_data[paradigm_data['citations'] < 100])
        
        # Normalize edilmiş atıf metrikleri
        norm_citations_total = paradigm_data['norm_citations'].sum()
        norm_citations_avg = paradigm_data['norm_citations'].mean()
        
        # Cluster analizi
        unique_clusters = paradigm_data['cluster'].nunique()
        
        summary_row = {
            'AI Paradigm': paradigm,
            'Publications (N)': len(paradigm_data),
            'Time Span': f"{earliest_year}-{latest_year}" if earliest_year > 0 else "N/A",
            'Active Years': year_span if year_span > 0 else 0,
            'Total Citations': int(paradigm_row['Total Citations']),
            'Mean Citations': round(paradigm_row['Average Citations'], 1),
            'Median Citations': int(paradigm_row['Median Citations']),
            'Max Citations': int(paradigm_row['Max Citations']),
            'Std Dev': round(paradigm_row['Std Citations'], 1),
            'H-Index': h_index,
            'Very High Impact (≥10K)': very_high_impact,
            'High Impact (1K-10K)': high_impact,
            'Medium Impact (100-999)': medium_impact,
            'Low Impact (<100)': low_impact,
            'Total Norm Citations': round(norm_citations_total, 1),
            'Mean Norm Citations': round(norm_citations_avg, 2),
            'Research Clusters': unique_clusters
        }
        
        summary_table.append(summary_row)
    
    summary_df = pd.DataFrame(summary_table)
    
    print(f"✅ {len(summary_df)} paradigma için kapsamlı tablo oluşturuldu")
    
    # Paradigma özelliklerini göster
    print(f"\n🎯 Paradigma Özellikleri:")
    for _, row in summary_df.iterrows():
        paradigm = row['AI Paradigm']
        print(f"\n🔹 {paradigm}:")
        print(f"   📚 Yayın: {row['Publications (N)']:,}")
        print(f"   📊 Toplam atıf: {row['Total Citations']:,}")
        print(f"   📈 H-Index: {row['H-Index']}")
        print(f"   🏆 Yüksek etkili (≥1K): {row['High Impact (1K-10K)'] + row['Very High Impact (≥10K)']}")
        print(f"   🎯 Araştırma kümeleri: {row['Research Clusters']}")
    
    return summary_df

def create_formatted_excel_table(summary_df, output_file):
    """Formatlanmış Excel tablosu oluşturur"""
    print(f"📄 Formatlanmış Excel tablosu oluşturuluyor: {output_file}")
    
    wb = Workbook()
    ws = wb.active
    ws.title = "Citation Summary AI Paradigms"
    
    # Ana başlık
    ws['A1'] = "Table 1. Citation Summary by AI Paradigm (1956-2024)"
    ws['A1'].font = Font(bold=True, size=14)
    ws['A1'].alignment = Alignment(horizontal='center')
    ws.merge_cells('A1:Q1')
    
    # Alt başlık
    ws['A2'] = "Comprehensive citation analysis across Statistical, Symbolic, and Hybrid AI research paradigms"
    ws['A2'].font = Font(italic=True, size=11)
    ws['A2'].alignment = Alignment(horizontal='center')
    ws.merge_cells('A2:Q2')
    
    # Paradigma vurgusu
    ws['A3'] = "All Three AI Paradigms Included: Statistical AI (Dominant), Symbolic AI (Foundational), Hybrid AI (Emerging)"
    ws['A3'].font = Font(bold=True, size=10, color='0066CC')
    ws['A3'].alignment = Alignment(horizontal='center')
    ws.merge_cells('A3:Q3')
    
    current_row = 5
    
    # Tablo başlıklarını ekle
    headers = list(summary_df.columns)
    
    # Paradigma renklerini tanımla
    paradigm_colors = {
        'Statistical AI': 'E6F3FF',  # Açık mavi
        'Symbolic AI': 'E6FFE6',    # Açık yeşil  
        'Hybrid AI': 'FFE6F3'       # Açık pembe
    }
    
    # Border tanımla
    thin_border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )
    
    # Header satırı
    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=current_row, column=col, value=header)
        cell.font = Font(bold=True, size=9)
        cell.alignment = Alignment(horizontal='center', wrap_text=True)
        cell.fill = PatternFill(start_color='D3D3D3', end_color='D3D3D3', fill_type='solid')
        cell.border = thin_border
    
    current_row += 1
    
    # Veri satırlarını ekle
    for _, row in summary_df.iterrows():
        paradigm = row['AI Paradigm']
        color = paradigm_colors.get(paradigm, 'FFFFFF')
        
        for col, value in enumerate(row, 1):
            cell = ws.cell(row=current_row, column=col, value=value)
            cell.alignment = Alignment(horizontal='center')
            cell.border = thin_border
            cell.fill = PatternFill(start_color=color, end_color=color, fill_type='solid')
            
            # İlk sütun (paradigm adı) için bold ve left align
            if col == 1:
                cell.font = Font(bold=True, size=10)
                cell.alignment = Alignment(horizontal='left')
            
            # Sayısal değerler için formatting
            if isinstance(value, (int, float)) and col > 1:
                if value >= 1000:
                    cell.number_format = '#,##0'
                elif isinstance(value, float):
                    cell.number_format = '0.0'
        
        current_row += 1
    
    # Sütun genişliklerini ayarla
    column_widths = {
        1: 15,   # AI Paradigm
        2: 12,   # Publications
        3: 15,   # Time Span
        4: 10,   # Active Years
        5: 15,   # Total Citations
        6: 12,   # Mean Citations
        7: 12,   # Median Citations
        8: 12,   # Max Citations
        9: 10,   # Std Dev
        10: 8,   # H-Index
        11: 12,  # Very High Impact
        12: 12,  # High Impact
        13: 12,  # Medium Impact
        14: 10,  # Low Impact
        15: 15,  # Total Norm Citations
        16: 12,  # Mean Norm Citations
        17: 10   # Research Clusters
    }
    
    for col_num, width in column_widths.items():
        ws.column_dimensions[get_column_letter(col_num)].width = width
    
    # Özet istatistikler ekle
    summary_row = current_row + 2
    
    total_pubs = summary_df['Publications (N)'].sum()
    total_cites = summary_df['Total Citations'].sum()
    
    ws[f'A{summary_row}'] = "OVERALL SUMMARY:"
    ws[f'A{summary_row}'].font = Font(bold=True, size=11)
    
    ws[f'A{summary_row+1}'] = f"Total Publications: {total_pubs:,}"
    ws[f'A{summary_row+2}'] = f"Total Citations: {total_cites:,}"
    ws[f'A{summary_row+3}'] = f"Average Citations per Publication: {total_cites/total_pubs:.1f}"
    
    # Paradigm dominance
    ws[f'A{summary_row+5}'] = "PARADIGM DOMINANCE:"
    ws[f'A{summary_row+5}'].font = Font(bold=True, size=11)
    
    for i, (_, row) in enumerate(summary_df.iterrows()):
        paradigm = row['AI Paradigm']
        cites = row['Total Citations']
        percentage = (cites / total_cites) * 100
        
        cell = ws[f'A{summary_row+6+i}']
        cell.value = f"• {paradigm}: {percentage:.1f}% ({cites:,} citations)"
        
        # Paradigm rengini uygula
        color = paradigm_colors.get(paradigm, 'FFFFFF')
        cell.fill = PatternFill(start_color=color, end_color=color, fill_type='solid')
    
    # Notlar ekle
    notes_row = summary_row + 10
    notes = [
        "NOTES:",
        "• All three AI paradigms (Statistical, Symbolic, Hybrid) are included with comprehensive metrics",
        "• Statistical AI: Machine learning, deep learning, neural networks, data-driven approaches",
        "• Symbolic AI: Expert systems, knowledge representation, logic-based reasoning, rule-based systems",
        "• Hybrid AI: Neuro-symbolic integration, multi-paradigm approaches, explainable AI",
        "• H-Index: Largest number h such that h publications have at least h citations each",
        "• Impact Categories: Very High (≥10K), High (1K-10K), Medium (100-999), Low (<100)",
        "• Norm Citations: Age and field-normalized citation metrics for fair comparison",
        "• Research Clusters: Distinct thematic research areas identified within each paradigm",
        "• Time Span: Complete temporal coverage from earliest to latest publications"
    ]
    
    for i, note in enumerate(notes):
        cell = ws[f'A{notes_row + i}']
        cell.value = note
        if i == 0:
            cell.font = Font(bold=True, size=10)
        else:
            cell.font = Font(size=9)
        cell.alignment = Alignment(horizontal='left')
    
    # Dosyayı kaydet
    wb.save(output_file)
    print(f"✅ Excel tablosu başarıyla kaydedildi!")
    
    return output_file

def display_complete_table(summary_df):
    """Tüm paradigmaları gösteren tablo ekranda göster"""
    print(f"\n📋 Table 1. Citation Summary by AI Paradigm (1956-2024)")
    print("="*120)
    print("🎯 ALL THREE AI PARADIGMS INCLUDED: Statistical AI, Symbolic AI, Hybrid AI")
    print("="*120)
    
    # Ana metrikleri göster
    display_columns = [
        'AI Paradigm', 'Publications (N)', 'Time Span', 'Total Citations', 
        'Mean Citations', 'H-Index', 'High Impact (1K-10K)', 'Very High Impact (≥10K)',
        'Research Clusters'
    ]
    
    display_df = summary_df[display_columns].copy()
    
    # Formatla
    for col in ['Publications (N)', 'Total Citations']:
        display_df[col] = display_df[col].apply(lambda x: f"{x:,}")
    
    print(display_df.to_string(index=False, max_colwidth=15))
    
    # Paradigm highlights
    print(f"\n🎯 PARADIGM HIGHLIGHTS:")
    print("="*80)
    
    total_cites = summary_df['Total Citations'].sum()
    
    for _, row in summary_df.iterrows():
        paradigm = row['AI Paradigm']
        percentage = (row['Total Citations'] / total_cites) * 100
        high_impact_total = row['High Impact (1K-10K)'] + row['Very High Impact (≥10K)']
        
        print(f"\n🔹 {paradigm.upper()}:")
        print(f"   📚 Publications: {row['Publications (N)']:,}")
        print(f"   📊 Total Citations: {row['Total Citations']:,}")
        print(f"   📈 H-Index: {row['H-Index']}")
        print(f"   🏆 High-Impact Works (≥1K): {high_impact_total}")
        print(f"   🎯 Research Clusters: {row['Research Clusters']}")
        print(f"   💡 Citation Share: {percentage:.1f}%")
        
        if paradigm == 'Statistical AI':
            print(f"   🏅 Status: DOMINANT paradigm")
        elif paradigm == 'Symbolic AI':
            print(f"   🏅 Status: FOUNDATIONAL paradigm")
        elif paradigm == 'Hybrid AI':
            print(f"   🏅 Status: EMERGING paradigm")

def main():
    """Ana fonksiyon"""
    print("📊 Complete Citation Summary Table Generator - FIXED VERSION")
    print("🎯 TÜM AI PARADİGMALARI DAHİL EDİLİYOR")
    print("="*70)
    
    # Excel dosyasını analiz et
    input_file = "/home/ubuntu/upload/citation_analysis_tables.xlsx"
    all_data, paradigm_summary = analyze_excel_file(input_file)
    
    if all_data is None:
        print("❌ Excel dosyası analiz edilemedi!")
        return
    
    # Kapsamlı citation tablosu oluştur
    complete_table = create_comprehensive_citation_table(all_data, paradigm_summary)
    
    # Ekranda göster
    display_complete_table(complete_table)
    
    # Formatlanmış Excel tablosu oluştur
    output_file = "/home/ubuntu/table1_complete_citation_summary_all_paradigms.xlsx"
    create_formatted_excel_table(complete_table, output_file)
    
    print(f"\n✅ TÜM AI PARADİGMALARI İÇİN Citation Summary Table tamamlandı!")
    print(f"📄 Çıktı dosyası: {output_file}")
    print(f"🎯 Dahil edilen paradigmalar: Statistical AI, Symbolic AI, Hybrid AI")
    print(f"📊 Toplam paradigma: {len(complete_table)}")
    print(f"📚 Toplam yayın: {complete_table['Publications (N)'].sum():,}")
    print(f"📈 Toplam atıf: {complete_table['Total Citations'].sum():,}")

if __name__ == "__main__":
    main()

