import json
import pandas as pd
from docx import Document
from docx.shared import Inches
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
import numpy as np

# JSON dosyasını oku
with open('/home/ubuntu/upload/keyword.json', 'r', encoding='utf-8-sig') as f:
    data = json.load(f)

# Verileri analiz et
items = data['network']['items']
links = data['network']['links']

# DataFrame oluştur
df_items = pd.DataFrame(items)

# En yüksek occurrence'lı terimleri al
top_keywords = df_items.nlargest(20, 'weights.Occurrences')[['label', 'weights.Occurrences', 'weights.Total link strength', 'cluster', 'scores.Avg. pub. year', 'scores.Avg. citations']]

# Cluster analizi
cluster_analysis = df_items.groupby('cluster').agg({
    'label': 'count',
    'weights.Occurrences': 'sum',
    'weights.Total link strength': 'mean',
    'scores.Avg. citations': 'mean'
}).round(2)

# Temporal analysis - yıllara göre
temporal_data = df_items.copy()
temporal_data['decade'] = (temporal_data['scores.Avg. pub. year'] // 10) * 10
decade_analysis = temporal_data.groupby('decade').agg({
    'label': 'count',
    'weights.Occurrences': 'sum',
    'scores.Avg. citations': 'mean'
}).round(2)

# Word belgesi oluştur
doc = Document()

# Başlık
title = doc.add_heading('Statistical AI Keyword Co-occurrence Analysis Results', 0)
title.alignment = WD_ALIGN_PARAGRAPH.CENTER

# Tablo 1: Top Keywords
doc.add_heading('Table 1. Top 20 Keywords in Statistical AI Research (1960-2024)', level=1)

# Açıklama
explanation1 = doc.add_paragraph()
explanation1.add_run("Bu tablo, istatistiksel yapay zeka araştırmalarında en sık kullanılan 20 anahtar kelimeyi göstermektedir. ").bold = False
explanation1.add_run("'Occurrences' ").italic = True
explanation1.add_run("terimin kaç makalede geçtiğini, ").bold = False
explanation1.add_run("'Link Strength' ").italic = True
explanation1.add_run("diğer terimlerle olan bağlantı gücünü, ").bold = False
explanation1.add_run("'Cluster' ").italic = True
explanation1.add_run("hangi tematik kümeye ait olduğunu gösterir. Ortalama yayın yılı ve atıf sayıları, terimlerin zamansal dağılımı ve etkisini yansıtır.")

# Tablo oluştur
table1 = doc.add_table(rows=1, cols=6)
table1.style = 'Table Grid'
table1.alignment = WD_TABLE_ALIGNMENT.CENTER

# Başlık satırı
hdr_cells = table1.rows[0].cells
hdr_cells[0].text = 'Rank'
hdr_cells[1].text = 'Keyword'
hdr_cells[2].text = 'Occurrences'
hdr_cells[3].text = 'Link Strength'
hdr_cells[4].text = 'Cluster'
hdr_cells[5].text = 'Avg. Citations'

# Başlık satırını kalın yap
for cell in hdr_cells:
    for paragraph in cell.paragraphs:
        for run in paragraph.runs:
            run.bold = True
    cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER

# Veri satırları
for i, (idx, row) in enumerate(top_keywords.iterrows()):
    row_cells = table1.add_row().cells
    row_cells[0].text = str(i + 1)
    row_cells[1].text = str(row['label'])
    row_cells[2].text = str(int(row['weights.Occurrences']))
    row_cells[3].text = str(int(row['weights.Total link strength']))
    row_cells[4].text = str(int(row['cluster']))
    row_cells[5].text = str(int(row['scores.Avg. citations']))
    
    # Hizalama
    for j, cell in enumerate(row_cells):
        if j == 1:  # Keyword sütunu sol hizalı
            cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.LEFT
        else:  # Diğerleri merkez hizalı
            cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER

doc.add_paragraph()

# Tablo 2: Cluster Analysis
doc.add_heading('Table 2. Thematic Cluster Analysis in Statistical AI', level=1)

explanation2 = doc.add_paragraph()
explanation2.add_run("Bu tablo, istatistiksel yapay zeka alanındaki tematik kümeleri analiz eder. Her küme, benzer konularda çalışan terimleri gruplar. ").bold = False
explanation2.add_run("'Term Count' ").italic = True
explanation2.add_run("kümedeki terim sayısını, ").bold = False
explanation2.add_run("'Total Occurrences' ").italic = True
explanation2.add_run("kümenin toplam görülme sıklığını, ").bold = False
explanation2.add_run("'Avg. Link Strength' ").italic = True
explanation2.add_run("küme içi bağlantı gücünü gösterir.")

table2 = doc.add_table(rows=1, cols=5)
table2.style = 'Table Grid'
table2.alignment = WD_TABLE_ALIGNMENT.CENTER

hdr_cells2 = table2.rows[0].cells
hdr_cells2[0].text = 'Cluster ID'
hdr_cells2[1].text = 'Term Count'
hdr_cells2[2].text = 'Total Occurrences'
hdr_cells2[3].text = 'Avg. Link Strength'
hdr_cells2[4].text = 'Avg. Citations'

for cell in hdr_cells2:
    for paragraph in cell.paragraphs:
        for run in paragraph.runs:
            run.bold = True
    cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER

for cluster_id, row in cluster_analysis.iterrows():
    row_cells = table2.add_row().cells
    row_cells[0].text = str(cluster_id)
    row_cells[1].text = str(int(row['label']))
    row_cells[2].text = str(int(row['weights.Occurrences']))
    row_cells[3].text = str(row['weights.Total link strength'])
    row_cells[4].text = str(int(row['scores.Avg. citations']))
    
    for cell in row_cells:
        cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER

doc.add_paragraph()

# Tablo 3: Temporal Evolution
doc.add_heading('Table 3. Temporal Evolution of Statistical AI Keywords by Decade', level=1)

explanation3 = doc.add_paragraph()
explanation3.add_run("Bu tablo, istatistiksel yapay zeka terimlerinin on yıllık dönemler bazında evrimini gösterir. ").bold = False
explanation3.add_run("1960'lardan günümüze kadar olan dönemde hangi terimlerin hangi dönemlerde daha aktif olduğunu ve ortalama atıf etkilerini analiz eder. Bu analiz, paradigma değişimlerini ve teknolojik gelişmeleri yansıtır.")

table3 = doc.add_table(rows=1, cols=4)
table3.style = 'Table Grid'
table3.alignment = WD_TABLE_ALIGNMENT.CENTER

hdr_cells3 = table3.rows[0].cells
hdr_cells3[0].text = 'Decade'
hdr_cells3[1].text = 'Active Terms'
hdr_cells3[2].text = 'Total Occurrences'
hdr_cells3[3].text = 'Avg. Citations'

for cell in hdr_cells3:
    for paragraph in cell.paragraphs:
        for run in paragraph.runs:
            run.bold = True
    cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER

for decade, row in decade_analysis.iterrows():
    if not np.isnan(decade):
        row_cells = table3.add_row().cells
        row_cells[0].text = f"{int(decade)}s"
        row_cells[1].text = str(int(row['label']))
        row_cells[2].text = str(int(row['weights.Occurrences']))
        row_cells[3].text = str(int(row['scores.Avg. citations']))
        
        for cell in row_cells:
            cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER

# En önemli bulgular
doc.add_paragraph()
doc.add_heading('Key Findings / Temel Bulgular', level=1)

findings = doc.add_paragraph()
findings.add_run("1. Dominant Terms: ").bold = True
findings.add_run(f"En baskın terimler '{top_keywords.iloc[0]['label']}', '{top_keywords.iloc[1]['label']}', ve '{top_keywords.iloc[2]['label']}' olarak tespit edilmiştir.\n\n")

findings.add_run("2. Cluster Distribution: ").bold = True
findings.add_run(f"Toplam {len(cluster_analysis)} farklı tematik küme belirlenmiş, en büyük küme {cluster_analysis['label'].max()} terim içermektedir.\n\n")

findings.add_run("3. Temporal Trends: ").bold = True
findings.add_run("Analiz sonuçları, 2000'li yıllardan itibaren istatistiksel AI terimlerinde belirgin bir artış olduğunu göstermektedir.\n\n")

findings.add_run("4. Citation Impact: ").bold = True
findings.add_run(f"En yüksek atıf ortalamasına sahip terim '{top_keywords.loc[top_keywords['scores.Avg. citations'].idxmax(), 'label']}' olup, {int(top_keywords['scores.Avg. citations'].max())} ortalama atıf almıştır.")

# Dosyayı kaydet
doc.save('/home/ubuntu/statistical_ai_keyword_analysis.docx')
print("✅ Analiz tamamlandı! Dosya kaydedildi: statistical_ai_keyword_analysis.docx")
print(f"📊 Toplam {len(items)} terim analiz edildi")
print(f"🔗 {len(links)} bağlantı incelendi")
print(f"📈 En sık geçen terim: {top_keywords.iloc[0]['label']} ({int(top_keywords.iloc[0]['weights.Occurrences'])} kez)")

