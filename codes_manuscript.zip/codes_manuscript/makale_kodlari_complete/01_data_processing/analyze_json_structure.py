#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
from collections import Counter

def analyze_json_file(file_path, name):
    """Analyze JSON file structure and content"""
    print(f"\n=== {name} Analysis ===")
    
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        # Basic info
        print(f"Query: {data.get('meta', {}).get('q', 'N/A')}")
        print(f"Total count: {data.get('meta', {}).get('count', 'N/A')}")
        print(f"Results in file: {len(data.get('results', []))}")
        
        # Extract all concepts and topics
        all_concepts = []
        all_topics = []
        
        for result in data.get('results', []):
            # Concepts
            concepts = result.get('concepts', [])
            for concept in concepts:
                concept_name = concept.get('display_name', '').lower().strip()
                if concept_name:
                    all_concepts.append(concept_name)
            
            # Topics  
            topics = result.get('topics', [])
            for topic in topics:
                topic_name = topic.get('display_name', '').lower().strip()
                if topic_name:
                    all_topics.append(topic_name)
        
        print(f"Total concepts extracted: {len(all_concepts)}")
        print(f"Unique concepts: {len(set(all_concepts))}")
        print(f"Total topics extracted: {len(all_topics)}")
        print(f"Unique topics: {len(set(all_topics))}")
        
        # Top 10 most common concepts
        concept_counts = Counter(all_concepts)
        print(f"\nTop 10 concepts:")
        for concept, count in concept_counts.most_common(10):
            print(f"  {concept}: {count}")
        
        # Top 10 most common topics
        topic_counts = Counter(all_topics)
        print(f"\nTop 10 topics:")
        for topic, count in topic_counts.most_common(10):
            print(f"  {topic}: {count}")
            
        return all_concepts, all_topics, concept_counts, topic_counts
        
    except Exception as e:
        print(f"Error analyzing {file_path}: {e}")
        return [], [], Counter(), Counter()

def main():
    """Main analysis function"""
    print("Analyzing JSON file structures and content...")
    
    # Analyze each file
    symbolic_concepts, symbolic_topics, symbolic_concept_counts, symbolic_topic_counts = analyze_json_file(
        '/home/ubuntu/upload/works_sembolic.json', 'Symbolic AI'
    )
    
    statistical_concepts, statistical_topics, statistical_concept_counts, statistical_topic_counts = analyze_json_file(
        '/home/ubuntu/upload/works_statical.json', 'Statistical AI'
    )
    
    hybrid_concepts, hybrid_topics, hybrid_concept_counts, hybrid_topic_counts = analyze_json_file(
        '/home/ubuntu/upload/works_hibrit.json', 'Hybrid AI'
    )
    
    # Check for overlaps
    print(f"\n=== OVERLAP ANALYSIS ===")
    
    symbolic_set = set(symbolic_concepts + symbolic_topics)
    statistical_set = set(statistical_concepts + statistical_topics)
    hybrid_set = set(hybrid_concepts + hybrid_topics)
    
    print(f"Symbolic unique keywords: {len(symbolic_set)}")
    print(f"Statistical unique keywords: {len(statistical_set)}")
    print(f"Hybrid unique keywords: {len(hybrid_set)}")
    
    # Check if files are identical
    if symbolic_set == statistical_set == hybrid_set:
        print("⚠️  WARNING: All files contain IDENTICAL keyword sets!")
    else:
        print("✅ Files contain different keyword sets")
        
        # Calculate overlaps
        all_three = symbolic_set & statistical_set & hybrid_set
        symbolic_statistical = (symbolic_set & statistical_set) - hybrid_set
        symbolic_hybrid = (symbolic_set & hybrid_set) - statistical_set
        statistical_hybrid = (statistical_set & hybrid_set) - symbolic_set
        symbolic_only = symbolic_set - statistical_set - hybrid_set
        statistical_only = statistical_set - symbolic_set - hybrid_set
        hybrid_only = hybrid_set - symbolic_set - statistical_set
        
        print(f"\nOverlap statistics:")
        print(f"  All three paradigms: {len(all_three)}")
        print(f"  Symbolic + Statistical only: {len(symbolic_statistical)}")
        print(f"  Symbolic + Hybrid only: {len(symbolic_hybrid)}")
        print(f"  Statistical + Hybrid only: {len(statistical_hybrid)}")
        print(f"  Symbolic only: {len(symbolic_only)}")
        print(f"  Statistical only: {len(statistical_only)}")
        print(f"  Hybrid only: {len(hybrid_only)}")

if __name__ == "__main__":
    main()

