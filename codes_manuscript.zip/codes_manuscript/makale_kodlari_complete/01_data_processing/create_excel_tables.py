#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
import pandas as pd
from collections import Counter
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment

def extract_detailed_data_from_json(file_path, paradigm_name):
    """Extract detailed keyword data from VOSviewer JSON file"""
    try:
        with open(file_path, 'r', encoding='utf-8-sig') as f:
            data = json.load(f)
        
        keyword_data = []
        
        # Extract from network items
        items = data.get('network', {}).get('items', [])
        
        for item in items:
            label = item.get('label', '').strip()
            if label and len(label) > 2:
                weights = item.get('weights', {})
                scores = item.get('scores', {})
                
                keyword_info = {
                    'keyword': label,
                    'paradigm': paradigm_name,
                    'occurrences': weights.get('Occurrences', 0),
                    'total_link_strength': weights.get('Total link strength', 0),
                    'links': weights.get('Links', 0),
                    'cluster': item.get('cluster', 0),
                    'avg_pub_year': scores.get('Avg. pub. year', 0),
                    'avg_citations': scores.get('Avg. citations', 0),
                    'avg_norm_citations': scores.get('Avg. norm. citations', 0)
                }
                keyword_data.append(keyword_info)
        
        print(f"{paradigm_name}: {len(keyword_data)} keywords with detailed data")
        return keyword_data
        
    except Exception as e:
        print(f"Error reading {file_path}: {e}")
        return []

def create_excel_tables():
    """Create Excel file with all analysis tables"""
    
    print("Extracting detailed data from JSON files...")
    
    # Extract data from each paradigm
    symbolic_data = extract_detailed_data_from_json('/home/ubuntu/upload/works_sembolic.json', 'Symbolic AI')
    statistical_data = extract_detailed_data_from_json('/home/ubuntu/upload/works_statical.json', 'Statistical AI')
    hybrid_data = extract_detailed_data_from_json('/home/ubuntu/upload/works_hibrit.json', 'Hybrid AI')
    
    # Combine all data
    all_data = symbolic_data + statistical_data + hybrid_data
    
    # Create Excel writer
    excel_file = '/home/ubuntu/keyword_analysis_tables.xlsx'
    
    with pd.ExcelWriter(excel_file, engine='openpyxl') as writer:
        
        # Sheet 1: All Keywords Data
        df_all = pd.DataFrame(all_data)
        df_all = df_all.sort_values(['paradigm', 'occurrences'], ascending=[True, False])
        df_all.to_excel(writer, sheet_name='All Keywords', index=False)
        
        # Sheet 2: Summary by Paradigm
        summary_data = []
        for paradigm in ['Symbolic AI', 'Statistical AI', 'Hybrid AI']:
            paradigm_data = [item for item in all_data if item['paradigm'] == paradigm]
            
            summary = {
                'Paradigm': paradigm,
                'Total Keywords': len(paradigm_data),
                'Total Occurrences': sum(item['occurrences'] for item in paradigm_data),
                'Avg Occurrences': sum(item['occurrences'] for item in paradigm_data) / len(paradigm_data) if paradigm_data else 0,
                'Max Occurrences': max(item['occurrences'] for item in paradigm_data) if paradigm_data else 0,
                'Min Occurrences': min(item['occurrences'] for item in paradigm_data) if paradigm_data else 0,
                'Total Link Strength': sum(item['total_link_strength'] for item in paradigm_data),
                'Avg Citations': sum(item['avg_citations'] for item in paradigm_data) / len(paradigm_data) if paradigm_data else 0
            }
            summary_data.append(summary)
        
        df_summary = pd.DataFrame(summary_data)
        df_summary.to_excel(writer, sheet_name='Summary by Paradigm', index=False)
        
        # Sheet 3: Top 20 Keywords (Figure 1 Data)
        # Get all unique keywords and their total occurrences
        keyword_totals = {}
        keyword_details = {}
        
        for item in all_data:
            keyword = item['keyword']
            if keyword not in keyword_totals:
                keyword_totals[keyword] = 0
                keyword_details[keyword] = {'symbolic': 0, 'statistical': 0, 'hybrid': 0}
            
            keyword_totals[keyword] += item['occurrences']
            
            if item['paradigm'] == 'Symbolic AI':
                keyword_details[keyword]['symbolic'] = item['occurrences']
            elif item['paradigm'] == 'Statistical AI':
                keyword_details[keyword]['statistical'] = item['occurrences']
            elif item['paradigm'] == 'Hybrid AI':
                keyword_details[keyword]['hybrid'] = item['occurrences']
        
        # Get top 20 keywords
        top_20_keywords = sorted(keyword_totals.items(), key=lambda x: x[1], reverse=True)[:20]
        
        figure1_data = []
        for keyword, total_occ in top_20_keywords:
            details = keyword_details[keyword]
            figure1_data.append({
                'Keyword': keyword,
                'Hybrid AI Occurrences': details['hybrid'],
                'Statistical AI Occurrences': details['statistical'],
                'Symbolic AI Occurrences': details['symbolic'],
                'Total Occurrences': total_occ
            })
        
        df_figure1 = pd.DataFrame(figure1_data)
        df_figure1.to_excel(writer, sheet_name='Figure 1 - Top 20 Keywords', index=False)
        
        # Sheet 4: Venn Diagram Data (Figure 2)
        symbolic_keywords = set(item['keyword'] for item in symbolic_data)
        statistical_keywords = set(item['keyword'] for item in statistical_data)
        hybrid_keywords = set(item['keyword'] for item in hybrid_data)
        
        # Calculate overlaps
        all_three = symbolic_keywords & statistical_keywords & hybrid_keywords
        symbolic_statistical = (symbolic_keywords & statistical_keywords) - hybrid_keywords
        symbolic_hybrid = (symbolic_keywords & hybrid_keywords) - statistical_keywords
        statistical_hybrid = (statistical_keywords & hybrid_keywords) - symbolic_keywords
        symbolic_only = symbolic_keywords - statistical_keywords - hybrid_keywords
        statistical_only = statistical_keywords - symbolic_keywords - hybrid_keywords
        hybrid_only = hybrid_keywords - symbolic_keywords - statistical_keywords
        
        venn_data = [
            {'Category': 'All Three Paradigms', 'Count': len(all_three), 'Keywords': ', '.join(sorted(list(all_three))[:10]) + '...' if len(all_three) > 10 else ', '.join(sorted(list(all_three)))},
            {'Category': 'Symbolic + Statistical Only', 'Count': len(symbolic_statistical), 'Keywords': ', '.join(sorted(list(symbolic_statistical))[:10]) + '...' if len(symbolic_statistical) > 10 else ', '.join(sorted(list(symbolic_statistical)))},
            {'Category': 'Symbolic + Hybrid Only', 'Count': len(symbolic_hybrid), 'Keywords': ', '.join(sorted(list(symbolic_hybrid))[:10]) + '...' if len(symbolic_hybrid) > 10 else ', '.join(sorted(list(symbolic_hybrid)))},
            {'Category': 'Statistical + Hybrid Only', 'Count': len(statistical_hybrid), 'Keywords': ', '.join(sorted(list(statistical_hybrid))[:10]) + '...' if len(statistical_hybrid) > 10 else ', '.join(sorted(list(statistical_hybrid)))},
            {'Category': 'Symbolic AI Only', 'Count': len(symbolic_only), 'Keywords': ', '.join(sorted(list(symbolic_only))[:10]) + '...' if len(symbolic_only) > 10 else ', '.join(sorted(list(symbolic_only)))},
            {'Category': 'Statistical AI Only', 'Count': len(statistical_only), 'Keywords': ', '.join(sorted(list(statistical_only))[:10]) + '...' if len(statistical_only) > 10 else ', '.join(sorted(list(statistical_only)))},
            {'Category': 'Hybrid AI Only', 'Count': len(hybrid_only), 'Keywords': ', '.join(sorted(list(hybrid_only))[:10]) + '...' if len(hybrid_only) > 10 else ', '.join(sorted(list(hybrid_only)))}
        ]
        
        df_venn = pd.DataFrame(venn_data)
        df_venn.to_excel(writer, sheet_name='Figure 2 - Venn Diagram', index=False)
        
        # Sheet 5: Overlap Matrix Data (Figure 3)
        # Filter keywords with minimum 10 occurrences
        filtered_keywords = []
        for keyword in keyword_totals:
            if keyword_totals[keyword] >= 10:
                filtered_keywords.append((keyword, keyword_totals[keyword]))
        
        # Sort and take top 25
        filtered_keywords.sort(key=lambda x: x[1], reverse=True)
        top_25_keywords = [item[0] for item in filtered_keywords[:25]]
        
        matrix_data = []
        for keyword in top_25_keywords:
            details = keyword_details[keyword]
            matrix_data.append({
                'Keyword': keyword,
                'Symbolic AI': 1 if details['symbolic'] > 0 else 0,
                'Hybrid AI': 1 if details['hybrid'] > 0 else 0,
                'Statistical AI': 1 if details['statistical'] > 0 else 0,
                'Total Occurrences': keyword_totals[keyword],
                'Symbolic Occurrences': details['symbolic'],
                'Hybrid Occurrences': details['hybrid'],
                'Statistical Occurrences': details['statistical']
            })
        
        df_matrix = pd.DataFrame(matrix_data)
        df_matrix.to_excel(writer, sheet_name='Figure 3 - Overlap Matrix', index=False)
    
    print(f"✅ Excel file created: {excel_file}")
    
    # Print summary statistics
    print(f"\n📊 Summary Statistics:")
    print(f"Symbolic AI: {len(symbolic_data)} keywords")
    print(f"Statistical AI: {len(statistical_data)} keywords")
    print(f"Hybrid AI: {len(hybrid_data)} keywords")
    print(f"Total unique keywords: {len(set(item['keyword'] for item in all_data))}")
    
    return excel_file

def main():
    """Main function"""
    print("Creating Excel tables from keyword analysis data...")
    excel_file = create_excel_tables()
    print(f"Excel file saved: {excel_file}")

if __name__ == "__main__":
    main()

