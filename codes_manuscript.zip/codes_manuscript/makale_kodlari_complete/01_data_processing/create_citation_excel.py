#!/usr/bin/env python3
"""
Citation Analysis Across AI Paradigms
1956-2024 yılları arası yapay zeka paradigmalarının atıf verilerini analiz eder
"""

import json
import pandas as pd
import os
import glob
from collections import defaultdict
import numpy as np
import re

def load_json_files(directory):
    """Bir dizindeki tüm JSON dosyalarını yükler"""
    json_files = glob.glob(os.path.join(directory, "*.json"))
    all_items = []
    
    for file_path in json_files:
        print(f"   📄 Yükleniyor: {os.path.basename(file_path)}")
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                
            # VOSviewer network formatı
            if 'network' in data and 'items' in data['network']:
                items = data['network']['items']
                
                # Dosya adından yıl aralığını çıkar
                filename = os.path.basename(file_path)
                year_info = extract_year_from_filename(filename)
                
                # Her item'a dosya bilgisi ekle
                for item in items:
                    item['source_file'] = filename
                    item['year_range'] = year_info
                
                all_items.extend(items)
                print(f"      ✅ {len(items)} item yüklendi")
            else:
                print(f"      ⚠️ Beklenmeyen format: {filename}")
                
        except Exception as e:
            print(f"      ❌ Hata: {e}")
    
    return all_items

def extract_year_from_filename(filename):
    """Dosya adından yıl aralığını çıkarır"""
    # Çeşitli yıl formatlarını yakala
    patterns = [
        r'(\d{4})-(\d{4})',  # 1956-1990
        r'(\d{4})_(\d{4})',  # 1956_1990
        r'(\d{2}\.\d{2}\.\d{4})_(\d{2}\.\d{2}\.\d{4})',  # 01.02.2024_01.01.2025
        r'(\d{2}\.\d{2}\.\d{4})_(\d{4})',  # 01.05.2017_2018
        r'(\d{4})-(\d{2}\.\d{2}\.\d{4})',  # 2021-30.06.2022
    ]
    
    for pattern in patterns:
        match = re.search(pattern, filename)
        if match:
            start, end = match.groups()
            
            # Tarih formatını yıla çevir
            if '.' in start:
                start_year = int(start.split('.')[-1])
            else:
                start_year = int(start)
                
            if '.' in end:
                end_year = int(end.split('.')[-1])
            else:
                end_year = int(end)
                
            return f"{start_year}-{end_year}"
    
    # Tek yıl formatı
    single_year = re.search(r'(\d{4})', filename)
    if single_year:
        year = single_year.group(1)
        return f"{year}-{year}"
    
    return "Unknown"

def parse_description_table(description):
    """HTML table formatındaki description'ı parse eder"""
    info = {}
    
    if not description:
        return info
    
    # HTML table'dan bilgileri çıkar
    patterns = {
        'authors': r'<td>Authors:</td><td>([^<]+)</td>',
        'title': r'<td>Title:</td><td>([^<]+)</td>',
        'source': r'<td>Source:</td><td>([^<]+)</td>',
        'year': r'<td>Year:</td><td>([^<]+)</td>'
    }
    
    for key, pattern in patterns.items():
        match = re.search(pattern, description, re.IGNORECASE)
        if match:
            info[key] = match.group(1).strip()
    
    return info

def process_paradigm_data(paradigm_name, directory):
    """Bir paradigmanın verilerini işler"""
    print(f"\n📊 {paradigm_name} paradigması işleniyor...")
    print(f"   📁 Dizin: {directory}")
    
    # JSON dosyalarını yükle
    items = load_json_files(directory)
    
    if not items:
        print(f"   ❌ {paradigm_name} için veri bulunamadı!")
        return pd.DataFrame()
    
    # DataFrame'e dönüştür
    processed_items = []
    
    for item in items:
        # Temel bilgiler
        processed_item = {
            'paradigm': paradigm_name,
            'id': item.get('id', ''),
            'label': item.get('label', ''),
            'cluster': item.get('cluster', 0),
            'source_file': item.get('source_file', ''),
            'year_range': item.get('year_range', ''),
            'url': item.get('url', '')
        }
        
        # Weights (ağırlıklar)
        weights = item.get('weights', {})
        processed_item.update({
            'links': weights.get('Links', 0),
            'citations': weights.get('Citations', 0),
            'norm_citations': weights.get('Norm. citations', 0)
        })
        
        # Scores (skorlar)
        scores = item.get('scores', {})
        processed_item.update({
            'pub_year': scores.get('Pub. year', 0),
            'score_citations': scores.get('Citations', 0),
            'score_norm_citations': scores.get('Norm. citations', 0)
        })
        
        # Koordinatlar
        processed_item.update({
            'x_coord': item.get('x', 0),
            'y_coord': item.get('y', 0)
        })
        
        # Description'dan bilgileri parse et
        description_info = parse_description_table(item.get('description', ''))
        processed_item.update({
            'authors': description_info.get('authors', ''),
            'title': description_info.get('title', ''),
            'source': description_info.get('source', ''),
            'desc_year': description_info.get('year', '')
        })
        
        processed_items.append(processed_item)
    
    df = pd.DataFrame(processed_items)
    
    print(f"   ✅ {len(df)} yayın işlendi")
    print(f"   📊 Toplam atıf: {df['citations'].sum():,}")
    print(f"   📊 Ortalama atıf: {df['citations'].mean():.1f}")
    print(f"   📊 En yüksek atıf: {df['citations'].max():,}")
    
    return df

def analyze_paradigms():
    """Tüm paradigmaları analiz eder"""
    print("🚀 Citation Analysis Across AI Paradigms")
    print("="*60)
    
    # Paradigma dizinleri
    base_dir = "/home/ubuntu/upload/json_cititation"
    paradigms = {
        'Symbolic AI': os.path.join(base_dir, "1956-2024_sembolic_json"),
        'Statistical AI': os.path.join(base_dir, "1956_2024_statistical"),
        'Hybrid AI': os.path.join(base_dir, "1956_2024_hybrid_json")
    }
    
    all_dataframes = []
    paradigm_summaries = []
    
    # Her paradigmayı işle
    for paradigm_name, directory in paradigms.items():
        if os.path.exists(directory):
            df = process_paradigm_data(paradigm_name, directory)
            if not df.empty:
                all_dataframes.append(df)
                
                # Özet istatistikler
                summary = {
                    'Paradigm': paradigm_name,
                    'Total Publications': len(df),
                    'Total Citations': df['citations'].sum(),
                    'Average Citations': df['citations'].mean(),
                    'Median Citations': df['citations'].median(),
                    'Max Citations': df['citations'].max(),
                    'Min Citations': df['citations'].min(),
                    'Std Citations': df['citations'].std(),
                    'Total Norm Citations': df['norm_citations'].sum(),
                    'Average Norm Citations': df['norm_citations'].mean(),
                    'Unique Clusters': df['cluster'].nunique(),
                    'Year Range': f"{df['pub_year'].min():.0f}-{df['pub_year'].max():.0f}" if df['pub_year'].max() > 0 else "N/A"
                }
                paradigm_summaries.append(summary)
        else:
            print(f"   ❌ Dizin bulunamadı: {directory}")
    
    # Tüm verileri birleştir
    if all_dataframes:
        combined_df = pd.concat(all_dataframes, ignore_index=True)
        summary_df = pd.DataFrame(paradigm_summaries)
        
        print(f"\n📋 GENEL ÖZET:")
        print(f"   📚 Toplam yayın: {len(combined_df):,}")
        print(f"   📊 Toplam atıf: {combined_df['citations'].sum():,}")
        print(f"   🎯 Paradigma sayısı: {len(paradigm_summaries)}")
        
        return combined_df, summary_df
    else:
        print("❌ Hiç veri işlenemedi!")
        return pd.DataFrame(), pd.DataFrame()

def create_detailed_analysis(combined_df, summary_df):
    """Detaylı analiz tabloları oluşturur"""
    print(f"\n📊 Detaylı analiz tabloları oluşturuluyor...")
    
    analysis_tables = {}
    
    # 1. Paradigma özet tablosu
    analysis_tables['Paradigm Summary'] = summary_df
    
    # 2. En çok atıf alan yayınlar (genel)
    top_cited = combined_df.nlargest(50, 'citations')[
        ['paradigm', 'title', 'authors', 'pub_year', 'citations', 'norm_citations', 'source']
    ].copy()
    top_cited['rank'] = range(1, len(top_cited) + 1)
    analysis_tables['Top Cited Works'] = top_cited
    
    # 3. Paradigma bazında en çok atıf alan yayınlar
    for paradigm in combined_df['paradigm'].unique():
        paradigm_data = combined_df[combined_df['paradigm'] == paradigm]
        top_paradigm = paradigm_data.nlargest(20, 'citations')[
            ['title', 'authors', 'pub_year', 'citations', 'norm_citations', 'source']
        ].copy()
        top_paradigm['rank'] = range(1, len(top_paradigm) + 1)
        analysis_tables[f'Top {paradigm} Works'] = top_paradigm
    
    # 4. Yıl bazında analiz
    yearly_analysis = combined_df.groupby(['paradigm', 'pub_year']).agg({
        'citations': ['count', 'sum', 'mean'],
        'norm_citations': ['sum', 'mean']
    }).round(2)
    yearly_analysis.columns = ['Publication Count', 'Total Citations', 'Avg Citations', 
                              'Total Norm Citations', 'Avg Norm Citations']
    yearly_analysis = yearly_analysis.reset_index()
    analysis_tables['Yearly Analysis'] = yearly_analysis
    
    # 5. Cluster analizi
    cluster_analysis = combined_df.groupby(['paradigm', 'cluster']).agg({
        'citations': ['count', 'sum', 'mean'],
        'norm_citations': ['sum', 'mean']
    }).round(2)
    cluster_analysis.columns = ['Publication Count', 'Total Citations', 'Avg Citations',
                               'Total Norm Citations', 'Avg Norm Citations']
    cluster_analysis = cluster_analysis.reset_index()
    analysis_tables['Cluster Analysis'] = cluster_analysis
    
    # 6. Normalize edilmiş atıf analizi
    norm_analysis = combined_df.groupby('paradigm').agg({
        'norm_citations': ['count', 'sum', 'mean', 'median', 'std', 'min', 'max']
    }).round(3)
    norm_analysis.columns = ['Count', 'Total', 'Mean', 'Median', 'Std', 'Min', 'Max']
    norm_analysis = norm_analysis.reset_index()
    analysis_tables['Normalized Citations Analysis'] = norm_analysis
    
    # 7. Yayın kaynakları analizi
    source_analysis = combined_df[combined_df['source'] != '[no source]'].groupby(['paradigm', 'source']).agg({
        'citations': ['count', 'sum', 'mean']
    }).round(2)
    source_analysis.columns = ['Publication Count', 'Total Citations', 'Avg Citations']
    source_analysis = source_analysis.reset_index()
    source_analysis = source_analysis.sort_values(['paradigm', 'Total Citations'], ascending=[True, False])
    analysis_tables['Source Analysis'] = source_analysis
    
    print(f"   ✅ {len(analysis_tables)} analiz tablosu oluşturuldu")
    return analysis_tables

def save_to_excel(combined_df, analysis_tables, output_file):
    """Tüm analizi Excel dosyasına kaydeder"""
    print(f"\n💾 Excel dosyası oluşturuluyor: {output_file}")
    
    with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
        # Ana veri
        combined_df.to_excel(writer, sheet_name='All Citation Data', index=False)
        
        # Analiz tabloları
        for sheet_name, df in analysis_tables.items():
            # Sheet adını Excel limitlerine uygun hale getir
            safe_sheet_name = sheet_name[:31]  # Excel 31 karakter limiti
            df.to_excel(writer, sheet_name=safe_sheet_name, index=False)
    
    print(f"   ✅ Excel dosyası başarıyla oluşturuldu!")
    
    # Özet bilgiler
    print(f"\n📋 Excel Dosyası İçeriği:")
    print(f"   📄 Ana veri: {len(combined_df):,} yayın")
    print(f"   📊 Analiz tablosu sayısı: {len(analysis_tables)}")
    print(f"   📁 Dosya boyutu: {os.path.getsize(output_file) / 1024 / 1024:.1f} MB")
    
    return output_file

def main():
    """Ana fonksiyon"""
    print("🚀 Citation Analysis Across AI Paradigms - Excel Generator")
    print("="*70)
    
    # Verileri analiz et
    combined_df, summary_df = analyze_paradigms()
    
    if combined_df.empty:
        print("❌ Analiz edilecek veri bulunamadı!")
        return
    
    # Detaylı analiz tabloları oluştur
    analysis_tables = create_detailed_analysis(combined_df, summary_df)
    
    # Excel dosyasına kaydet
    output_file = "/home/ubuntu/citation_analysis_across_ai_paradigms.xlsx"
    save_to_excel(combined_df, analysis_tables, output_file)
    
    # Final özet
    print(f"\n🎯 Citation Analysis Tamamlandı!")
    print(f"   📊 Analiz edilen paradigma: {combined_df['paradigm'].nunique()}")
    print(f"   📚 Toplam yayın: {len(combined_df):,}")
    print(f"   📈 Toplam atıf: {combined_df['citations'].sum():,}")
    print(f"   📅 Yıl aralığı: {combined_df['pub_year'].min():.0f}-{combined_df['pub_year'].max():.0f}")
    print(f"   📄 Excel dosyası: {output_file}")

if __name__ == "__main__":
    main()

