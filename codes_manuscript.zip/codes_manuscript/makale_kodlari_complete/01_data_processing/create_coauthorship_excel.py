#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Hibrit Yapay Zeka Co-authorship Network Analysis
Bu script, VOSviewer JSON dosyasından co-authorship verilerini analiz eder
ve makale için uygun tablolar oluşturur.
"""

import json
import pandas as pd
import numpy as np
from collections import defaultdict, Counter
import re
from docx import Document
from docx.shared import Inches, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
import warnings
warnings.filterwarnings('ignore')

def load_coauthorship_data(file_path):
    """Co-authorship JSON dosyasını yükle"""
    try:
        with open(file_path, 'r', encoding='utf-8-sig') as f:
            data = json.load(f)
        print(f"✅ Co-authorship JSON dosyası başarıyla yüklendi")
        return data
    except Exception as e:
        print(f"❌ JSON dosyası yüklenirken hata: {e}")
        return None

def analyze_coauthorship_structure(data):
    """Co-authorship ağ yapısını analiz et"""
    print("\n🔍 Co-authorship Ağ Yapısı Analizi:")
    
    if 'network' in data:
        network = data['network']
        
        if 'items' in network:
            items = network['items']
            print(f"👥 Toplam yazar sayısı: {len(items)}")
            
            # Cluster analizi
            clusters = set()
            total_documents = 0
            total_citations = 0
            total_links = 0
            avg_pub_years = []
            
            for item in items:
                if 'cluster' in item:
                    clusters.add(item['cluster'])
                if 'weights' in item:
                    weights = item['weights']
                    total_documents += weights.get('Documents', 0)
                    total_citations += weights.get('Citations', 0)
                    total_links += weights.get('Links', 0)
                if 'scores' in item and 'Avg. pub. year' in item['scores']:
                    avg_pub_years.append(item['scores']['Avg. pub. year'])
            
            print(f"🏷️ Collaboration cluster sayısı: {len(clusters)}")
            print(f"📄 Toplam makale sayısı: {total_documents}")
            print(f"📊 Toplam atıf sayısı: {total_citations:,.0f}")
            print(f"🔗 Toplam collaboration link: {total_links}")
            if avg_pub_years:
                print(f"📅 Ortalama yayın yılı: {np.mean(avg_pub_years):.1f}")
                print(f"📅 Yıl aralığı: {min(avg_pub_years):.0f} - {max(avg_pub_years):.0f}")
        
        if 'links' in network:
            links = network['links']
            print(f"🤝 Co-authorship bağlantı sayısı: {len(links)}")
    
    return data

def extract_coauthorship_data(data):
    """Co-authorship verilerini çıkar ve analiz et"""
    
    authors_data = []
    
    if 'network' in data and 'items' in data['network']:
        items = data['network']['items']
        
        for item in items:
            # Temel bilgileri çıkar
            author_info = {
                'id': item.get('id', 0),
                'label': item.get('label', ''),
                'cluster': item.get('cluster', 0),
                'x': item.get('x', 0),
                'y': item.get('y', 0)
            }
            
            # Weights bilgilerini çıkar
            if 'weights' in item:
                weights = item['weights']
                author_info['links'] = weights.get('Links', 0)
                author_info['total_link_strength'] = weights.get('Total link strength', 0)
                author_info['documents'] = weights.get('Documents', 0)
                author_info['citations'] = weights.get('Citations', 0)
                author_info['norm_citations'] = weights.get('Norm. citations', 0)
            
            # Scores bilgilerini çıkar
            if 'scores' in item:
                scores = item['scores']
                author_info['avg_pub_year'] = scores.get('Avg. pub. year', 0)
                author_info['avg_citations'] = scores.get('Avg. citations', 0)
                author_info['avg_norm_citations'] = scores.get('Avg. norm. citations', 0)
            
            authors_data.append(author_info)
    
    return authors_data

def create_coauthorship_analysis_tables(authors_data):
    """Co-authorship analizi tablolarını oluştur"""
    
    df_authors = pd.DataFrame(authors_data)
    
    print(f"\n📊 Co-authorship Analizi:")
    print(f"Toplam yazar sayısı: {len(df_authors)}")
    print(f"Cluster sayısı: {df_authors['cluster'].nunique()}")
    print(f"Toplam makale: {df_authors['documents'].sum()}")
    print(f"Toplam atıf: {df_authors['citations'].sum():,.0f}")
    
    # En produktif yazarlar (makale sayısına göre)
    top_productive_authors = df_authors.nlargest(20, 'documents')[
        ['label', 'documents', 'citations', 'avg_citations', 'links', 'total_link_strength', 'cluster', 'avg_pub_year']
    ].copy()
    
    # En çok atıf alan yazarlar
    top_cited_authors = df_authors.nlargest(20, 'citations')[
        ['label', 'documents', 'citations', 'avg_citations', 'norm_citations', 'links', 'cluster', 'avg_pub_year']
    ].copy()
    
    # En çok iş birliği yapan yazarlar (link strength'e göre)
    top_collaborative_authors = df_authors.nlargest(20, 'total_link_strength')[
        ['label', 'documents', 'citations', 'links', 'total_link_strength', 'cluster', 'avg_pub_year']
    ].copy()
    
    # Cluster analizi
    cluster_analysis = df_authors.groupby('cluster').agg({
        'documents': ['count', 'sum', 'mean'],
        'citations': ['sum', 'mean', 'max'],
        'links': ['sum', 'mean', 'max'],
        'total_link_strength': ['sum', 'mean', 'max'],
        'avg_pub_year': ['min', 'max', 'mean'],
        'label': lambda x: ', '.join(x.head(3))  # İlk 3 yazar
    }).round(3)
    
    cluster_analysis.columns = [
        'Author_Count', 'Total_Documents', 'Avg_Documents',
        'Total_Citations', 'Avg_Citations', 'Max_Citations',
        'Total_Links', 'Avg_Links', 'Max_Links',
        'Total_Link_Strength', 'Avg_Link_Strength', 'Max_Link_Strength',
        'First_Year', 'Last_Year', 'Avg_Year', 'Sample_Authors'
    ]
    cluster_analysis = cluster_analysis.reset_index()
    
    # En aktif collaboration cluster'ları
    top_collaboration_clusters = cluster_analysis.nlargest(15, 'Total_Link_Strength')
    
    return df_authors, top_productive_authors, top_cited_authors, top_collaborative_authors, cluster_analysis, top_collaboration_clusters

def assign_collaboration_cluster_names(cluster_analysis, df_authors):
    """Collaboration cluster'lara açıklayıcı isimler ata"""
    
    cluster_names = {}
    
    for _, row in cluster_analysis.iterrows():
        cluster_id = row['cluster']
        sample_authors = row['Sample_Authors'].lower()
        avg_year = row['Avg_Year']
        total_strength = row['Total_Link_Strength']
        author_count = row['Author_Count']
        
        # Cluster'daki tüm yazarları al
        cluster_authors = df_authors[df_authors['cluster'] == cluster_id]['label'].str.lower().str.cat(sep=' ')
        
        # Cluster ismini belirle (yazar isimlerinden ve istatistiklerden)
        if any(name in cluster_authors for name in ['yann lecun', 'yoshua bengio', 'geoffrey hinton']):
            cluster_names[cluster_id] = "Deep Learning Pioneers"
        elif any(name in cluster_authors for name in ['fuzzy', 'neuro-fuzzy', 'anfis']):
            cluster_names[cluster_id] = "Fuzzy Logic & Soft Computing Researchers"
        elif any(name in cluster_authors for name in ['genetic', 'evolutionary', 'optimization']):
            cluster_names[cluster_id] = "Evolutionary Computing Researchers"
        elif any(name in cluster_authors for name in ['ensemble', 'random forest', 'boosting']):
            cluster_names[cluster_id] = "Ensemble Learning Researchers"
        elif any(name in cluster_authors for name in ['neural network', 'artificial neural']):
            cluster_names[cluster_id] = "Neural Network Researchers"
        elif any(name in cluster_authors for name in ['machine learning', 'data mining']):
            cluster_names[cluster_id] = "Machine Learning Researchers"
        elif any(name in cluster_authors for name in ['computer vision', 'image processing']):
            cluster_names[cluster_id] = "Computer Vision Researchers"
        elif any(name in cluster_authors for name in ['natural language', 'text mining']):
            cluster_names[cluster_id] = "NLP & Text Mining Researchers"
        elif any(name in cluster_authors for name in ['robotics', 'control', 'autonomous']):
            cluster_names[cluster_id] = "Robotics & Control Researchers"
        elif any(name in cluster_authors for name in ['medical', 'healthcare', 'biomedical']):
            cluster_names[cluster_id] = "Medical AI Researchers"
        elif total_strength > 1000:
            cluster_names[cluster_id] = f"High-Impact Collaboration Group {cluster_id}"
        elif author_count > 50:
            cluster_names[cluster_id] = f"Large Research Community {cluster_id}"
        elif avg_year > 2015:
            cluster_names[cluster_id] = f"Modern AI Research Group {cluster_id}"
        elif avg_year < 2005:
            cluster_names[cluster_id] = f"Classical AI Research Group {cluster_id}"
        else:
            cluster_names[cluster_id] = f"Specialized Research Cluster {cluster_id}"
    
    return cluster_names

def create_comprehensive_coauthorship_document(df_authors, top_productive_authors, top_cited_authors, top_collaborative_authors, cluster_analysis, top_collaboration_clusters, cluster_names):
    """Kapsamlı Co-authorship Word belgesi oluştur"""
    
    doc = Document()
    
    # Başlık
    title = doc.add_heading('Hybrid Artificial Intelligence: Comprehensive Co-authorship Network Analysis', 0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    # Özet Bilgiler
    summary_heading = doc.add_heading('Executive Summary', level=1)
    
    summary = doc.add_paragraph()
    summary.add_run("Bu kapsamlı co-authorship network analysis, hibrit yapay zeka alanındaki araştırmacılar arası iş birliği ağlarını, collaboration patterns'ları ve research communities'leri VOSviewer analizi sonuçlarına dayanarak sistematik olarak incelemektedir. ")
    summary.add_run("Analiz kapsamında ").bold = True
    summary.add_run(f"{len(df_authors)} aktif araştırmacı, {len(cluster_analysis)} collaboration cluster ve ")
    summary.add_run(f"{df_authors['documents'].sum()} makale üzerinden oluşan co-authorship network ")
    summary.add_run("detaylı şekilde haritalandırılmıştır.")
    
    summary2 = doc.add_paragraph()
    summary2.add_run(f"Toplam {df_authors['citations'].sum():,.0f} atıf ve {df_authors['total_link_strength'].sum():,.0f} collaboration strength ile hibrit yapay zeka alanının research collaboration ecosystem'i quantitatif olarak ortaya konmuş, ")
    summary2.add_run("en produktif araştırmacılardan en güçlü collaboration cluster'larına kadar alanın academic social network'ü çıkarılmıştır.")
    
    # Tablo 1: En Produktif Yazarlar
    doc.add_heading('Table 1: Most Productive Authors in Hybrid AI Research', level=1)
    
    table1_desc = doc.add_paragraph()
    table1_desc.add_run("Bu tablo, hibrit yapay zeka alanında en yüksek makale üretimine sahip 20 araştırmacıyı göstermektedir. ")
    table1_desc.add_run("Documents sütunu toplam makale sayısını, Citations toplam atıf sayısını, Links ise co-authorship bağlantı sayısını belirtmektedir. ")
    table1_desc.add_run("Total Link Strength, yazarın collaboration network'ündeki toplam bağlantı gücünü yansıtarak research community'deki etkisini göstermektedir. ")
    table1_desc.add_run("Bu araştırmacılar, hibrit AI alanının en aktif ve produktif academic contributors'larını temsil etmektedir.")
    
    # Tablo 1 oluştur
    table1 = doc.add_table(rows=1, cols=8)
    table1.style = 'Table Grid'
    table1.alignment = WD_TABLE_ALIGNMENT.CENTER
    
    # Başlık satırı
    hdr_cells1 = table1.rows[0].cells
    hdr_cells1[0].text = 'Rank'
    hdr_cells1[1].text = 'Author'
    hdr_cells1[2].text = 'Documents'
    hdr_cells1[3].text = 'Citations'
    hdr_cells1[4].text = 'Avg Citations'
    hdr_cells1[5].text = 'Links'
    hdr_cells1[6].text = 'Link Strength'
    hdr_cells1[7].text = 'Research Period'
    
    # Başlık satırını kalın yap
    for cell in hdr_cells1:
        for paragraph in cell.paragraphs:
            for run in paragraph.runs:
                run.font.bold = True
    
    # Veri satırları
    for i, (_, row) in enumerate(top_productive_authors.iterrows(), 1):
        row_cells = table1.add_row().cells
        row_cells[0].text = str(i)
        row_cells[1].text = str(row['label']).title()
        row_cells[2].text = str(row['documents'])
        row_cells[3].text = f"{row['citations']:,.0f}"
        row_cells[4].text = f"{row['avg_citations']:.1f}"
        row_cells[5].text = str(row['links'])
        row_cells[6].text = f"{row['total_link_strength']:.0f}"
        # Research period hesapla (ortalama yıldan ±5 yıl)
        avg_year = row['avg_pub_year']
        period = f"{avg_year-2:.0f}-{avg_year+2:.0f}"
        row_cells[7].text = period
    
    doc.add_paragraph()
    
    # Tablo 2: En Çok Atıf Alan Yazarlar
    doc.add_heading('Table 2: Most Cited Authors in Hybrid AI Research', level=1)
    
    table2_desc = doc.add_paragraph()
    table2_desc.add_run("Bu tablo, hibrit yapay zeka alanında en yüksek citation impact'e sahip 20 araştırmacıyı göstermektedir. ")
    table2_desc.add_run("Bu araştırmacılar, hibrit AI'ın akademik gelişiminde en etkili olan ve alanın bilimsel prestijini belirleyen leading scholars'ı temsil etmektedir. ")
    table2_desc.add_run("Normalized Citations değeri, yayın yılına göre normalize edilmiş akademik etkiyi yansıtırken, ")
    table2_desc.add_run("Links sütunu yazarın co-authorship network'ündeki collaboration diversity'sini göstermektedir.")
    
    # Tablo 2 oluştur
    table2 = doc.add_table(rows=1, cols=7)
    table2.style = 'Table Grid'
    table2.alignment = WD_TABLE_ALIGNMENT.CENTER
    
    # Başlık satırı
    hdr_cells2 = table2.rows[0].cells
    hdr_cells2[0].text = 'Rank'
    hdr_cells2[1].text = 'Author'
    hdr_cells2[2].text = 'Documents'
    hdr_cells2[3].text = 'Total Citations'
    hdr_cells2[4].text = 'Avg Citations'
    hdr_cells2[5].text = 'Norm. Citations'
    hdr_cells2[6].text = 'Collaboration Links'
    
    # Başlık satırını kalın yap
    for cell in hdr_cells2:
        for paragraph in cell.paragraphs:
            for run in paragraph.runs:
                run.font.bold = True
    
    # Veri satırları
    for i, (_, row) in enumerate(top_cited_authors.iterrows(), 1):
        row_cells = table2.add_row().cells
        row_cells[0].text = str(i)
        row_cells[1].text = str(row['label']).title()
        row_cells[2].text = str(row['documents'])
        row_cells[3].text = f"{row['citations']:,.0f}"
        row_cells[4].text = f"{row['avg_citations']:.1f}"
        row_cells[5].text = f"{row['norm_citations']:.2f}"
        row_cells[6].text = str(row['links'])
    
    doc.add_paragraph()
    
    # Tablo 3: En Çok İş Birliği Yapan Yazarlar
    doc.add_heading('Table 3: Most Collaborative Authors in Hybrid AI Research', level=1)
    
    table3_desc = doc.add_paragraph()
    table3_desc.add_run("Bu tablo, hibrit yapay zeka alanında en güçlü collaboration network'üne sahip 20 araştırmacıyı göstermektedir. ")
    table3_desc.add_run("Total Link Strength, yazarın co-authorship network'ündeki toplam bağlantı gücünü yansıtarak research collaboration'daki merkezi rolünü belirtmektedir. ")
    table3_desc.add_run("Links sütunu, yazarın kaç farklı araştırmacıyla iş birliği yaptığını gösterirken, ")
    table3_desc.add_run("bu araştırmacılar hibrit AI community'sinin collaboration hub'larını ve network connector'larını temsil etmektedir.")
    
    # Tablo 3 oluştur
    table3 = doc.add_table(rows=1, cols=7)
    table3.style = 'Table Grid'
    table3.alignment = WD_TABLE_ALIGNMENT.CENTER
    
    # Başlık satırı
    hdr_cells3 = table3.rows[0].cells
    hdr_cells3[0].text = 'Rank'
    hdr_cells3[1].text = 'Author'
    hdr_cells3[2].text = 'Documents'
    hdr_cells3[3].text = 'Citations'
    hdr_cells3[4].text = 'Links'
    hdr_cells3[5].text = 'Link Strength'
    hdr_cells3[6].text = 'Active Period'
    
    # Başlık satırını kalın yap
    for cell in hdr_cells3:
        for paragraph in cell.paragraphs:
            for run in paragraph.runs:
                run.font.bold = True
    
    # Veri satırları
    for i, (_, row) in enumerate(top_collaborative_authors.iterrows(), 1):
        row_cells = table3.add_row().cells
        row_cells[0].text = str(i)
        row_cells[1].text = str(row['label']).title()
        row_cells[2].text = str(row['documents'])
        row_cells[3].text = f"{row['citations']:,.0f}"
        row_cells[4].text = str(row['links'])
        row_cells[5].text = f"{row['total_link_strength']:.0f}"
        # Active period hesapla
        avg_year = row['avg_pub_year']
        period = f"{avg_year-3:.0f}-{avg_year+3:.0f}"
        row_cells[6].text = period
    
    doc.add_paragraph()
    
    # Tablo 4: En Aktif Collaboration Cluster'ları
    doc.add_heading('Table 4: Most Active Collaboration Clusters in Hybrid AI', level=1)
    
    table4_desc = doc.add_paragraph()
    table4_desc.add_run("Bu tablo, hibrit yapay zeka alanındaki en aktif 15 collaboration cluster'ını göstermektedir. ")
    table4_desc.add_run("Her cluster, benzer araştırma alanlarında çalışan ve yoğun iş birliği içinde olan araştırmacı gruplarını temsil etmektedir. ")
    table4_desc.add_run("Total Link Strength, cluster içindeki toplam collaboration gücünü; Author Count ise cluster büyüklüğünü belirtmektedir. ")
    table4_desc.add_run("Bu cluster'lar, hibrit AI research community'sinin tematik yapısını ve collaboration patterns'larını ortaya koymaktadır.")
    
    # Cluster analizi tablosunu güncelle
    cluster_analysis_named = top_collaboration_clusters.copy()
    cluster_analysis_named['Cluster_Name'] = cluster_analysis_named['cluster'].map(cluster_names)
    
    # Tablo 4 oluştur
    table4 = doc.add_table(rows=1, cols=8)
    table4.style = 'Table Grid'
    table4.alignment = WD_TABLE_ALIGNMENT.CENTER
    
    # Başlık satırı
    hdr_cells4 = table4.rows[0].cells
    hdr_cells4[0].text = 'Rank'
    hdr_cells4[1].text = 'Research Community'
    hdr_cells4[2].text = 'Authors'
    hdr_cells4[3].text = 'Documents'
    hdr_cells4[4].text = 'Citations'
    hdr_cells4[5].text = 'Links'
    hdr_cells4[6].text = 'Link Strength'
    hdr_cells4[7].text = 'Active Period'
    
    # Başlık satırını kalın yap
    for cell in hdr_cells4:
        for paragraph in cell.paragraphs:
            for run in paragraph.runs:
                run.font.bold = True
    
    # Veri satırları
    for i, (_, row) in enumerate(cluster_analysis_named.iterrows(), 1):
        row_cells = table4.add_row().cells
        row_cells[0].text = str(i)
        row_cells[1].text = str(row['Cluster_Name'])
        row_cells[2].text = str(row['Author_Count'])
        row_cells[3].text = str(row['Total_Documents'])
        row_cells[4].text = f"{row['Total_Citations']:,.0f}"
        row_cells[5].text = str(row['Total_Links'])
        row_cells[6].text = f"{row['Total_Link_Strength']:.0f}"
        active_period = f"{row['First_Year']:.0f}-{row['Last_Year']:.0f}"
        row_cells[7].text = active_period
    
    # Metodoloji
    doc.add_heading('Methodology', level=1)
    
    method = doc.add_paragraph()
    method.add_run("Bu comprehensive co-authorship network analysis, VOSviewer bibliometrik analiz yazılımının co-authorship analizi özelliği kullanılarak gerçekleştirilmiştir. ")
    method.add_run("Hibrit yapay zeka alanındaki akademik yayınlardan elde edilen co-authorship verileri, ")
    method.add_run("network analizi teknikleriyle işlenmiş ve collaboration cluster'larına ayrılmıştır. ")
    method.add_run("Link strength, iki yazarın birlikte yayın yapma sıklığına dayalı olarak hesaplanmış, ")
    method.add_run("cluster'lar ise co-authorship patterns'larına göre oluşturulmuştur. ")
    method.add_run("Minimum 5 makale threshold'u uygulanarak sadece aktif araştırmacılar analiz kapsamına alınmıştır.")
    
    # Sonuç ve Değerlendirme
    doc.add_heading('Key Findings and Collaboration Insights', level=1)
    
    conclusion1 = doc.add_paragraph()
    most_productive = top_productive_authors.iloc[0]
    conclusion1.add_run("Bu kapsamlı co-authorship network analysis, hibrit yapay zeka alanının collaboration ecosystem'ini ve research community dynamics'ini quantitatif olarak ortaya koymaktadır. ")
    conclusion1.add_run(f"En produktif araştırmacı olan {most_productive['label'].title()} ")
    conclusion1.add_run(f"({most_productive['documents']} makale, {most_productive['citations']:,.0f} atıf) ile alanın academic productivity leadership'i belirlenmiştir.")
    
    conclusion2 = doc.add_paragraph()
    most_cited = top_cited_authors.iloc[0]
    most_collaborative = top_collaborative_authors.iloc[0]
    conclusion2.add_run(f"Citation impact açısından {most_cited['label'].title()} ")
    conclusion2.add_run(f"({most_cited['citations']:,.0f} toplam atıf), collaboration strength açısından ise {most_collaborative['label'].title()} ")
    conclusion2.add_run(f"({most_collaborative['total_link_strength']:.0f} link strength) alanın leading researchers'ları olarak öne çıkmaktadır. ")
    conclusion2.add_run("Bu bulgular, hibrit AI community'sinde productivity, impact ve collaboration'ın farklı araştırmacılarda yoğunlaştığını göstermektedir.")
    
    conclusion3 = doc.add_paragraph()
    top_cluster = cluster_analysis_named.iloc[0]
    conclusion3.add_run(f"Collaboration cluster analizi, hibrit AI research community'sinin {len(cluster_analysis)} farklı tematik grupta organize olduğunu ortaya koymaktadır. ")
    conclusion3.add_run(f"En aktif collaboration cluster olan '{top_cluster['Cluster_Name']}' ")
    conclusion3.add_run(f"({top_cluster['Author_Count']} araştırmacı, {top_cluster['Total_Link_Strength']:.0f} link strength) ")
    conclusion3.add_run("alanın collaboration hub'ını oluşturmakta ve research network'ün merkezi yapısını belirlemektedir.")
    
    return doc

def main():
    """Ana fonksiyon"""
    print("🚀 Hibrit AI Co-authorship Network Analysis Başlatılıyor...")
    
    # JSON dosyasını yükle
    json_file = "/home/ubuntu/upload/author_network.json"
    data = load_coauthorship_data(json_file)
    
    if data is None:
        return
    
    # Co-authorship ağ yapısını analiz et
    analyze_coauthorship_structure(data)
    
    # Co-authorship verilerini çıkar
    authors_data = extract_coauthorship_data(data)
    
    if not authors_data:
        print("❌ Co-authorship verisi bulunamadı!")
        return
    
    # Analiz tablolarını oluştur
    df_authors, top_productive_authors, top_cited_authors, top_collaborative_authors, cluster_analysis, top_collaboration_clusters = create_coauthorship_analysis_tables(authors_data)
    
    # Cluster isimlerini ata
    cluster_names = assign_collaboration_cluster_names(cluster_analysis, df_authors)
    
    print("\n📊 Collaboration Cluster İsimleri:")
    for cluster_id, name in sorted(cluster_names.items()):
        print(f"  Cluster {cluster_id}: {name}")
    
    # Word belgesi oluştur
    doc = create_comprehensive_coauthorship_document(df_authors, top_productive_authors, top_cited_authors, top_collaborative_authors, cluster_analysis, top_collaboration_clusters, cluster_names)
    
    # Dosyayı kaydet
    output_file = "/home/ubuntu/hybrid_ai_coauthorship_network_analysis.docx"
    doc.save(output_file)
    
    print(f"\n✅ Co-authorship Network Analysis tamamlandı!")
    print(f"📄 Word belgesi kaydedildi: {output_file}")
    print(f"👥 Toplam yazar: {len(df_authors)}")
    print(f"📋 Toplam cluster: {len(cluster_analysis)}")
    print(f"📄 Toplam makale: {df_authors['documents'].sum()}")
    print(f"📈 Toplam atıf: {df_authors['citations'].sum():,.0f}")
    
    # Özet istatistikler
    print(f"\n📈 Özet İstatistikler:")
    print(f"  - En produktif yazar: {top_productive_authors.iloc[0]['label'].title()} ({top_productive_authors.iloc[0]['documents']} makale)")
    print(f"  - En çok atıf alan yazar: {top_cited_authors.iloc[0]['label'].title()} ({top_cited_authors.iloc[0]['citations']:,.0f} atıf)")
    print(f"  - En çok iş birliği yapan yazar: {top_collaborative_authors.iloc[0]['label'].title()} ({top_collaborative_authors.iloc[0]['total_link_strength']:.0f} link strength)")
    print(f"  - En aktif cluster: {cluster_names[top_collaboration_clusters.iloc[0]['cluster']]} ({top_collaboration_clusters.iloc[0]['Author_Count']} yazar)")

if __name__ == "__main__":
    main()

