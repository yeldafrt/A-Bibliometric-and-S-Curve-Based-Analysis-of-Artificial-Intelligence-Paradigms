#!/usr/bin/env python3
"""
Top Cited Works Analysis
Excel dosyasındaki Top Cited Works sayfasını analiz eder
"""

import pandas as pd
import numpy as np

def analyze_top_cited_works():
    """Top Cited Works sayfasını analiz eder"""
    print("🔍 Top Cited Works Sayfası Analizi")
    print("="*50)
    
    try:
        # Excel dosyasını yükle
        excel_file = "/home/ubuntu/citation_analysis_across_ai_paradigms.xlsx"
        
        # Ana veri ve Top Cited Works sayfasını yükle
        all_data = pd.read_excel(excel_file, sheet_name='All Citation Data')
        top_cited = pd.read_excel(excel_file, sheet_name='Top Cited Works')
        
        print(f"📊 Ana veri: {len(all_data):,} yayın")
        print(f"📊 Top Cited Works: {len(top_cited)} yayın")
        
        # Top Cited Works'ün ne olduğunu açıkla
        print(f"\n📋 'Top Cited Works' Sayfası Nedir?")
        print("="*50)
        print("Bu sayfa, TÜM paradigmalar arasından en çok atıf alan 50 yayını içerir.")
        print("Atıf sayısına göre sıralanmış, paradigma fark etmeksizin en etkili yayınlar.")
        
        # Paradigma dağılımını analiz et
        print(f"\n📊 Top 50'deki Paradigma Dağılımı:")
        print("="*50)
        
        paradigm_dist = top_cited['paradigm'].value_counts()
        total_top = len(top_cited)
        
        for paradigm, count in paradigm_dist.items():
            percentage = (count / total_top) * 100
            print(f"🔹 {paradigm}: {count} yayın ({percentage:.1f}%)")
        
        # Hibrit AI'nın neden olmadığını açıkla
        print(f"\n❓ Hibrit AI Neden Yok?")
        print("="*50)
        
        # Her paradigmanın en yüksek atıf sayısını bul
        paradigm_max = all_data.groupby('paradigm')['citations'].agg(['max', 'mean', 'count'])
        
        print("Paradigma bazında en yüksek atıf sayıları:")
        for paradigm, stats in paradigm_max.iterrows():
            print(f"🔹 {paradigm}:")
            print(f"   • En yüksek atıf: {stats['max']:,}")
            print(f"   • Ortalama atıf: {stats['mean']:.1f}")
            print(f"   • Yayın sayısı: {stats['count']:,}")
        
        # Top 50'nin minimum atıf sayısını bul
        min_top50_citations = top_cited['citations'].min()
        print(f"\n📊 Top 50'ye girmek için minimum atıf: {min_top50_citations:,}")
        
        # Hibrit AI'nın en iyi yayınlarını göster
        hybrid_data = all_data[all_data['paradigm'] == 'Hybrid AI']
        top_hybrid = hybrid_data.nlargest(10, 'citations')[['title', 'authors', 'pub_year', 'citations']]
        
        print(f"\n🔹 Hibrit AI'nın En İyi 10 Yayını:")
        print("="*50)
        
        for i, (_, work) in enumerate(top_hybrid.iterrows(), 1):
            title = work['title'][:60] + "..." if len(work['title']) > 60 else work['title']
            print(f"{i:2d}. {work['citations']:,} atıf ({work['pub_year']:.0f})")
            print(f"    📖 {title}")
        
        # Karşılaştırma
        print(f"\n📊 Karşılaştırma:")
        print("="*50)
        print(f"• Top 50'ye girmek için: {min_top50_citations:,} atıf gerekli")
        print(f"• Hibrit AI'nın en iyisi: {hybrid_data['citations'].max():,} atıf")
        print(f"• Fark: {min_top50_citations - hybrid_data['citations'].max():,} atıf")
        
        if hybrid_data['citations'].max() < min_top50_citations:
            print("❌ Hibrit AI'nın hiçbir yayını Top 50'ye giremiyor!")
        else:
            print("✅ Hibrit AI'nın bazı yayınları Top 50'de olmalı!")
        
        # Detaylı analiz
        print(f"\n📈 Detaylı Atıf Analizi:")
        print("="*50)
        
        # Atıf aralıklarına göre dağılım
        ranges = [
            (0, 100, "0-100"),
            (100, 500, "100-500"), 
            (500, 1000, "500-1K"),
            (1000, 5000, "1K-5K"),
            (5000, 10000, "5K-10K"),
            (10000, float('inf'), "10K+")
        ]
        
        for paradigm in all_data['paradigm'].unique():
            paradigm_data = all_data[all_data['paradigm'] == paradigm]
            print(f"\n🔹 {paradigm} - Atıf Aralığı Dağılımı:")
            
            for min_val, max_val, label in ranges:
                count = len(paradigm_data[(paradigm_data['citations'] >= min_val) & 
                                        (paradigm_data['citations'] < max_val)])
                if count > 0:
                    percentage = (count / len(paradigm_data)) * 100
                    print(f"   {label:>8}: {count:4d} yayın ({percentage:4.1f}%)")
        
        return top_cited, hybrid_data
        
    except Exception as e:
        print(f"❌ Hata: {e}")
        return None, None

def main():
    """Ana fonksiyon"""
    top_cited, hybrid_data = analyze_top_cited_works()
    
    if top_cited is not None:
        print(f"\n✅ Analiz tamamlandı!")
        print(f"\n💡 SONUÇ:")
        print("Top Cited Works sayfası, paradigma fark etmeksizin")
        print("en çok atıf alan 50 yayını içerir. Hibrit AI'nın")
        print("atıf sayıları diğer paradigmalara göre düşük olduğu")
        print("için bu listede yer alamıyor.")

if __name__ == "__main__":
    main()

