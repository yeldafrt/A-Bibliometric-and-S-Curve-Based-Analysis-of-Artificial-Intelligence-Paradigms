#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Figure 6: Comparative Author Network Metrics Across AI Paradigms (1956–2024)
Bu script, makaledeki Figure 6'yı oluşturur - 3 panelli bar chart
(a) Avg Link Strength, (b) Avg Centrality, (c) Avg Citations
"""

import json
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import warnings
warnings.filterwarnings('ignore')

# Görsel ayarları
plt.rcParams['figure.dpi'] = 300
plt.rcParams['savefig.dpi'] = 300
plt.rcParams['font.size'] = 11
plt.rcParams['axes.titlesize'] = 12
plt.rcParams['axes.labelsize'] = 11
plt.rcParams['xtick.labelsize'] = 10
plt.rcParams['ytick.labelsize'] = 10
plt.rcParams['legend.fontsize'] = 10
plt.rcParams['font.family'] = 'sans-serif'

def load_coauthorship_data(file_path):
    """Co-authorship JSON dosyasını yükle"""
    try:
        with open(file_path, 'r', encoding='utf-8-sig') as f:
            data = json.load(f)
        print(f"✅ JSON yüklendi: {file_path}")
        return data
    except Exception as e:
        print(f"❌ JSON yüklenemedi: {e}")
        return None

def extract_coauthorship_data(data, paradigm_name):
    """Co-authorship verilerini çıkar"""
    authors_data = []
    
    if 'network' in data and 'items' in data['network']:
        items = data['network']['items']
        
        for item in items:
            author_info = {
                'label': item.get('label', ''),
                'paradigm': paradigm_name
            }
            
            # Weights bilgilerini çıkar
            if 'weights' in item:
                weights = item['weights']
                author_info['links'] = weights.get('Links', 0)
                author_info['total_link_strength'] = weights.get('Total link strength', 0)
                author_info['documents'] = weights.get('Documents', 0)
                author_info['citations'] = weights.get('Citations', 0)
            
            # Scores bilgilerini çıkar
            if 'scores' in item:
                scores = item['scores']
                author_info['avg_citations'] = scores.get('Avg. citations', 0)
            
            authors_data.append(author_info)
    
    return authors_data

def calculate_paradigm_metrics():
    """Paradigma bazında metrikleri hesapla"""
    
    # JSON dosyaları
    json_files = [
        ('dataset/dataset/json_co_authorship/authorship_sembolic.json', 'Symbolic AI'),
        ('dataset/dataset/json_co_authorship/authorship_statical.json', 'Statistical AI'),
        ('dataset/dataset/json_co_authorship/authorship_hibrid.json', 'Hybrid AI')
    ]
    
    all_data = []
    
    for json_file, paradigm_name in json_files:
        print(f"📊 {paradigm_name} verisi yükleniyor...")
        data = load_coauthorship_data(json_file)
        if data:
            authors_data = extract_coauthorship_data(data, paradigm_name)
            all_data.extend(authors_data)
    
    # DataFrame oluştur
    df = pd.DataFrame(all_data)
    
    # Paradigma bazında metrikleri hesapla
    metrics = []
    
    for paradigm in ['Symbolic AI', 'Statistical AI', 'Hybrid AI']:
        paradigm_data = df[df['paradigm'] == paradigm]
        
        if len(paradigm_data) > 0:
            # Ortalama değerleri hesapla
            avg_link_strength = paradigm_data['total_link_strength'].mean()
            avg_centrality = paradigm_data['links'].mean()
            avg_citations = paradigm_data['citations'].mean()
            
            metrics.append({
                'paradigm': paradigm,
                'avg_link_strength': avg_link_strength,
                'avg_centrality': avg_centrality,
                'avg_citations': avg_citations,
                'author_count': len(paradigm_data)
            })
            
            print(f"{paradigm}:")
            print(f"  - Yazar sayısı: {len(paradigm_data)}")
            print(f"  - Avg Link Strength: {avg_link_strength:.2f}")
            print(f"  - Avg Centrality: {avg_centrality:.2f}")
            print(f"  - Avg Citations: {avg_citations:.2f}")
    
    return pd.DataFrame(metrics)

def create_figure6():
    """Figure 6: 3 panelli bar chart oluştur"""
    
    print("🎨 Figure 6 oluşturuluyor...")
    
    # Metrikleri hesapla
    metrics_df = calculate_paradigm_metrics()
    
    # Figure oluştur (1 satır, 3 sütun)
    fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(15, 5))
    
    # Paradigma isimleri ve renk
    paradigms = metrics_df['paradigm'].tolist()
    color = '#4472C4'  # Mavi renk (görüntüdeki gibi)
    
    # X pozisyonları
    x_pos = np.arange(len(paradigms))
    
    # (a) Avg Link Strength
    bars1 = ax1.bar(x_pos, metrics_df['avg_link_strength'], color=color, alpha=0.8, 
                    edgecolor='black', linewidth=0.5)
    ax1.set_title('(a) Avg Link Strength', fontweight='bold', pad=15)
    ax1.set_ylabel('Avg Link Strength')
    ax1.set_xticks(x_pos)
    ax1.set_xticklabels(paradigms, rotation=0)
    ax1.grid(True, alpha=0.3, axis='y')
    ax1.set_ylim(0, max(metrics_df['avg_link_strength']) * 1.1)
    
    # Değerleri bar'ların üzerine yaz
    for bar, value in zip(bars1, metrics_df['avg_link_strength']):
        ax1.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.2, 
                f'{value:.1f}', ha='center', va='bottom', fontweight='bold', fontsize=9)
    
    # (b) Avg Centrality
    bars2 = ax2.bar(x_pos, metrics_df['avg_centrality'], color=color, alpha=0.8,
                    edgecolor='black', linewidth=0.5)
    ax2.set_title('(b) Avg Centrality', fontweight='bold', pad=15)
    ax2.set_ylabel('Avg Centrality')
    ax2.set_xticks(x_pos)
    ax2.set_xticklabels(paradigms, rotation=0)
    ax2.grid(True, alpha=0.3, axis='y')
    ax2.set_ylim(0, max(metrics_df['avg_centrality']) * 1.1)
    
    # Değerleri bar'ların üzerine yaz
    for bar, value in zip(bars2, metrics_df['avg_centrality']):
        ax2.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.1, 
                f'{value:.1f}', ha='center', va='bottom', fontweight='bold', fontsize=9)
    
    # (c) Avg Citations
    bars3 = ax3.bar(x_pos, metrics_df['avg_citations'], color=color, alpha=0.8,
                    edgecolor='black', linewidth=0.5)
    ax3.set_title('(c) Avg Citations', fontweight='bold', pad=15)
    ax3.set_ylabel('Avg Citations')
    ax3.set_xticks(x_pos)
    ax3.set_xticklabels(paradigms, rotation=0)
    ax3.grid(True, alpha=0.3, axis='y')
    ax3.set_ylim(0, max(metrics_df['avg_citations']) * 1.1)
    
    # Değerleri bar'ların üzerine yaz
    for bar, value in zip(bars3, metrics_df['avg_citations']):
        ax3.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 10, 
                f'{value:.0f}', ha='center', va='bottom', fontweight='bold', fontsize=9)
    
    # Genel ayarlar
    plt.tight_layout()
    plt.subplots_adjust(wspace=0.3)
    
    return fig, metrics_df

def save_figure(fig, filename):
    """Figure'ı kaydet"""
    output_path = f"{filename}"
    fig.savefig(output_path, dpi=300, bbox_inches='tight', 
               facecolor='white', edgecolor='none')
    print(f"✅ Figure kaydedildi: {output_path}")
    return output_path

def print_metrics_summary(metrics_df):
    """Metriklerin özetini yazdır"""
    print("\n📊 Figure 6 Metrikleri:")
    print("="*50)
    for _, row in metrics_df.iterrows():
        print(f"\n{row['paradigm']}:")
        print(f"  👥 Yazar sayısı: {row['author_count']}")
        print(f"  🔗 Avg Link Strength: {row['avg_link_strength']:.2f}")
        print(f"  🎯 Avg Centrality: {row['avg_centrality']:.2f}")
        print(f"  📊 Avg Citations: {row['avg_citations']:.1f}")

def main():
    """Ana fonksiyon"""
    print("🚀 Figure 6: Comparative Author Network Metrics Generator")
    print("="*60)
    
    # Figure 6'yı oluştur
    fig, metrics_df = create_figure6()
    
    # Kaydet
    save_figure(fig, "figure6_comparative_author_network_metrics22222222.png")
    
    # Metriklerin özetini yazdır
    print_metrics_summary(metrics_df)
    
    print(f"\n🎯 Figure 6 Açıklaması:")
    print(f"Bu grafik, üç AI paradigmasının yazar ağı metriklerini karşılaştırır:")
    print(f"(a) Avg Link Strength - Yazarlar arası ortalama bağlantı gücü")
    print(f"(b) Avg Centrality - Yazarların ağdaki ortalama merkezi konumu")
    print(f"(c) Avg Citations - Yazarların ortalama atıf sayısı")
    
    print(f"\n📈 Ana Bulgular:")
    print(f"• Statistical AI en yüksek link strength ve citations'a sahip")
    print(f"• Hybrid AI en yüksek centrality'ye sahip")
    print(f"• Symbolic AI tüm metriklerde en düşük değerlere sahip")

if __name__ == "__main__":
    main()

