#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Comparative AI S-Curve Analysis
Üç AI paradigmasının (Symbolic, Statistical, Hybrid) karşılaştırmalı S-eğrisi analizi
Ekteki comparative_ai_s_curves.png formatında
"""

import json
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
import os
import glob
import re
import warnings
warnings.filterwarnings('ignore')

# Set matplotlib parameters for high-quality visualization
plt.rcParams['figure.figsize'] = (14, 10)
plt.rcParams['font.size'] = 14
plt.rcParams['axes.titlesize'] = 16
plt.rcParams['axes.labelsize'] = 14
plt.rcParams['xtick.labelsize'] = 12
plt.rcParams['ytick.labelsize'] = 12
plt.rcParams['legend.fontsize'] = 12

def load_paradigm_data(paradigm_name, data_dir):
    """Load data for a specific paradigm"""
    json_files = glob.glob(os.path.join(data_dir, "*.json"))
    all_publications = []
    
    for file_path in json_files:
        print(f"Loading {paradigm_name}: {os.path.basename(file_path)}")
        try:
            # Read file and clean invalid control characters
            with open(file_path, 'rb') as f:
                raw_content = f.read()
            
            # Decode with error handling
            try:
                content = raw_content.decode('utf-8-sig')
            except UnicodeDecodeError:
                content = raw_content.decode('utf-8-sig', errors='ignore')
            
            # Remove invalid control characters and fix common JSON issues
            content = re.sub(r'[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]', '', content)
            content = re.sub(r'[\r\n\t]+', ' ', content)  # Normalize whitespace
            content = re.sub(r'\s+', ' ', content)  # Remove extra spaces
            
            # Try to parse JSON
            data = json.loads(content)
                
            # Extract publications from network items
            if 'network' in data and 'items' in data['network']:
                for item in data['network']['items']:
                    pub_data = {
                        'id': item.get('id'),
                        'label': item.get('label', ''),
                        'year': item.get('scores', {}).get('Pub. year', 0),
                        'citations': item.get('scores', {}).get('Citations', 0),
                        'norm_citations': item.get('scores', {}).get('Norm. citations', 0),
                        'cluster': item.get('cluster', 0)
                    }
                    
                    # Only include valid years
                    if pub_data['year'] >= 1956 and pub_data['year'] <= 2024:
                        all_publications.append(pub_data)
                        
        except Exception as e:
            print(f"Error loading {file_path}: {e}")
            continue
    
    return pd.DataFrame(all_publications)

def s_curve_function(x, L, k, x0):
    """Logistic S-curve function"""
    return L / (1 + np.exp(-k * (x - x0)))

def fit_s_curve(years, cumulative_data):
    """Fit S-curve to cumulative data"""
    try:
        # Initial parameter estimates
        L_init = max(cumulative_data) * 1.1  # Carrying capacity
        k_init = 0.1  # Growth rate
        x0_init = np.median(years)  # Inflection point
        
        # Fit the curve
        popt, pcov = curve_fit(
            s_curve_function, 
            years, 
            cumulative_data,
            p0=[L_init, k_init, x0_init],
            maxfev=5000,
            bounds=([0, 0, min(years)], [np.inf, 1, max(years)])
        )
        
        # Calculate R-squared
        y_pred = s_curve_function(years, *popt)
        ss_res = np.sum((cumulative_data - y_pred) ** 2)
        ss_tot = np.sum((cumulative_data - np.mean(cumulative_data)) ** 2)
        r_squared = 1 - (ss_res / ss_tot)
        
        return popt, r_squared
    except Exception as e:
        print(f"S-curve fitting error: {e}")
        return None, 0

def create_comparative_s_curves():
    """Create comparative S-curve analysis for all three AI paradigms"""
    
    # Data directories
    data_dirs = {
        'Symbolic AI': "dataset/dataset/json_cititation/1956-2024_sembolic_json/",
        'Statistical AI': "dataset/dataset/json_cititation/1956_2024_statistical/",
        'Hybrid AI': "dataset/dataset/json_cititation/1956_2024_hybrid_json/"
    }
    
    # Colors for each paradigm
    colors = {
        'Symbolic AI': '#1f77b4',      # Blue
        'Statistical AI': '#ff7f0e',   # Orange  
        'Hybrid AI': '#2ca02c'         # Green
    }
    
    # Load data for all paradigms
    paradigm_data = {}
    for paradigm, data_dir in data_dirs.items():
        print(f"\n=== Loading {paradigm} ===")
        df = load_paradigm_data(paradigm, data_dir)
        if not df.empty:
            paradigm_data[paradigm] = df
            print(f"Loaded {len(df)} publications from {df['year'].min()} to {df['year'].max()}")
    
    # Create the comparative plot (NO MAIN TITLE)
    fig, ax = plt.subplots(1, 1, figsize=(14, 10))
    
    # Year range for plotting
    all_years = range(1956, 2025)
    
    # Collect fitted params for dynamic annotations
    fitted_params = {}
    # Process each paradigm
    for paradigm, df in paradigm_data.items():
        # Prepare data for analysis
        annual_counts = df.groupby('year').size().to_dict()
        
        # Fill missing years with 0
        for year in all_years:
            if year not in annual_counts:
                annual_counts[year] = 0
        
        # Calculate cumulative data
        years = sorted(annual_counts.keys())
        cumulative_pubs = np.cumsum([annual_counts[year] for year in years])
        
        # Fit S-curve
        pub_params, pub_r2 = fit_s_curve(years, cumulative_pubs)
        
        # Plot actual data points
        ax.scatter(years, cumulative_pubs, color=colors[paradigm], alpha=0.7, s=40, zorder=5)
        
        # Plot S-curve fit
        if pub_params is not None:
            y_fit = s_curve_function(np.array(years), *pub_params)
            ax.plot(years, y_fit, color=colors[paradigm], linewidth=3, 
                   label=f'{paradigm} (R² = {pub_r2:.3f})', zorder=4)
            fitted_params[paradigm] = pub_params
        
        # Print summary
        print(f"\n=== {paradigm.upper()} SUMMARY ===")
        print(f"Total Publications: {len(df):,}")
        print(f"Year Range: {df['year'].min():.0f} - {df['year'].max():.0f}")
        print(f"Total Citations: {df['citations'].sum():,}")
        print(f"Average Citations per Publication: {df['citations'].mean():.1f}")
        
        if pub_params is not None:
            print(f"S-Curve Parameters:")
            print(f"  Carrying Capacity (L): {pub_params[0]:.0f}")
            print(f"  Growth Rate (k): {pub_params[1]:.4f}")
            print(f"  Inflection Point (x0): {pub_params[2]:.1f}")
            print(f"  R-squared: {pub_r2:.3f}")
    
    # Customize the plot
    ax.set_xlabel('Year', fontsize=14, fontweight='bold')
    ax.set_ylabel('Cumulative Publications', fontsize=14, fontweight='bold')
    ax.grid(True, alpha=0.3)
    ax.set_xlim(1955, 2025)
    ax.set_ylim(0, None)
    
    # Legend
    ax.legend(loc='upper left', frameon=True, fancybox=True, shadow=True)
    
    # Adjust layout
    plt.tight_layout()
    
    ## ADD HERE
    # Dynamic annotations using fitted curve parameters
    ymax = ax.get_ylim()[1]
    # Safeguard if some paradigms didn't fit
    x0_symbolic = fitted_params.get('Symbolic AI', [None, None, None])[2]
    x0_statistical = fitted_params.get('Statistical AI', [None, None, None])[2]
    x0_hybrid = fitted_params.get('Hybrid AI', [None, None, None])[2]

    # Helper to compute y on fitted curve at a given x for a paradigm
    def y_on_curve(paradigm_name, x_value):
        params = fitted_params.get(paradigm_name)
        if params is None:
            return None
        return s_curve_function(np.array([x_value]), *params)[0]

    # Transition: Symbolic -> Statistical, place arrow from late Symbolic to early Statistical
    if x0_symbolic is not None and x0_statistical is not None:
        x_from = max(1956, min(2024, x0_symbolic + 5))
        x_to = max(1956, min(2024, x0_statistical - 2))
        y_from = y_on_curve('Symbolic AI', x_from)
        y_to = y_on_curve('Statistical AI', x_to)
        if y_from is not None and y_to is not None:
            ax.annotate('', xy=(x_to, y_to), xytext=(x_from, y_from),
                        arrowprops=dict(arrowstyle='->', lw=2, color='red', alpha=0.7))
            ax.text((x_from + x_to) / 2.0, (y_from + y_to) / 2.0,
                    'Paradigm\nTransition', fontsize=10, ha='center',
                    bbox=dict(boxstyle="round,pad=0.3", facecolor='lightcoral', alpha=0.7))

    # Transition: Statistical -> Hybrid
    if x0_statistical is not None and x0_hybrid is not None:
        x_from = max(1956, min(2024, x0_statistical + 5))
        x_to = max(1956, min(2024, x0_hybrid - 2))
        y_from = y_on_curve('Statistical AI', x_from)
        y_to = y_on_curve('Hybrid AI', x_to)
        if y_from is not None and y_to is not None:
            ax.annotate('', xy=(x_to, y_to), xytext=(x_from, y_from),
                        arrowprops=dict(arrowstyle='->', lw=2, color='red', alpha=0.7))
            ax.text((x_from + x_to) / 2.0, (y_from + y_to) / 2.0,
                    'Paradigm\nTransition', fontsize=10, ha='center',
                    bbox=dict(boxstyle="round,pad=0.3", facecolor='lightcoral', alpha=0.7))

    # Phase labels via logistic inverse at characteristic fractions of L
    def logistic_inverse(L_val, k_val, x0_val, y_val):
        # x = x0 + (1/k) * ln(y/(L-y))
        eps = 1e-9
        y_val = max(min(y_val, L_val - eps), eps)
        return x0_val + (1.0 / max(k_val, eps)) * np.log(y_val / (L_val - y_val))

    # Use the same three labels for each paradigm for consistency
    phase_spec = [(0.15, 'Emergence'), (0.50, 'Growth'), (0.85, 'Maturity')]

    def place_phase_labels(paradigm_name, color_hex):
        params = fitted_params.get(paradigm_name)
        if params is None:
            return
        L_val, k_val, x0_val = params
        for frac, label in phase_spec:
            y_target = L_val * frac
            x_pos = logistic_inverse(L_val, k_val, x0_val, y_target)
            x_pos = float(max(1956, min(2024, x_pos)))
            y_pos = y_on_curve(paradigm_name, x_pos)
            if y_pos is not None:
                ax.text(x_pos, y_pos, label, fontsize=9, ha='center', style='italic', color=color_hex)

    place_phase_labels('Symbolic AI', '#1f77b4')
    place_phase_labels('Statistical AI', '#ff7f0e')
    place_phase_labels('Hybrid AI', '#2ca02c')

    # Show decreasing time between phases using bidirectional arrows labeled with duration (years)
    def place_phase_durations(paradigm_name, color_hex, y_offset_factor):
        params = fitted_params.get(paradigm_name)
        if params is None:
            return
        L_val, k_val, x0_val = params
        # Characteristic x positions for Emergence, Growth, Maturity
        x_em = float(max(1956, min(2024, logistic_inverse(L_val, k_val, x0_val, L_val * 0.15))))
        x_gr = float(max(1956, min(2024, logistic_inverse(L_val, k_val, x0_val, L_val * 0.50))))
        x_ma = float(max(1956, min(2024, logistic_inverse(L_val, k_val, x0_val, L_val * 0.85))))
        # Helper to draw arrow and label between two x's
        def draw_duration(x_left, x_right):
            if x_right <= x_left:
                return
            x_mid = (x_left + x_right) / 2.0
            y_mid_curve = y_on_curve(paradigm_name, x_mid)
            if y_mid_curve is None:
                return
            y_ann = y_mid_curve * y_offset_factor
            ax.annotate('', xy=(x_right, y_ann), xytext=(x_left, y_ann),
                        arrowprops=dict(arrowstyle='<->', lw=1.8, color=color_hex, alpha=0.9))
            ax.text(x_mid, y_ann * 1.02, f"{int(round(x_right - x_left))} yrs", fontsize=8,
                    ha='center', va='bottom', color=color_hex)
        draw_duration(x_em, x_gr)
        draw_duration(x_gr, x_ma)

    # Offset factors to avoid overlaps across paradigms
    place_phase_durations('Symbolic AI', '#1f77b4', 0.92)
    place_phase_durations('Statistical AI', '#ff7f0e', 0.88)
    place_phase_durations('Hybrid AI', '#2ca02c', 0.84)

    # Vertical lines at inflection points when available
    for name, color in [('Symbolic AI', '#1f77b4'), ('Hybrid AI', '#2ca02c')]:
        params = fitted_params.get(name)
        if params is not None:
            x0 = params[2]
            ax.axvline(x=x0, color='gray', linestyle='--', alpha=0.5, linewidth=1)
            ax.text(x0, ymax * 0.95, f'{int(x0)}\n{name.split()[0]} AI\nInflection', fontsize=8, ha='center',
                    bbox=dict(boxstyle="round,pad=0.2", facecolor='lightgray', alpha=0.7))

    # Kurzweil's law annotation anchored to current ylim
    ax.text(1960, ymax * 0.90, "Kurzweil's Law of Accelerating Returns:\n\"Each paradigm creates the next\"",
            fontsize=11, ha='left', va='top',
            bbox=dict(boxstyle="round,pad=0.5", facecolor='lightyellow', alpha=0.8))

    # Save the plot with high DPI
    output_path = 'comparative_ai_s_curves_new222222222.png'
    plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor='white')
    print(f"\nComparative S-curve analysis saved to: {output_path}")
    
    return output_path

if __name__ == "__main__":
    create_comparative_s_curves()

