#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from collections import Counter, defaultdict
import seaborn as sns
from matplotlib_venn import venn3
import warnings
warnings.filterwarnings('ignore')

def extract_keywords_from_vosviewer_json(file_path, paradigm_name):
    """Extract keywords from VOSviewer JSON file"""
    try:
        with open(file_path, 'r', encoding='utf-8-sig') as f:
            data = json.load(f)
        
        keywords = []
        keyword_data = {}
        
        # Extract from network items
        items = data.get('network', {}).get('items', [])
        
        for item in items:
            label = item.get('label', '').lower().strip()
            if label and len(label) > 2:
                keywords.append(label)
                
                # Store additional data
                weights = item.get('weights', {})
                keyword_data[label] = {
                    'occurrences': weights.get('Occurrences', 0),
                    'total_link_strength': weights.get('Total link strength', 0),
                    'links': weights.get('Links', 0),
                    'cluster': item.get('cluster', 0)
                }
        
        print(f"{paradigm_name}: {len(keywords)} keywords extracted")
        return keywords, keyword_data
        
    except Exception as e:
        print(f"Error reading {file_path}: {e}")
        return [], {}

def create_figure1_heatmap(symbolic_data, statistical_data, hybrid_data):
    """Create Figure 1: Keyword Occurrence Frequencies Heatmap"""
    
    # Get keyword occurrences for each paradigm
    symbolic_keywords, symbolic_info = symbolic_data
    statistical_keywords, statistical_info = statistical_data
    hybrid_keywords, hybrid_info = hybrid_data
    
    # Get all unique keywords
    all_keywords = set(symbolic_keywords + statistical_keywords + hybrid_keywords)
    
    # Calculate total occurrences for each keyword across all paradigms
    keyword_totals = {}
    for keyword in all_keywords:
        total = 0
        if keyword in symbolic_info:
            total += symbolic_info[keyword]['occurrences']
        if keyword in statistical_info:
            total += statistical_info[keyword]['occurrences']
        if keyword in hybrid_info:
            total += hybrid_info[keyword]['occurrences']
        keyword_totals[keyword] = total
    
    # Get top 20 keywords by total occurrences
    top_keywords = sorted(keyword_totals.items(), key=lambda x: x[1], reverse=True)[:20]
    top_keyword_names = [item[0] for item in top_keywords]
    
    # Create data matrix
    data_matrix = []
    paradigms = ['Hybrid AI', 'Statistical AI', 'Symbolic AI']
    
    for keyword in top_keyword_names:
        row = [
            hybrid_info.get(keyword, {}).get('occurrences', 0),
            statistical_info.get(keyword, {}).get('occurrences', 0),
            symbolic_info.get(keyword, {}).get('occurrences', 0)
        ]
        data_matrix.append(row)
    
    # Create heatmap
    fig, ax = plt.subplots(figsize=(12, 10))
    
    # Convert to numpy array
    data_array = np.array(data_matrix)
    
    # Create heatmap
    im = ax.imshow(data_array, cmap='Blues', aspect='auto')
    
    # Set ticks and labels
    ax.set_xticks(np.arange(len(paradigms)))
    ax.set_yticks(np.arange(len(top_keyword_names)))
    ax.set_xticklabels(paradigms, fontsize=12, fontweight='bold')
    ax.set_yticklabels(top_keyword_names, fontsize=11)
    
    # Add text annotations
    for i in range(len(top_keyword_names)):
        for j in range(len(paradigms)):
            text = ax.text(j, i, int(data_array[i, j]),
                          ha="center", va="center", 
                          color="white" if data_array[i, j] > data_array.max()/2 else "black",
                          fontweight='bold', fontsize=10)
    
    # Add colorbar
    cbar = plt.colorbar(im, ax=ax, shrink=0.8)
    cbar.set_label('Occurrences', fontsize=12, fontweight='bold')
    
    # Set labels
    ax.set_xlabel('AI Paradigm', fontsize=14, fontweight='bold')
    ax.set_ylabel('Keywords', fontsize=14, fontweight='bold')
    
    # Adjust layout
    plt.tight_layout()
    
    # Save figure
    plt.savefig('new_figure1_keyword_heatmap.png', dpi=300, bbox_inches='tight', facecolor='white')
    plt.close()
    
    return top_keyword_names, data_matrix

def create_figure2_venn_diagram(symbolic_data, statistical_data, hybrid_data):
    """Create Figure 2: Venn Diagram of Keyword Overlap"""
    
    # Get keyword sets
    symbolic_keywords, _ = symbolic_data
    statistical_keywords, _ = statistical_data
    hybrid_keywords, _ = hybrid_data
    
    # Convert to sets
    symbolic_set = set(symbolic_keywords)
    statistical_set = set(statistical_keywords)
    hybrid_set = set(hybrid_keywords)
    
    # Create Venn diagram
    fig, ax = plt.subplots(figsize=(10, 8))
    
    # Create venn diagram
    venn = venn3([symbolic_set, statistical_set, hybrid_set], 
                 ('Symbolic AI', 'Statistical AI', 'Hybrid AI'),
                 ax=ax)
    
    # Customize colors
    if venn.get_patch_by_id('100'):
        venn.get_patch_by_id('100').set_color('#ffb3ba')  # Light red
    if venn.get_patch_by_id('010'):
        venn.get_patch_by_id('010').set_color('#bae1ff')  # Light blue
    if venn.get_patch_by_id('001'):
        venn.get_patch_by_id('001').set_color('#baffc9')  # Light green
    if venn.get_patch_by_id('110'):
        venn.get_patch_by_id('110').set_color('#ffffba')  # Light yellow
    if venn.get_patch_by_id('101'):
        venn.get_patch_by_id('101').set_color('#ffdfba')  # Light orange
    if venn.get_patch_by_id('011'):
        venn.get_patch_by_id('011').set_color('#e0bbff')  # Light purple
    if venn.get_patch_by_id('111'):
        venn.get_patch_by_id('111').set_color('#d3d3d3')  # Light gray
    
    # Set font sizes
    for text in venn.set_labels:
        if text:
            text.set_fontsize(14)
            text.set_fontweight('bold')
    
    for text in venn.subset_labels:
        if text:
            text.set_fontsize(12)
            text.set_fontweight('bold')
    
    plt.tight_layout()
    
    # Save figure
    plt.savefig('new_figure2_venn_diagram.png', dpi=300, bbox_inches='tight', facecolor='white')
    plt.close()

def create_figure3_overlap_matrix(symbolic_data, statistical_data, hybrid_data):
    """Create Figure 3: Conceptual Overlap Matrix"""
    
    # Get keyword data
    symbolic_keywords, symbolic_info = symbolic_data
    statistical_keywords, statistical_info = statistical_data
    hybrid_keywords, hybrid_info = hybrid_data
    
    # Get all unique keywords
    all_keywords = list(set(symbolic_keywords + statistical_keywords + hybrid_keywords))
    
    # Filter keywords by minimum occurrence threshold
    min_occurrences = 10
    filtered_keywords = []
    
    for keyword in all_keywords:
        total_occurrences = 0
        if keyword in symbolic_info:
            total_occurrences += symbolic_info[keyword]['occurrences']
        if keyword in statistical_info:
            total_occurrences += statistical_info[keyword]['occurrences']
        if keyword in hybrid_info:
            total_occurrences += hybrid_info[keyword]['occurrences']
        
        if total_occurrences >= min_occurrences:
            filtered_keywords.append((keyword, total_occurrences))
    
    # Sort by total occurrences and take top 25
    filtered_keywords.sort(key=lambda x: x[1], reverse=True)
    selected_keywords = [item[0] for item in filtered_keywords[:25]]
    
    # Create binary matrix (1 if keyword exists in paradigm, 0 otherwise)
    paradigms = ['Symbolic AI', 'Hybrid AI', 'Statistical AI']
    matrix_data = []
    
    for keyword in selected_keywords:
        row = []
        # Symbolic AI
        row.append(1 if keyword in symbolic_keywords else 0)
        # Hybrid AI  
        row.append(1 if keyword in hybrid_keywords else 0)
        # Statistical AI
        row.append(1 if keyword in statistical_keywords else 0)
        matrix_data.append(row)
    
    # Create heatmap
    fig, ax = plt.subplots(figsize=(8, 12))
    
    # Convert to numpy array
    matrix_array = np.array(matrix_data)
    
    # Create heatmap with green color scheme
    im = ax.imshow(matrix_array, cmap='Greens', aspect='auto', vmin=0, vmax=1)
    
    # Set ticks and labels
    ax.set_xticks(np.arange(len(paradigms)))
    ax.set_yticks(np.arange(len(selected_keywords)))
    ax.set_xticklabels(paradigms, fontsize=12, fontweight='bold')
    ax.set_yticklabels(selected_keywords, fontsize=10)
    
    # Add text annotations
    for i in range(len(selected_keywords)):
        for j in range(len(paradigms)):
            text = ax.text(j, i, int(matrix_array[i, j]),
                          ha="center", va="center", 
                          color="white" if matrix_array[i, j] > 0.5 else "black",
                          fontweight='bold', fontsize=12)
    
    # Add grid
    ax.set_xticks(np.arange(len(paradigms)+1)-.5, minor=True)
    ax.set_yticks(np.arange(len(selected_keywords)+1)-.5, minor=True)
    ax.grid(which="minor", color="white", linestyle='-', linewidth=2)
    
    plt.tight_layout()
    
    # Save figure
    plt.savefig('new_figure3_overlap_matrix.png', dpi=300, bbox_inches='tight', facecolor='white')
    plt.close()

def main():
    """Main function to create all figures"""
    print("Creating keyword analysis figures from NEW JSON data...")
    
    # Extract keywords from each JSON file
    print("Extracting keywords from VOSviewer JSON files...")
    symbolic_data = extract_keywords_from_vosviewer_json('dataset/dataset/json_keword_occurence/works_sembolic.json', 'Symbolic AI')
    statistical_data = extract_keywords_from_vosviewer_json('dataset/dataset/json_keword_occurence/works_statical.json', 'Statistical AI')
    hybrid_data = extract_keywords_from_vosviewer_json('dataset/dataset/json_keword_occurence/works_hibrit.json', 'Hybrid AI')
    
    # Check if we have data
    if not any([symbolic_data[0], statistical_data[0], hybrid_data[0]]):
        print("❌ No data extracted from JSON files!")
        return
    
    # Create Figure 1: Keyword Heatmap
    print("Creating Figure 1: Keyword Occurrence Frequencies Heatmap...")
    top_keywords, data_matrix = create_figure1_heatmap(symbolic_data, statistical_data, hybrid_data)
    
    # Create Figure 2: Venn Diagram
    print("Creating Figure 2: Venn Diagram...")
    create_figure2_venn_diagram(symbolic_data, statistical_data, hybrid_data)
    
    # Create Figure 3: Overlap Matrix
    print("Creating Figure 3: Conceptual Overlap Matrix...")
    create_figure3_overlap_matrix(symbolic_data, statistical_data, hybrid_data)
    
    print("✅ All NEW figures created successfully!")
    print("Files saved:")
    print("  - new_figure1_keyword_heatmap.png")
    print("  - new_figure2_venn_diagram.png") 
    print("  - new_figure3_overlap_matrix.png")

if __name__ == "__main__":
    main()

