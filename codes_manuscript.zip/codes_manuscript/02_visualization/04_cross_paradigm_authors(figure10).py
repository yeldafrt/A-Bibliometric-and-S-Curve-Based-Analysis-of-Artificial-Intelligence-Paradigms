#!/usr/bin/env python3
"""
Cross-Paradigm Authors Visualization
Excel dosyasından 1956-2024 arası cross-paradigm yazarların 
geçişkenliğini ve tarihsel izdüşümünü gösteren çok panelli görsel oluşturur.
"""

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from collections import Counter
import matplotlib.patches as patches
from matplotlib.patches import Rectangle
import warnings
warnings.filterwarnings('ignore')

# Görsel ayarları
plt.rcParams['figure.dpi'] = 300
plt.rcParams['savefig.dpi'] = 300
plt.rcParams['font.size'] = 10
plt.rcParams['axes.titlesize'] = 12
plt.rcParams['axes.labelsize'] = 10
plt.rcParams['xtick.labelsize'] = 9
plt.rcParams['ytick.labelsize'] = 9
plt.rcParams['legend.fontsize'] = 9
plt.rcParams['font.family'] = 'sans-serif'

def load_excel_data(file_path):
    """Excel dosyasından verileri yükler"""
    print(f"📊 Excel dosyası yükleniyor: {file_path}")
    
    # Tüm sheet'leri yükle
    sheets = {}
    
    try:
        # Ana yazarlar verisi
        sheets['authors'] = pd.read_excel(file_path, sheet_name='All Cross-Paradigm Authors')
        sheets['combinations'] = pd.read_excel(file_path, sheet_name='Paradigm Combinations')
        sheets['temporal'] = pd.read_excel(file_path, sheet_name='Temporal Analysis')
        sheets['institutional'] = pd.read_excel(file_path, sheet_name='Institutional Analysis')
        sheets['summary'] = pd.read_excel(file_path, sheet_name='Summary Statistics')
        
        print(f"✅ {len(sheets['authors'])} yazar verisi yüklendi")
        return sheets
        
    except Exception as e:
        print(f"❌ Excel dosyası yüklenirken hata: {e}")
        return None

def create_paradigm_combinations_chart(df_combinations, ax):
    """(a) Paradigma kombinasyonları pie chart"""
    
    # Veriyi hazırla
    combinations = df_combinations['Paradigm Combination'].tolist()
    counts = df_combinations['Author Count'].tolist()
    
    # Renk paleti
    colors = ['#2E86AB', '#A23B72', '#F18F01', '#C73E1D']
    
    # Pie chart oluştur
    wedges, texts, autotexts = ax.pie(counts, labels=combinations, autopct='%1.1f%%', 
                                     colors=colors, startangle=90, 
                                     textprops={'fontsize': 9})
    
    # Başlık
    ax.set_title('(a) Cross-Paradigm Author Distribution by Paradigm Combinations', 
                fontsize=12, fontweight='bold', pad=20)
    
    # Etiketleri düzenle
    for autotext in autotexts:
        autotext.set_color('white')
        autotext.set_fontweight('bold')
    
    return ax

def create_temporal_distribution_chart(df_authors, ax):
    """(b) Temporal dağılım histogram"""
    
    # Kariyer başlangıç yıllarını al
    career_starts = df_authors[df_authors['Career Start'] > 0]['Career Start']
    
    # Histogram oluştur
    bins = range(1950, 2030, 5)  # 5 yıllık aralıklar
    n, bins, patches = ax.hist(career_starts, bins=bins, alpha=0.7, 
                              color='#2E86AB', edgecolor='black', linewidth=0.5)
    
    # Renk gradyanı
    for i, patch in enumerate(patches):
        patch.set_facecolor(plt.cm.viridis(i / len(patches)))
    
    ax.set_xlabel('Career Start Year', fontsize=10)
    ax.set_ylabel('Number of Authors', fontsize=10)
    ax.set_title('(b) Temporal Distribution of Cross-Paradigm Authors (1956-2024)', 
                fontsize=12, fontweight='bold', pad=20)
    
    # Grid
    ax.grid(True, alpha=0.3)
    ax.set_xlim(1950, 2025)
    
    return ax

def create_career_span_analysis(df_authors, ax):
    """(c) Kariyer span vs paradigm count scatter plot"""
    
    # Veriyi hazırla
    df_clean = df_authors[(df_authors['Career Span (Years)'] > 0) & 
                         (df_authors['Career Span (Years)'] < 50)]  # Outlier'ları filtrele
    
    # Paradigm count'a göre renklendirme
    paradigm_counts = df_clean['Paradigm Count']
    colors = ['#F18F01' if x == 2 else '#C73E1D' if x == 3 else '#2E86AB' 
              for x in paradigm_counts]
    
    # Scatter plot
    scatter = ax.scatter(df_clean['Career Span (Years)'], df_clean['Total Citations'], 
                        c=colors, alpha=0.6, s=60, edgecolors='black', linewidth=0.5)
    
    ax.set_xlabel('Career Span (Years)', fontsize=10)
    ax.set_ylabel('Total Citations', fontsize=10)
    ax.set_title('(c) Career Span vs Citations by Paradigm Count', 
                fontsize=12, fontweight='bold', pad=20)
    
    # Logaritmik y ekseni
    ax.set_yscale('log')
    
    # Legend
    legend_elements = [
        plt.scatter([], [], c='#F18F01', s=60, label='2 Paradigms', edgecolors='black'),
        plt.scatter([], [], c='#C73E1D', s=60, label='3 Paradigms', edgecolors='black')
    ]
    ax.legend(handles=legend_elements, loc='upper right', fontsize=9)
    
    # Grid
    ax.grid(True, alpha=0.3)
    
    return ax

def create_institutional_analysis(df_institutional, ax):
    """(d) En aktif kurumlar bar chart"""
    
    # En aktif 10 kurumu al
    top_institutions = df_institutional.head(10)
    
    # Bar chart
    bars = ax.barh(range(len(top_institutions)), 
                   top_institutions['Cross-Paradigm Authors'],
                   color='#A23B72', alpha=0.7, edgecolor='black', linewidth=0.5)
    
    # Y ekseni etiketleri
    institution_names = [name[:30] + '...' if len(name) > 30 else name 
                        for name in top_institutions['Institution']]
    ax.set_yticks(range(len(top_institutions)))
    ax.set_yticklabels(institution_names, fontsize=9)
    
    ax.set_xlabel('Number of Cross-Paradigm Authors', fontsize=10)
    ax.set_title('(d) Leading Institutions in Cross-Paradigm AI Research', 
                fontsize=12, fontweight='bold', pad=20)
    
    # Değerleri bar'ların üzerine yaz
    for i, bar in enumerate(bars):
        width = bar.get_width()
        ax.text(width + 0.1, bar.get_y() + bar.get_height()/2, 
               f'{int(width)}', ha='left', va='center', fontsize=8)
    
    # Grid
    ax.grid(True, alpha=0.3, axis='x')
    ax.invert_yaxis()  # En yüksek değer üstte
    
    return ax

def create_paradigm_evolution_timeline(df_authors, ax):
    """(e) Paradigma evrim timeline (bonus panel)"""
    
    # Yıllara göre paradigma kombinasyonlarının dağılımı
    df_clean = df_authors[df_authors['Career Start'] > 0].copy()
    
    # 5 yıllık dönemlere böl
    df_clean['Period'] = ((df_clean['Career Start'] // 5) * 5).astype(int)
    
    # Paradigma kombinasyonlarını sayısal kodla
    paradigm_mapping = {
        'Statistical AI, Symbolic AI': 'Stat + Symb',
        'Hybrid AI, Symbolic AI': 'Hybrid + Symb', 
        'Hybrid AI, Statistical AI': 'Hybrid + Stat',
        'Hybrid AI, Statistical AI, Symbolic AI': 'All Three'
    }
    
    df_clean['Paradigm_Short'] = df_clean['Paradigms'].map(paradigm_mapping)
    df_clean['Paradigm_Short'] = df_clean['Paradigm_Short'].fillna('Other')
    
    # Pivot table oluştur
    pivot_data = df_clean.groupby(['Period', 'Paradigm_Short']).size().unstack(fill_value=0)
    
    # Stacked area chart
    periods = pivot_data.index
    colors = ['#2E86AB', '#A23B72', '#F18F01', '#C73E1D', '#6A994E']
    
    ax.stackplot(periods, *[pivot_data[col] for col in pivot_data.columns], 
                labels=pivot_data.columns, colors=colors[:len(pivot_data.columns)], alpha=0.7)
    
    ax.set_xlabel('Time Period', fontsize=10)
    ax.set_ylabel('Number of Authors', fontsize=10)
    ax.set_title('(e) Evolution of Cross-Paradigm Combinations Over Time', 
                fontsize=12, fontweight='bold', pad=20)
    
    # Legend
    ax.legend(loc='upper left', fontsize=8, framealpha=0.9)
    
    # Grid
    ax.grid(True, alpha=0.3)
    ax.set_xlim(1950, 2025)
    
    return ax

def create_productivity_vs_paradigms(df_authors, ax):
    """(f) Produktivite vs paradigm count violin plot"""
    
    # Veriyi hazırla
    df_clean = df_authors[df_authors['Total Works'] <= 50]  # Outlier'ları filtrele
    
    # Paradigm count'a göre grupla
    paradigm_2 = df_clean[df_clean['Paradigm Count'] == 2]['Total Works']
    paradigm_3 = df_clean[df_clean['Paradigm Count'] == 3]['Total Works']
    
    # Box plot
    data_to_plot = [paradigm_2, paradigm_3]
    box_plot = ax.boxplot(data_to_plot, labels=['2 Paradigms', '3 Paradigms'], 
                         patch_artist=True, notch=True)
    
    # Renklendirme
    colors = ['#F18F01', '#C73E1D']
    for patch, color in zip(box_plot['boxes'], colors):
        patch.set_facecolor(color)
        patch.set_alpha(0.7)
    
    ax.set_ylabel('Total Works', fontsize=10)
    ax.set_title('(f) Productivity Distribution by Number of Paradigms', 
                fontsize=12, fontweight='bold', pad=20)
    
    # Grid
    ax.grid(True, alpha=0.3, axis='y')
    
    # İstatistikleri ekle
    stats_text = f"2 Paradigms: μ={paradigm_2.mean():.1f}, n={len(paradigm_2)}\n"
    stats_text += f"3 Paradigms: μ={paradigm_3.mean():.1f}, n={len(paradigm_3)}"
    ax.text(0.02, 0.98, stats_text, transform=ax.transAxes, fontsize=8,
           verticalalignment='top', bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
    
    return ax

def create_comprehensive_visualization(sheets):
    """Kapsamlı çok panelli görselleştirme oluşturur"""
    print("🎨 Çok panelli görselleştirme oluşturuluyor...")
    
    # Figure oluştur (3x2 grid)
    fig = plt.figure(figsize=(16, 12))
    
    # Grid layout
    gs = fig.add_gridspec(3, 2, hspace=0.3, wspace=0.3, 
                         left=0.08, right=0.95, top=0.95, bottom=0.08)
    
    # Alt panelleri oluştur
    ax1 = fig.add_subplot(gs[0, 0])  # (a) Paradigm combinations
    ax2 = fig.add_subplot(gs[0, 1])  # (b) Temporal distribution
    ax3 = fig.add_subplot(gs[1, 0])  # (c) Career span analysis
    ax4 = fig.add_subplot(gs[1, 1])  # (d) Institutional analysis
    ax5 = fig.add_subplot(gs[2, 0])  # (e) Paradigm evolution
    ax6 = fig.add_subplot(gs[2, 1])  # (f) Productivity analysis
    
    # Panelleri doldur
    create_paradigm_combinations_chart(sheets['combinations'], ax1)
    create_temporal_distribution_chart(sheets['authors'], ax2)
    create_career_span_analysis(sheets['authors'], ax3)
    create_institutional_analysis(sheets['institutional'], ax4)
    create_paradigm_evolution_timeline(sheets['authors'], ax5)
    create_productivity_vs_paradigms(sheets['authors'], ax6)
    
    # Genel düzenlemeler
    plt.tight_layout()
    
    return fig

def save_visualization(fig, output_path):
    """Görselleştirmeyi kaydet"""
    print(f"💾 Görsel kaydediliyor: {output_path}")
    
    fig.savefig(output_path, dpi=300, bbox_inches='tight', 
               facecolor='white', edgecolor='none')
    
    print(f"✅ Görsel başarıyla kaydedildi!")
    return output_path

def main():
    """Ana fonksiyon"""
    print("🚀 Cross-Paradigm Authors Visualization Generator")
    print("="*60)
    
    # Excel dosyasını yükle
    excel_file = "cross_paradigm_authors_analysis22.xlsx"
    sheets = load_excel_data(excel_file)
    
    if sheets is None:
        print("❌ Excel dosyası yüklenemedi!")
        return
    
    # Görselleştirme oluştur
    fig = create_comprehensive_visualization(sheets)
    
    # Kaydet
    output_file = "cross_paradigm_authors_visualization.png"
    save_visualization(fig, output_file)
    
    # Özet bilgiler
    print(f"\n📊 Görselleştirme Özeti:")
    print(f"   📄 Kaynak: {excel_file}")
    print(f"   🎨 Çıktı: {output_file}")
    print(f"   📐 Boyut: 16x12 inch, 300 DPI")
    print(f"   📋 Panel sayısı: 6")
    print(f"   👥 Analiz edilen yazar: {len(sheets['authors'])}")
    
    print(f"\n🎯 Panel Açıklamaları:")
    print(f"   (a) Paradigm Combinations - Cross-paradigm yazarların dağılımı")
    print(f"   (b) Temporal Distribution - 1956-2024 arası temporal dağılım")
    print(f"   (c) Career Span Analysis - Kariyer süresi vs atıf analizi")
    print(f"   (d) Institutional Analysis - En aktif kurumlar")
    print(f"   (e) Paradigm Evolution - Zaman içinde paradigma evrim")
    print(f"   (f) Productivity Analysis - Paradigm sayısına göre produktivite")

if __name__ == "__main__":
    main()

