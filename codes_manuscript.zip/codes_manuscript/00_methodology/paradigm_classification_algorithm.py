#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Updated AI Paradigm Classification Algorithm
URL'lerdeki gerçek anahtar kelimelerle güncellenmiş versiyon
"""

import re
from typing import Dict, List, Tuple, Optional

class UpdatedAIParadigmClassifier:
    """
    Updated AI Paradigm Classification based on ACTUAL OpenAlex API keywords
    from url_ler.docx file analysis
    """
    
    def __init__(self):
        """Initialize with ACTUAL keywords from OpenAlex API queries"""
        
        # GERÇEK URL'lerden çıkarılan anahtar kelimeler (url_ler.docx)
        self.paradigm_keywords = {
            'Symbolic AI': [
                # Gerçek URL'lerden
                'rule-based', 'logic', 'ontology', 'symbolic',
                'knowledge representation', 'expert system', 
                'description logic', 'inference engine',
                # Genişletilmiş (related terms)
                'rule-based systems', 'rule-based reasoning',
                'logic programming', 'logical reasoning',
                'ontologies', 'expert systems',
                'knowledge base', 'knowledge engineering',
                'formal logic', 'first-order logic',
                'semantic reasoning', 'symbolic reasoning'
            ],
            
            'Statistical AI': [
                # Gerçek URL'lerden  
                'probabilistic', 'statistical', 'bayesian',
                'probabilistic inference', 'statistical learning',
                'naive bayes', 'hidden markov model', 
                'support vector machine', 'maximum likelihood',
                # Genişletilmiş (related terms)
                'machine learning', 'deep learning',
                'bayesian networks', 'bayesian inference',
                'neural networks', 'neural network',
                'statistical models', 'probabilistic models',
                'data-driven', 'statistical ai',
                'supervised learning', 'unsupervised learning'
            ],
            
            'Hybrid AI': [
                # Gerçek URL'lerden
                'neuro-symbolic', 'hybrid AI', 'hybrid reasoning',
                'symbolic-connectionist', 'neural-symbolic',
                'multi-strategy reasoning', 'cognitive architecture',
                # Genişletilmiş (related terms)
                'neurosymbolic', 'neuro symbolic',
                'hybrid intelligent systems', 'hybrid intelligence',
                'cognitive architectures', 'multi-paradigm',
                'integration ai', 'ai integration',
                'explainable ai', 'interpretable ai',
                'knowledge-enhanced', 'differentiable programming'
            ]
        }
        
        # Filtering criteria from URL analysis
        self.filtering_criteria = {
            'concepts_id': 'C41008148',  # Artificial Intelligence concept
            'publication_types': ['journal-article', 'book-chapter', 'proceedings-article'],
            'date_range': {
                'from': '1956-01-01',
                'to': '2024-12-31'
            },
            'search_field': 'title.search'  # URLs use title.search, not abstract.search
        }
        
        # Temporal ranges for each paradigm
        self.temporal_ranges = {
            'Symbolic AI': (1956, 2024),
            'Statistical AI': (1956, 2024), 
            'Hybrid AI': (1956, 2024)
        }
    
    def preprocess_text(self, text: str) -> str:
        """Preprocess text for keyword matching"""
        if not text:
            return ""
        
        # Convert to lowercase
        text = text.lower()
        
        # Remove special characters and normalize whitespace
        text = re.sub(r'[^\w\s-]', ' ', text)
        text = re.sub(r'\s+', ' ', text)
        
        return text.strip()
    
    def calculate_keyword_score(self, text: str, keywords: List[str]) -> Tuple[float, List[str]]:
        """Calculate keyword match score and return matched keywords"""
        if not text:
            return 0.0, []
        
        processed_text = self.preprocess_text(text)
        matches = []
        matched_keywords = []
        
        for keyword in keywords:
            processed_keyword = self.preprocess_text(keyword)
            if processed_keyword in processed_text:
                matches.append(keyword)
                matched_keywords.append(keyword)
        
        score = len(matches) / len(keywords) if keywords else 0.0
        return score, matched_keywords
    
    def check_temporal_range(self, paradigm: str, publication_year: int) -> bool:
        """Check if publication year falls within paradigm's temporal range"""
        if paradigm not in self.temporal_ranges:
            return True
        
        min_year, max_year = self.temporal_ranges[paradigm]
        return min_year <= publication_year <= max_year
    
    def classify_publication(self, title: str = "", abstract: str = "", 
                           keywords: List[str] = None, publication_year: int = None,
                           citations: int = 0) -> Tuple[str, Dict]:
        """
        Classify a publication into AI paradigm based on ACTUAL OpenAlex criteria
        
        Args:
            title: Publication title (primary search field in URLs)
            abstract: Publication abstract
            keywords: List of author keywords
            publication_year: Year of publication
            citations: Number of citations
            
        Returns:
            Tuple of (classified_paradigm, detailed_results)
        """
        
        # Combine text sources (title has priority as per URLs)
        combined_text = title
        if abstract:
            combined_text += " " + abstract
        if keywords:
            combined_text += " " + " ".join(keywords)
        
        # Calculate scores for each paradigm
        paradigm_results = {}
        
        for paradigm, paradigm_keywords in self.paradigm_keywords.items():
            # Calculate keyword match score
            score, matched_keywords = self.calculate_keyword_score(combined_text, paradigm_keywords)
            
            # Apply temporal filter
            temporal_valid = True
            if publication_year:
                temporal_valid = self.check_temporal_range(paradigm, publication_year)
                if not temporal_valid:
                    score = 0.0
            
            paradigm_results[paradigm] = {
                'score': score,
                'matched_keywords': matched_keywords,
                'temporal_valid': temporal_valid,
                'total_keywords': len(paradigm_keywords)
            }
        
        # Determine best matching paradigm
        valid_paradigms = {p: r for p, r in paradigm_results.items() if r['score'] > 0}
        
        if not valid_paradigms:
            best_paradigm = "Unclassified"
        else:
            best_paradigm = max(valid_paradigms.items(), key=lambda x: x[1]['score'])[0]
        
        return best_paradigm, paradigm_results
    
    def validate_against_urls(self) -> Dict:
        """Validate algorithm against actual OpenAlex URL criteria"""
        
        # URL'lerden çıkarılan gerçek kriterler
        actual_url_keywords = {
            'Symbolic AI': [
                'rule-based', 'logic', 'ontology', 'symbolic',
                'knowledge representation', 'expert system', 
                'description logic', 'inference engine'
            ],
            'Statistical AI': [
                'probabilistic', 'statistical', 'bayesian',
                'probabilistic inference', 'statistical learning',
                'naive bayes', 'hidden markov model', 
                'support vector machine', 'maximum likelihood'
            ],
            'Hybrid AI': [
                'neuro-symbolic', 'hybrid AI', 'hybrid reasoning',
                'symbolic-connectionist', 'neural-symbolic',
                'multi-strategy reasoning', 'cognitive architecture'
            ]
        }
        
        validation_results = {}
        
        for paradigm in actual_url_keywords.keys():
            actual_keywords = set(kw.lower() for kw in actual_url_keywords[paradigm])
            my_keywords = set(kw.lower() for kw in self.paradigm_keywords[paradigm])
            
            matches = actual_keywords.intersection(my_keywords)
            missing = actual_keywords - my_keywords
            extra = my_keywords - actual_keywords
            
            coverage = len(matches) / len(actual_keywords) * 100 if actual_keywords else 0
            
            validation_results[paradigm] = {
                'coverage_percent': coverage,
                'matches': sorted(matches),
                'missing_keywords': sorted(missing),
                'extra_keywords': sorted(extra),
                'total_actual': len(actual_keywords),
                'total_mine': len(my_keywords)
            }
        
        return validation_results

def main():
    """Demonstrate the updated classification algorithm"""
    
    classifier = UpdatedAIParadigmClassifier()
    
    print("🔍 UPDATED AI Paradigm Classification Algorithm")
    print("="*60)
    print("✅ Based on ACTUAL OpenAlex API keywords from url_ler.docx")
    
    # Validate against URLs
    print(f"\n📊 URL Validation Results:")
    validation = classifier.validate_against_urls()
    
    for paradigm, results in validation.items():
        print(f"\n🎯 {paradigm}:")
        print(f"  Coverage: {results['coverage_percent']:.1f}%")
        print(f"  Matches: {len(results['matches'])}/{results['total_actual']}")
        if results['missing_keywords']:
            print(f"  Missing: {', '.join(results['missing_keywords'][:3])}...")
    
    # Test examples
    print(f"\n🧪 Test Classifications:")
    
    test_cases = [
        {
            'title': 'Rule-based Expert System for Medical Diagnosis using Logic Programming',
            'publication_year': 1985,
        },
        {
            'title': 'Bayesian Networks for Probabilistic Inference in Statistical Learning',
            'publication_year': 2018,
        },
        {
            'title': 'Neuro-Symbolic Integration in Hybrid AI Systems with Cognitive Architecture',
            'publication_year': 2022,
        }
    ]
    
    for i, test_case in enumerate(test_cases, 1):
        paradigm, results = classifier.classify_publication(**test_case)
        
        print(f"\n📄 Test {i}: {test_case['title'][:50]}...")
        print(f"  Classified as: {paradigm}")
        
        # Show top matches
        for p, r in results.items():
            if r['matched_keywords']:
                print(f"  {p}: {r['score']:.3f} ({', '.join(r['matched_keywords'][:2])}...)")

if __name__ == "__main__":
    main()

