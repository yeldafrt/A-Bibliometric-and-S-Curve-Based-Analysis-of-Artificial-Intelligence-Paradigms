#!/usr/bin/env python3
"""
Statistical AI S-curve parametrelerini hesapla - pub_year sütunu kullanılarak
"""

import pandas as pd
import numpy as np
from scipy.optimize import curve_fit

def logistic_function(x, L, k, x0):
    """Logistic function"""
    return L / (1 + np.exp(-k * (x - x0)))

def calculate_scurve_parameters():
    print("=== STATISTICAL AI S-CURVE PARAMETRELERİ HESAPLAMA ===\n")
    
    excel_path = "/home/ubuntu/upload/pasted_file_9Vms2w_citation_analysis_across_ai_paradigms.xlsx"
    
    try:
        # All Citation Data'dan Statistical AI verilerini al
        df_all = pd.read_excel(excel_path, sheet_name='All Citation Data')
        df_stat = df_all[df_all['paradigm'].str.contains('Statistical', case=False, na=False)]
        
        print(f"📊 Statistical AI toplam yayın: {len(df_stat)}")
        
        # pub_year sütununu kullan
        year_col = 'pub_year'
        print(f"📅 Kullanılan yıl sütunu: {year_col}")
        
        # NaN değerleri temizle
        df_stat_clean = df_stat.dropna(subset=[year_col])
        print(f"📊 Temizlenmiş veri: {len(df_stat_clean)} yayın")
        
        # Yıllık yayın sayılarını hesapla
        yearly_counts = df_stat_clean[year_col].value_counts().sort_index()
        
        print(f"📅 Yıl aralığı: {yearly_counts.index.min()} - {yearly_counts.index.max()}")
        print(f"📊 Toplam yıl sayısı: {len(yearly_counts)}")
        
        # En yüksek yayın yılı
        max_year = yearly_counts.idxmax()
        max_count = yearly_counts.max()
        print(f"📈 En yüksek yayın yılı: {max_year} ({max_count} yayın)")
        
        # 2017 kontrolü
        if 2017 in yearly_counts.index:
            count_2017 = yearly_counts[2017]
            print(f"📊 2017 yayın sayısı: {count_2017}")
            print(f"📝 Metin değeri: 781")
            print(f"🔍 Fark: {abs(781 - count_2017)}")
            
            if abs(781 - count_2017) < 50:
                print("✅ 2017 pik değeri: DOĞRU")
            else:
                print("⚠️ 2017 pik değeri: FARKLI")
        
        # Kümülatif yayın sayılarını hesapla
        cumulative_pubs = yearly_counts.cumsum()
        print(f"📈 Toplam kümülatif yayın: {cumulative_pubs.iloc[-1]}")
        
        # S-curve fitting için veri hazırla
        years = cumulative_pubs.index.values
        publications = cumulative_pubs.values
        
        # Başlangıç yılını 0 yap
        start_year = years[0]
        x_data = years - start_year
        y_data = publications
        
        print(f"\n📊 S-CURVE FİTTİNG:")
        print(f"Veri noktası sayısı: {len(x_data)}")
        print(f"Başlangıç yılı: {start_year}")
        print(f"Son kümülatif: {y_data[-1]} yayın")
        
        # Logistic curve fitting
        L_guess = y_data[-1] * 1.2  # Biraz daha yüksek tahmin
        k_guess = 0.15
        x0_guess = len(x_data) * 0.6  # Inflection point tahmini
        
        try:
            popt, pcov = curve_fit(logistic_function, x_data, y_data, 
                                 p0=[L_guess, k_guess, x0_guess],
                                 maxfev=10000,
                                 bounds=([y_data[-1], 0.01, 0], 
                                        [y_data[-1]*2, 1.0, len(x_data)]))
            
            L_fitted, k_fitted, x0_fitted = popt
            inflection_year = x0_fitted + start_year
            
            # R² hesapla
            y_pred = logistic_function(x_data, *popt)
            ss_res = np.sum((y_data - y_pred) ** 2)
            ss_tot = np.sum((y_data - np.mean(y_data)) ** 2)
            r_squared = 1 - (ss_res / ss_tot)
            
            print("\n🎯 HESAPLANAN S-CURVE PARAMETRELERİ:")
            print(f"📈 Carrying Capacity (L): {L_fitted:.0f}")
            print(f"📊 Growth Rate (k): {k_fitted:.4f}")
            print(f"📅 Inflection Point: {inflection_year:.1f}")
            print(f"📊 R² değeri: {r_squared:.4f}")
            
            print("\n📝 METİNDEKİ DEĞERLERLE KARŞILAŞTIRMA:")
            print("="*50)
            print(f"{'Parametre':<20} {'Metin':<10} {'Hesaplanan':<12} {'Fark':<10}")
            print("="*50)
            print(f"{'Carrying Capacity':<20} {'7,467':<10} {L_fitted:<12.0f} {abs(7467 - L_fitted):<10.0f}")
            print(f"{'Inflection Point':<20} {'2013.0':<10} {inflection_year:<12.1f} {abs(2013.0 - inflection_year):<10.1f}")
            print(f"{'R²':<20} {'0.992':<10} {r_squared:<12.3f} {abs(0.992 - r_squared):<10.4f}")
            print("="*50)
            
            # Doğruluk değerlendirmesi
            print("\n✅ DOĞRULUK DEĞERLENDİRMESİ:")
            
            capacity_diff = abs(7467 - L_fitted)
            inflection_diff = abs(2013.0 - inflection_year)
            r2_diff = abs(0.992 - r_squared)
            
            capacity_ok = capacity_diff < 1000
            inflection_ok = inflection_diff < 3.0
            r2_ok = r2_diff < 0.02
            
            print(f"📈 Carrying Capacity: {'✅ DOĞRU' if capacity_ok else '⚠️ FARKLI'} (fark: {capacity_diff:.0f})")
            print(f"📅 Inflection Point: {'✅ DOĞRU' if inflection_ok else '⚠️ FARKLI'} (fark: {inflection_diff:.1f} yıl)")
            print(f"📊 R²: {'✅ DOĞRU' if r2_ok else '⚠️ FARKLI'} (fark: {r2_diff:.4f})")
            
            # Genel sonuç
            total_correct = sum([capacity_ok, inflection_ok, r2_ok])
            print(f"\n🏆 GENEL SONUÇ: {total_correct}/3 parametre doğru")
            
            if total_correct == 3:
                print("🎯 TÜM S-CURVE PARAMETRELERİ DOĞRU!")
            elif total_correct >= 2:
                print("✅ S-CURVE PARAMETRELERİ BÜYÜK ORANDA DOĞRU")
            else:
                print("⚠️ S-CURVE PARAMETRELERİNDE FARKLILIKLAR VAR")
                
        except Exception as e:
            print(f"❌ Curve fitting hatası: {e}")
            print("Manuel parametre kontrolü yapılıyor...")
            
            # Manuel kontrol
            print(f"\n📊 MANUEL KONTROL:")
            print(f"Toplam yayın: {y_data[-1]}")
            print(f"Metin carrying capacity: 7,467")
            print(f"Fark: {abs(7467 - y_data[-1])}")
            
    except Exception as e:
        print(f"❌ Veri okuma hatası: {e}")

if __name__ == "__main__":
    calculate_scurve_parameters()

